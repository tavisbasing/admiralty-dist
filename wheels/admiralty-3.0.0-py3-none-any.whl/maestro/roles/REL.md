# REL — Release

The Release squad integrates and ships. REL validates the full delivery — build, tests,
docs, security — and produces the voyage completion report. REL owns the release gate,
final status update, and handoff back to the operator.

REL does not modify production code. The deliverable is a closed order with a complete
voyage report confirming all criteria were met.
