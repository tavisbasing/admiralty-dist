# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Maestro — AI-orchestrated multi-agent coding for Claude Code.

This is the `admiralty` distribution: the legacy-named package retained for
backward compatibility. The product is Maestro.

Version: 3.0.1
Repository: https://github.com/tavisbasing/Admiralty
"""

__version__ = "3.0.1"
__title__ = "Maestro"

# Licence check — runs on every CLI startup (skipped for version/init — see cli.py)
from admiralty import auth as _auth
_auth.check()
