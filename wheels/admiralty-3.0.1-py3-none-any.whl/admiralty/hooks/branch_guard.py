"""
Branch-discipline guard for crew git/gh operations.

Refuses any git/gh tool call that mutates state on a branch other than
MAESTRO_SPRINT_BRANCH (legacy: ADMIRALTY_VOYAGE_BRANCH).
Bypass with MAESTRO_BRANCH_GUARD_BYPASS=1 (legacy: ADMIRALTY_BRANCH_GUARD_BYPASS=1)
(operator manual-recovery sessions only — must be set explicitly in the
parent shell).

Background:
  - BUG-ADM-2026-0004. The dispatcher records `voyageBranch` on every
    order but historically nothing verified that crews actually operated
    on that branch. Crews running on the wrong branch produced
    cross-voyage contamination during the VOY-0028 / VOY-0030 batch1
    split (PR #30 → PR #31 + #32) and forced a `git push
    --force-with-lease` recovery. This module is the runtime enforcement.

  - BUG-ADM-2026-0009 (v2.5.7). The original implementation fell open
    when ADMIRALTY_VOYAGE_BRANCH was unset, on the assumption that
    Captain interactive sessions and "loose" orders without a voyage
    needed an unmoderated path. That hatch was too permissive: a crew
    dispatched without a voyageBranch silently inherited whatever branch
    the dispatcher's parent shell happened to be on (in Captain's repro,
    `restructure/flatten-structure`) and pushed 3 commits there. The
    intended voyage branch missed the work. The fix below now refuses
    mutating git/gh tool calls when MAESTRO_SPRINT_BRANCH is unset,
    keeping non-mutating commands (status, diff, log) free. Operator
    manual-recovery sessions opt out via MAESTRO_BRANCH_GUARD_BYPASS=1
    in the parent shell.
"""

from __future__ import annotations

import os
import re
import subprocess
from typing import Tuple

from maestro.env import branch_guard_bypass as _bypass, sprint_branch as _sprint_branch


# Git commands that mutate state and therefore care about branch identity.
# Read-only commands (status, log, diff, fetch, ls-files) are not gated.
_GIT_MUTATING = re.compile(
    r"(?:^|\s|;|&&|\|\|)\s*git\s+"
    r"(commit|push|checkout|switch|merge|rebase|reset|tag|am|cherry-pick|"
    r"branch\s+(?:-D|-d|-m|--delete|--move))\b"
)

_GH_MUTATING = re.compile(
    r"(?:^|\s|;|&&|\|\|)\s*gh\s+"
    r"(pr\s+create|pr\s+merge|pr\s+close|release\s+create|api\s+graphql)\b"
)

# Redacts inline credentials before the command is echoed in a deny reason.
# - userinfo in URLs:  https://user:token@github.com/... → https://user:***@github.com/...
# - bare token-looking flags: --token=ghp_xxx              → --token=***
_CRED_USERINFO = re.compile(r"(https?://[^/\s:]+:)([^@\s]+)(@)")
_CRED_FLAG = re.compile(r"(--(?:token|password|api[-_]?key)[ =])(\S+)", re.IGNORECASE)


def _redact(command: str) -> str:
    redacted = _CRED_USERINFO.sub(r"\1***\3", command)
    redacted = _CRED_FLAG.sub(r"\1***", redacted)
    return redacted


def _current_branch() -> str:
    """Return git current-branch name, or empty string on failure."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return ""


def check_branch(tool_name: str, command: str) -> Tuple[bool, str]:
    """
    Decide whether to allow a tool invocation under branch discipline.

    Returns:
        (allow, reason)
        allow=True  → operation permitted; reason is empty.
        allow=False → operation must be denied; reason is human-readable
                      and surfaces to the crew so it knows how to recover.
    """
    if _bypass():
        return True, ""

    if tool_name != "Bash":
        return True, ""

    is_mutating = bool(_GIT_MUTATING.search(command) or _GH_MUTATING.search(command))
    if not is_mutating:
        return True, ""

    expected = _sprint_branch().strip()
    if not expected:
        # BUG-ADM-2026-0009: refuse loose mutations. Without MAESTRO_SPRINT_BRANCH
        # in the crew environment the guard has no way to verify which branch
        # the mutation should land on, and silently allowing the operation
        # caused 3 commits to land on a stale branch in the PSG retest.
        # Copilot review on PR #58: this hook can only see the env var, not
        # the order JSON — so the deny reason describes what the guard
        # actually observed (env unset) rather than guessing at order state.
        return False, (
            "Branch guard: refusing "
            f"`{_redact(command).strip()[:80]}` — no MAESTRO_SPRINT_BRANCH "
            "in the crew environment, so this mutation has no verified "
            "target branch. The dispatcher injects this var from the order's "
            "resolved voyageBranch; if it's missing, the order likely has no "
            "voyageBranch (and no parent voyage.branch / no operator-set env "
            "var), or the dispatcher failed to export it. Either set "
            "voyageBranch on the order (or branch on its parent voyage), "
            "re-dispatch, or set MAESTRO_BRANCH_GUARD_BYPASS=1 in the "
            "parent shell for manual-recovery sessions."
        )

    actual = _current_branch()
    if not actual:
        return False, (
            "Branch guard: could not resolve current branch; refusing "
            "git/gh mutation. Set MAESTRO_BRANCH_GUARD_BYPASS=1 only "
            "if you intentionally need to act outside a voyage branch."
        )

    if actual != expected:
        return False, (
            f"Branch guard: refusing `{_redact(command).strip()[:80]}` because "
            f"current branch is `{actual}` but this order's voyageBranch "
            f"is `{expected}`. Switch to `{expected}` before mutating "
            "git state."
        )

    # We're on the right branch — but the *target* of the mutation can still
    # name a different branch. Catch those explicit cross-branch targets.
    target_violation = _explicit_target_branch_violation(command, expected)
    if target_violation:
        return False, target_violation

    return True, ""


# Branch-name token: anything except whitespace and shell separators.
_BRANCH_TOK = r"[^\s;&|<>]+"


def _strip_quotes(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
        return value[1:-1]
    return value


def _explicit_target_branch_violation(command: str, expected: str) -> str:
    """If `command` names an explicit non-`expected` branch as its target,
    return a deny-reason; otherwise return ''.

    Caught patterns (any of):
      git checkout <branch>            (when branch != expected)
      git switch [-c|-C|--create] <branch>
      git push <remote> <branch>       (where <branch> is a non-flag refspec)
      git push <remote> HEAD:<branch>
      gh pr create --head <branch>     and --head=<branch>
      gh pr create --head "<branch>"   (quoted)
    """
    cmd = command.strip()

    # gh pr create — both space and equals forms; tolerate quotes.
    if re.search(r"(?:^|\s|;|&&|\|\|)\s*gh\s+pr\s+create\b", cmd):
        m = re.search(r"--head(?:\s+|=)([^\s;&|<>]+)", cmd)
        if m:
            head = _strip_quotes(m.group(1))
            if head and head != expected:
                return (
                    f"Branch guard: `gh pr create --head {head}` does not "
                    f"match the order's voyageBranch `{expected}`."
                )

    # git checkout <branch>  (skip flag-only checkouts like `git checkout -- file`)
    m = re.search(
        r"(?:^|\s|;|&&|\|\|)\s*git\s+checkout(?:\s+(?:-b|-B|--track))?\s+(" + _BRANCH_TOK + r")",
        cmd,
    )
    if m:
        target = _strip_quotes(m.group(1))
        # Ignore commit-ish sentinels and pathspec separators.
        if target and target not in ("--", "HEAD", expected) and not target.startswith("-"):
            return (
                f"Branch guard: `git checkout {target}` would leave the "
                f"voyage branch `{expected}`. Stay on `{expected}` for "
                "the duration of this order."
            )

    # git switch [-c|-C|--create] <branch>
    m = re.search(
        r"(?:^|\s|;|&&|\|\|)\s*git\s+switch(?:\s+(?:-c|-C|--create|--detach))?\s+(" + _BRANCH_TOK + r")",
        cmd,
    )
    if m:
        target = _strip_quotes(m.group(1))
        if target and target != expected and not target.startswith("-"):
            return (
                f"Branch guard: `git switch {target}` would leave the "
                f"voyage branch `{expected}`."
            )

    # git push <remote> <branch>  or  git push <remote> HEAD:<branch>
    # Skip the read-only / metadata flags.
    push = re.search(
        r"(?:^|\s|;|&&|\|\|)\s*git\s+push\s+(\S+)(?:\s+(\S+))?",
        cmd,
    )
    if push:
        remote = push.group(1)
        refspec = push.group(2) or ""
        # If the second token is a flag (e.g. --tags) or absent, no target branch is named.
        if refspec and not refspec.startswith("-") and not remote.startswith("-"):
            target = refspec.split(":")[-1]  # "HEAD:other" → "other"; "main" → "main"
            target = _strip_quotes(target)
            if target and target != expected and target != "HEAD":
                return (
                    f"Branch guard: `git push {remote} {refspec}` targets "
                    f"`{target}`, which is not the voyage branch "
                    f"`{expected}`."
                )

    return ""
