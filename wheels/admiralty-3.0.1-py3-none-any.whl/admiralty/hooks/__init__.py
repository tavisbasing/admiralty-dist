# admiralty.hooks — Maestro hooks

from pathlib import Path


def find_admiralty_root(start_dir: str) -> "Path | None":
    """Walk up from start_dir to find an Admiralty workspace root.

    Checks for .adm/config/ (v2.0) or .admiralty/config/ (v1.x legacy fallback).
    Returns the workspace root path, or None if not found.
    """
    path = Path(start_dir).resolve()
    for p in [path, *path.parents]:
        if (p / ".adm" / "config").is_dir():
            return p
        if (p / ".admiralty" / "config").is_dir():
            return p
    return None
