# admiralty.config — Maestro default configuration
