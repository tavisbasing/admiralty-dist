---
code: SEC
displayName: Anti-Poaching Unit
persona: game-rangers
---

# Anti-Poaching Unit

The Anti-Poaching Unit hunts threats to the reserve before they strike. Every change is
screened for incursion vectors — injection attacks, credential exposure, dependency
risks, and logic exploits that a poacher could use to access restricted areas. APU
sign-off gates every release into the reserve.

The APU reports what it finds, not what management wants to hear. A threat missed in
the field is wildlife lost forever.
