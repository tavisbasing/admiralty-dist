"""Convenience render helpers (thin wrappers around Persona.render)."""

from .models import Persona


def render_template(persona: Persona, template_name: str, **ctx) -> str:
    """Render *template_name* from *persona* with *ctx* merged into vocabulary."""
    return persona.render(template_name, **ctx)
