"""Persona dataclass and related exceptions."""

from dataclasses import dataclass, field
from typing import Dict, List

from jinja2 import Undefined
from jinja2.sandbox import ImmutableSandboxedEnvironment


class PersonaSchemaError(Exception):
    """Raised when a persona JSON fails schema validation or cannot be parsed."""


def _plural_filter(value: str) -> str:
    """Naive English plural: append 's' unless already ends with 's'."""
    if value.endswith("s"):
        return value
    return value + "s"


@dataclass
class Persona:
    id: str
    display_name: str
    vocabulary: Dict[str, str]
    role_display: Dict[str, str]
    squad_names_list: List[str] = field(default_factory=lambda: [f"Squad {i}" for i in range(1, 6)])
    output_templates: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        # ImmutableSandboxedEnvironment blocks dunder-attribute gadgets that enable RCE
        # via operator-supplied persona JSON (SEC-MSO-2026-0001).
        env = ImmutableSandboxedEnvironment(undefined=Undefined)
        env.filters["plural"] = _plural_filter
        self._env = env
        self._compiled: Dict[str, object] = {
            key: env.from_string(tmpl)
            for key, tmpl in self.output_templates.items()
        }

    def term(self, key: str) -> str:
        """Look up a vocabulary term by key."""
        return self.vocabulary[key]

    def role_name(self, code: str) -> str:
        """Return the display name for a role code."""
        return self.role_display[code]

    def squad_names(self) -> List[str]:
        """Return the list of squad display names for slots 1-5."""
        return self.squad_names_list

    def render(self, template_name: str, **ctx) -> str:
        """Render an output template with the given context (vocabulary merged in)."""
        tmpl = self._compiled.get(template_name)
        if tmpl is None:
            raise KeyError(f"No output template '{template_name}' in persona '{self.id}'")
        merged = {**self.vocabulary, **ctx}
        return tmpl.render(**merged)

    def address_user(self) -> str:
        """Return the user-address string (renders the 'userAddressing' template)."""
        if "userAddressing" in self._compiled:
            return self.render("userAddressing")
        return self.vocabulary.get("userTitle", self.id)
