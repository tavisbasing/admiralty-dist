"""4-step persona resolution: env var → workspace → user-global → built-in default."""

import logging
import os
from pathlib import Path
from typing import Optional

import jinja2.exceptions

from .loader import PersonaSchemaError, load_builtin, load_persona_from_file
from .models import Persona

logger = logging.getLogger(__name__)

_DEFAULT_ID = "default"
_cached: Optional[Persona] = None


def _find_workspace_config() -> Optional[Path]:
    """Walk upward from cwd looking for .maestro/config/persona.json."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        candidate = parent / ".maestro" / "config" / "persona.json"
        if candidate.exists():
            return candidate
        # Stop at filesystem root
        if parent == parent.parent:
            break
    return None


def _load_safe(path: Path, label: str) -> Optional[Persona]:
    """Try to load a persona from *path*; return None and log a warning on failure."""
    try:
        persona = load_persona_from_file(path)
        # Probe the userAddressing template (most commonly rendered) to detect
        # sandboxed-template violations before the persona enters active use.
        persona.address_user()
        return persona
    except (PersonaSchemaError, OSError, jinja2.exceptions.SecurityError) as exc:
        logger.warning("Persona load failed (%s): %s — falling back to default", label, exc)
        return None


def resolve() -> Persona:
    """Resolve and return the active persona following the 4-step order.

    Result is cached for the process lifetime. Call reset() to clear the cache.
    """
    global _cached
    if _cached is not None:
        return _cached

    _cached = _resolve_uncached()
    return _cached


def _resolve_uncached() -> Persona:
    # Step 1 — MAESTRO_PERSONA env var
    env_id = os.environ.get("MAESTRO_PERSONA", "").strip()
    if env_id:
        try:
            return load_builtin(env_id)
        except PersonaSchemaError:
            logger.warning(
                "MAESTRO_PERSONA='%s' is unknown or invalid — falling back to default", env_id
            )
        # Env var set but unresolvable → fall through to default (never crash)

    # Step 2 — workspace .maestro/config/persona.json
    ws_path = _find_workspace_config()
    if ws_path is not None:
        persona = _load_safe(ws_path, "workspace")
        if persona is not None:
            return persona

    # Step 3 — user-global ~/.maestro/config/persona.json
    user_path = Path.home() / ".maestro" / "config" / "persona.json"
    if user_path.exists():
        persona = _load_safe(user_path, "user-global")
        if persona is not None:
            return persona

    # Step 4 — built-in default
    return load_builtin(_DEFAULT_ID)


def reset() -> None:
    """Clear the cached persona (useful in tests)."""
    global _cached
    _cached = None
