# Migration Guide: v2.8.x → v3.0.0 (Maestro)

This guide covers everything an operator or PSG customer needs to upgrade from
Admiralty v2.8.x to Maestro v3.0.0. All changes are backward-compatible during
the v3.0–v3.1 window; hard errors land in v3.2 and removals land in v4.0.

---

## 1. Install

```bash
pip install --upgrade maestro==3.0.0 \
    --extra-index-url https://maestrodevs.github.io/simple/
```

Verify:

```bash
mso version
# Maestro v3.0.0
```

**Backward-compat note:** The `admiralty` PyPI package continues to work as a
shim that re-exports the `maestro` package. No requirement file changes are
needed for existing deployments:

```bash
pip install admiralty   # still resolves — installs the maestro shim
adm version            # → Maestro v3.0.0 (via shim)
```

The `adm`, `admiralty`, and `maestro` CLI entry points are all registered and
all route to the same command implementations.

---

## 2. What Changed

The table below summarises every user-facing rename. The **Back-compat** column
describes what happens if you use the old value in v3.x.

| Concept | v2.x value | v3.x value | Back-compat in v3.x |
|---|---|---|---|
| Brand name | Admiralty | Maestro | Aliases present; WARN emitted |
| PyPI package | `admiralty` | `maestro` | Shim package forwards to `maestro` |
| Primary CLI binary | `adm` | `mso` | `adm` still registered; works |
| Alt CLI aliases | `admiralty` | `maestro`, `mso` | All four binaries active |
| Workspace dir | `.admiralty/` | `.adm/` | `.admiralty/` auto-detected with WARN |
| Default config dir | `.admiralty/config/` | `.adm/config/` | Dual-read during migration window |
| Active orders dir | `.admiralty/orders/active/` | `.adm/orders/active/` | Dual-read |
| Crew runtime dir | `.admiralty/crews/` | `.adm/crews/` | Dual-read |
| Env var prefix | `ADMIRALTY_*` | `MAESTRO_*` | Old vars accepted; WARN emitted |
| Env: voyage branch | `ADMIRALTY_VOYAGE_BRANCH` | `MAESTRO_VOYAGE_BRANCH` | Dual-read |
| Env: branch guard | `ADMIRALTY_BRANCH_GUARD_BYPASS` | `MAESTRO_BRANCH_GUARD_BYPASS` | Dual-read |
| Env: repo path | `ADMIRALTY_REPO_PATH` | `MAESTRO_REPO_PATH` | Dual-read |
| Env: temp dir | `ADMIRALTY_TEMP` | `MAESTRO_TEMP` | Dual-read |
| Role codes (legacy) | `NAV`, `SHP`, `ENG`, `LOG`, `WTC`, `SGN`, `CPT` | `PLN`, `BLD`, `TST`, `DOC`, `SEC`, `REL`, `LEAD` | Legacy codes work; WARN emitted |
| Workflow noun: crew | crew | squad (display) / crew (internal) | Both accepted |
| Workflow noun: dispatch | dispatch | dispatch | No change |
| Import path | `from admiralty import ...` | `from maestro import ...` | `admiralty` shim re-exports `maestro` |
| Global registry | `~/.admiralty/projects.json` | `~/.maestro/projects.json` | Migrated on first `mso` run |

---

## 3. Workspace Migration

Your existing `.adm/` workspace works without any changes. The steps below are
**optional** — they clean up legacy `.admiralty/` directories that pre-date the
v2.5 workspace rename.

### 3.1 Back up first

```bash
mso backup
# Creates: ~/.maestro/backups/maestro-backup-<timestamp>.tar.gz
```

Or manually:

```bash
cp -r .adm/ .adm-backup-$(date +%Y%m%d)/
```

### 3.2 Run the migration command

```bash
mso migrate
```

What `mso migrate` does:

1. Detects any `.admiralty/` directory at the project root.
2. Copies its contents into `.adm/` (no destructive writes — existing `.adm/`
   files are never overwritten).
3. Renames any `ADMIRALTY_*` env vars found in `.admiralty/config/` to
   `MAESTRO_*` (writes a diff to stdout for review).
4. Updates `~/.maestro/projects.json` if the project is registered.
5. Leaves `.admiralty/` intact — you delete it once satisfied.

### 3.3 Verify

```bash
mso status --once
# All crews/squads should appear; no "legacy path" WARNs remain.
```

### 3.4 Delete the legacy directory (optional)

Once you have confirmed everything works:

```bash
rm -rf .admiralty/
```

`.adm/` is the canonical workspace from this point forward.

---

## 4. Env Var Migration

All `ADMIRALTY_*` variables are accepted in v3.x (with a deprecation WARN).
Update your shell profile, CI environment, and any wrapper scripts to use the
`MAESTRO_*` equivalents.

| Old variable | New variable | Purpose |
|---|---|---|
| `ADMIRALTY_VOYAGE_BRANCH` | `MAESTRO_VOYAGE_BRANCH` | Active voyage branch for branch guard |
| `ADMIRALTY_BRANCH_GUARD_BYPASS` | `MAESTRO_BRANCH_GUARD_BYPASS` | Set to `1` to bypass branch guard (escape hatch) |
| `ADMIRALTY_REPO_PATH` | `MAESTRO_REPO_PATH` | Absolute path to the managed repo (injected by dispatcher) |
| `ADMIRALTY_TEMP` | `MAESTRO_TEMP` | Crew temporary directory |
| `ADMIRALTY_CREW_ID` | `MAESTRO_CREW_ID` | Crew/squad identifier |
| `ADMIRALTY_ORDER_ID` | `MAESTRO_ORDER_ID` | Active order identifier |
| `ADMIRALTY_LICENCE_KEY` | `MAESTRO_LICENCE_KEY` | Licence key (alternative to interactive activation) |
| `ADMIRALTY_LOG_LEVEL` | `MAESTRO_LOG_LEVEL` | Log verbosity (`DEBUG`, `INFO`, `WARN`, `ERROR`) |
| `ADMIRALTY_BRIDGE_TOKEN` | `MAESTRO_BRIDGE_TOKEN` | Slack bridge bot token |
| `ADMIRALTY_BRIDGE_CHANNEL` | `MAESTRO_BRIDGE_CHANNEL` | Slack bridge channel ID |

### Sample export block for shell profiles

Add to `~/.bashrc`, `~/.zshrc`, or your CI environment configuration:

```bash
# Maestro v3 — replaces ADMIRALTY_* vars
export MAESTRO_LICENCE_KEY="<your-key>"
export MAESTRO_LOG_LEVEL="INFO"

# Remove or comment out old vars:
# export ADMIRALTY_LICENCE_KEY="<your-key>"
```

For CI pipelines (GitHub Actions example):

```yaml
env:
  MAESTRO_LICENCE_KEY: ${{ secrets.MAESTRO_LICENCE_KEY }}
  # ADMIRALTY_LICENCE_KEY: ${{ secrets.ADMIRALTY_LICENCE_KEY }}  # remove after migration
```

---

## 5. Role-Code Migration

Maestro v3 ships with both the legacy nautical role codes and the new
acronym-based codes. Custom orders authored against legacy codes continue to
dispatch correctly, but emit a deprecation WARN in fleet logs.

| Legacy code (v2.x) | New code (v3.x) | Role |
|---|---|---|
| `NAV` | `PLN` | Planner |
| `SHP` | `BLD` | Builder |
| `ENG` | `TST` | Tester |
| `LOG` | `DOC` | Documenter |
| `WTC` | `SEC` | Security reviewer |
| `SGN` | `REL` | Release manager |
| `CPT` | `LEAD` | Lead / orchestrator |

### Updating existing orders

In your order JSON files, change:

```json
{ "role": "NAV" }
```

to:

```json
{ "role": "PLN" }
```

There is no automated mass-rename tool — update orders at your own pace before
v3.2 (at which point legacy codes become hard errors in `mso dispatch`).

### Updating CLAUDE.md role references

If your `CLAUDE.md` or `.adm/claude.md` files reference legacy codes by name,
replace them with the new codes. The role definitions live in
`maestro/roles/` — each `.yaml` file uses the new code as its filename
(`pln.yaml`, `bld.yaml`, etc.).

---

## 6. Persona Setup

Maestro v3 ships four built-in personas: `nautical` (default), `corporate`,
`startup`, and `default` (neutral/no character).

### Interactive setup

```bash
mso setup
# Follow the prompts to select a persona and configure your workspace.
```

### Manual configuration

Create or edit `.adm/config/workspace.json`:

```json
{
  "persona": "nautical"
}
```

Valid values: `nautical`, `corporate`, `startup`, `default`.

### Per-command override

```bash
mso dispatch --persona corporate
mso status --persona default
```

See [PERSONAS.md](PERSONAS.md) for the full persona reference including custom
persona authoring.

---

## 7. Deprecation Timeline

| Version | Legacy alias behaviour |
|---|---|
| **v3.0** | All legacy aliases (`adm`, `admiralty`, `ADMIRALTY_*`, legacy role codes, `.admiralty/`) work. Deprecation WARNs emitted to stderr and fleet log. |
| **v3.1** | Same as v3.0. WARNs become more prominent (shown at dispatch start and `mso status`). |
| **v3.2** | Legacy aliases become **hard errors**. `mso dispatch` exits non-zero if any `ADMIRALTY_*` env var is set or any legacy role code appears in an order. CI pipelines will fail until migrated. |
| **v4.0** | Legacy aliases and shim package removed entirely. The `admiralty` PyPI package is delisted. |

**Recommended migration window:** Complete all env var and role-code migrations
before the v3.2 release. Monitor the [changelog](../CHANGELOG.md) for the v3.2
release date.

---

## 8. Rollback Procedure

If v3.0.0 causes a problem in your environment, you can pin back to v2.8.x in
minutes. Your `.adm/` workspace is never modified destructively by `mso migrate`,
so rollback is always safe.

### Step 1 — Pin the old package

```bash
pip install 'admiralty<3' \
    --extra-index-url https://maestrodevs.github.io/simple/
```

This installs the last v2.8.x release of the `admiralty` package.

### Step 2 — Verify the old CLI is active

```bash
adm version
# Admiralty v2.8.x
```

### Step 3 — Restore your workspace if needed

If you ran `mso migrate` and deleted `.admiralty/`, restore from backup:

```bash
mso restore ~/.maestro/backups/maestro-backup-<timestamp>.tar.gz
# or manually:
cp -r .adm-backup-<date>/ .adm/
```

`.adm/` was never removed by `mso migrate` — only `.admiralty/` was the legacy
path. If you did not delete `.adm/`, no restore is needed.

### Step 4 — Reset env vars

Revert your shell profile and CI environment to `ADMIRALTY_*` variable names
(or leave `MAESTRO_*` — v2.8.x ignores unknown env vars harmlessly).

### Step 5 — Report the issue

Open an issue or contact support so the blocker can be tracked and fixed before
re-attempting the upgrade.

---

## 9. Known Issues / Heads-Up

The following items were identified during the VOY-MSO-2026-0040 rebrand voyage
and are relevant to operators upgrading to v3.0.0.

### 9.1 Dual-read window is limited to v3.x

The dual-read fallback (`.admiralty/` alongside `.adm/`, `ADMIRALTY_*` env
vars, legacy role codes) is guaranteed through the v3.x release series only.
Hard errors land in v3.2. Do not plan your migration for "sometime in v3" —
target completion before v3.2.

### 9.2 `mso migrate` does not move gitignored paths

Crew runtime directories (`.admiralty/crews/`, `.admiralty/logs/`,
`.admiralty/bridge/`) are gitignored and are **not** copied by `mso migrate`.
These are ephemeral; any in-flight crew state should be allowed to complete or
be manually stopped before migration.

### 9.3 Global registry migration is one-time

On the first `mso` command after upgrading, the registry at
`~/.admiralty/projects.json` is copied to `~/.maestro/projects.json`. If you
downgrade and re-upgrade, the copy runs again but does not overwrite existing
entries in `~/.maestro/projects.json`.

### 9.4 Shim package dependency resolution

If your `requirements.txt` pins `admiralty==2.8.x` explicitly, the shim
package in v3 will satisfy the import (`from admiralty import ...` continues
to work) but `adm version` will report `Maestro v3.0.0`, not `Admiralty
v2.8.x`. Update your pin to `maestro==3.0.0` once you are ready to fully
commit to v3.

### 9.5 Persona in CLAUDE.md

If your `CLAUDE.md` or `.adm/claude.md` references the old persona inline
(e.g. describes the AI as "Admiralty's Quartermaster" or uses the old brand
name), update those files to use the persona-aware language from the v3
templates. Run `mso docs personas` for the updated wording.

### 9.6 `mso licence activate` replaces `adm licence activate`

Both commands work, but internal licence storage moved from
`~/.admiralty/licence.json` to `~/.maestro/licence.json`. If you have a
licence already activated under v2.8.x, `mso` will detect and migrate it
automatically on first run. If the automatic migration fails (e.g. permission
error), run:

```bash
mso licence activate <YOUR-KEY>
```

---

*For questions or issues with the v3 migration, open a support ticket or visit
the [Troubleshooting guide](TROUBLESHOOTING.md).*
