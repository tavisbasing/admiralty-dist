# Maestro vs Everything Claude Code — Positioning & Comparison

**Source of truth:** [.adm/reports/investigation/INV-ADM-2026-0001.md](../.adm/reports/investigation/INV-ADM-2026-0001.md)  
**Date:** 2026-04-25  
**Version:** Maestro v2.2.0 | ECC v1.10.0 (ecc-universal)

---

## What Makes Maestro Different

Before comparing, here is what Maestro does that no skill plugin or single-session agent system can do.

### 1. Multi-Process Fleet Orchestration

Maestro dispatches up to 5 **independent Claude Code processes** simultaneously — each a fully isolated crew with its own shell, workspace, and lifecycle. Work is parallelised, queued, and sequenced by the Fleet Admiral (`fleet_runner.py`). A session-scoped plugin cannot replicate this; it operates within a single context window.

### 2. Chain of Command

```
Captain (Human) → Quartermaster (Claude) → Fleet Admiral (adm dispatch) → Crews
```

Authority flows in one direction. Crews cannot escalate above their role. The Captain approves; the Fleet Admiral dispatches; crews execute. This model enforces accountability in a way that ad-hoc subagent delegation does not.

Full specification: [`maestro/docs/CHAIN-OF-COMMAND.md`](../maestro/docs/CHAIN-OF-COMMAND.md)

### 3. Role Sequencing & Quality Gates

Roles execute in dependency order. A COX (Coxswain) cannot deploy until BOS (Bosun) has validated. An SHP (Shipwright) cannot merge until NAV (Navigator) has planned. Dependency chains are declared in order files (`dependsOn`) and enforced by the dispatcher — not by convention.

This is categorically different from 48 specialised agents you can call in any order.

### 4. Token Cost Attribution

`adm usage --voyage VOY-ADM-2026-0001` breaks down token spend by voyage, order, and crew. Every API call is accounted for. There is no equivalent in skill-plugin systems.

### 5. Voyage & Order Schema

Work is structured as **Voyages** (objectives) containing **Orders** (role-specific tasks). Each order carries:
- Role assignment (`NAV`, `SHP`, `BOS`, `SCR`, `LKT`, `COX`)
- Acceptance criteria (validated before role-handoff)
- Dependency declarations
- Token usage records

This schema produces a durable, auditable record of what was planned, by whom, and what it cost.

### 6. Structured Handoff System

When a crew completes an order, it writes a **handoff document** to `.adm/handoffs/`. The next crew reads this as its starting context. Knowledge is explicit, persistent, and human-readable — not implicit session state that disappears when a context window closes.

### 7. Managed Repo Lifecycle

Maestro manages branch checkout, per-crew workspace isolation, commit, and PR creation for crews — not just the prompts. ECC provides workflow prompts; Maestro provides workflow execution infrastructure.

### 8. Scalable to Project Complexity

A voyage can span many context windows across many crews without losing coherence. Projects that exceed a single session's limits are handled by crew queuing, wave promotion, and role-to-role handoffs — not by hoping the model doesn't hallucinate what happened 50,000 tokens ago.

---

## The 12-Dimension Comparison Matrix

| # | Dimension | Maestro v2.2.0 | Everything Claude Code | Delta | Severity | Recommendation |
|---|-----------|------------------|------------------------|-------|----------|-----------------|
| 1 | **Architecture & Orchestration** | Multi-agent fleet dispatcher with formal chain-of-command: Captain → Quartermaster → Fleet Admiral → 5 parallel crews. Role-based sequencing, dependency graphs, wave promotion. (`admiralty/core/fleet_runner.py`, `admiralty/core/crew.py`) | Single-agent skill/hook system within one Claude session. Agent delegation model (48 agents) for task-specific roles, but no formal dispatch queue or orchestration layer. (Repository structure: `agents/`, `hooks/`, `skills/`) | **Major architectural difference.** Maestro dispatches *multiple independent Claude sessions* with crew identity and lifecycle tracking; ECC operates *within a single session* with subagent delegation. | MAJOR | **REJECT** — ECC's single-session model is fundamentally incompatible with Maestro's multi-crew orchestration. Maestro's chain-of-command requires persistent crew state and inter-crew handoffs. |
| 2 | **Agent/Role Catalogue** | 6 fixed roles with defined responsibilities: NAV (planning), SHP (dev), BOS (QA), SCR (docs), LKT (security), COX (deployment). Role-to-role handoffs via `.adm/handoffs/`. Model selection per role: Sonnet/Haiku/Opus. (`admiralty/core/crew.py` lines 19–20) | 48 specialized agents covering code review, build error resolution, security auditing, documentation, TDD guidance, language-specific reviewers. Extensible agent system in `agents/` directory. | **Philosophically opposed.** Maestro pre-defines 6 roles with formal sequencing; ECC provides 48 specialized agents that delegate *within* a session. Maestro's roles are *sequential orchestration*; ECC's agents are *parallel capability*. | MAJOR | **REJECT** — Maestro's fixed role set is intentional: it enforces quality gates and dependency ordering. Adopting ECC's agent library would break the chain-of-command model. |
| 3 | **Skill / Slash-Command Surface** | Roles execute via order prompts (`.adm/orders/`), not slash commands. Crews read contextual instructions from CLAUDE.md layer 2 (`.adm/claude.md`), orders (role-specific prompts), and plan documents (`.adm/plans/`). No slash-command surface — commands are CLI: `adm dispatch`, `adm status`, `adm usage`, etc. | 183+ skills organized by domain (backend patterns, testing, DeFi, healthcare, etc.). Skills are SKILL.md files with YAML frontmatter. 79 legacy slash commands provided for compatibility but deprecated in favor of skills. (Repository structure: `skills/`, `commands/`) | **Incompatible paradigm.** Maestro has no user-facing slash-command/skill surface — crews read roles from configuration and prompts. ECC's entire workflow is skill-driven within Claude Code. | MINOR | **REJECT** — Skills are for single-session prompt engineering; Maestro's order/prompt system already covers this via `.adm/plans/` and role-specific instructions. Adding ECC's skill surface would require fundamental architectural changes. |
| 4 | **Hook Ecosystem** | 6 hook types: pretool (role permission enforcement), posttool (artifact scanning), stop (Ralph Wiggum iteration control), notification (Slack bridge), bridge_question (Slack two-way), session lifecycle (start/end). Configured via `settings.json` hooks field. (`admiralty/hooks/pretool.py`, `admiralty/hooks/posttool.py`, `admiralty/hooks/stop.py`) | 8 event types in Claude Code (PreToolUse, PostToolUse, Stop, SessionStart, SessionEnd, PreCompact, etc.). 20+ events in Cursor. Hooks are Node.js scripts reading JSON stdin, writing JSON stdout. Customizable via env vars: `ECC_HOOK_PROFILE`, `ECC_DISABLED_HOOKS`. Quality-gate enforcement via blocking PreToolUse. | **Complementary in scope, different in language & philosophy.** Both enforce pre-execution gates; Maestro's hooks block at crew level, ECC's block at tool level. Maestro uses Python; ECC uses Node.js. Maestro's hooks are crew-aware (read ADMIRALTY_CREW env); ECC's are session-agnostic. | MINOR | **ADAPT** — ECC's secret detection and code formatting hooks (`hooks/`, Node.js scripts) could be ported to Python and integrated into Maestro's pretool/posttool pipeline. Recommend: audit which ECC hooks (e.g., secret scanning) are missing from Maestro, port highest-value ones as Python modules. |
| 5 | **MCP Server Integration** | Configured via `settings.json` in `.claude/settings.json`. Servers listed in `mcp_servers` object. Example: `{"command": "npx", "args": ["@modelcontextprotocol/server-github"]}`. No explicit server manifest or registry — relies on Claude Code's MCP subsystem. | Explicit MCP configs in `mcp-configs/` directory (server manifests). 15+ servers pre-configured. Servers discoverable via registry, with risk profiling for each server. AgentShield integration for MCP security scanning. (Repository structure: `mcp-configs/`) | **ECC provides MCP registry; Maestro relies on Claude Code's MCP discovery.** ECC's mcp-configs/ acts as a curated server manifest with security profiles. Maestro has no analogous registry — configs are per-project in `.claude/settings.json`. | MINOR | **ADOPT** — ECC's MCP manifest pattern (`mcp-configs/`) is superior for multi-project scenarios. Recommend: create `.adm/config/mcp-servers.json` as a canonical MCP registry for Maestro projects, with server profiles, risk levels, and per-role permissions. Migrate existing `.claude/settings.json` entries to this canonical source. |
| 6 | **Multi-Platform Support** | Claude Code only. No native Cursor, Codex (macOS app), OpenCode, or Antigravity support. Crews run via Claude Code CLI (`claude code`). Architecture is Claude Code-specific (hook event types, settings.json format, env var names). | 4-platform native support: Claude Code, Cursor (15 hook events), Codex (macOS app + CLI with TOML config), OpenCode (31+ command shims). Platform-specific configs in `.claude/`, `.cursor/`, `.codex/`, `.opencode/` directories. | **Strategic difference.** Maestro is deliberately Claude Code-only; ECC aims for vendor independence. Maestro's model selection (Sonnet/Haiku/Opus) depends on Anthropic SDK — incompatible with non-Claude platforms. | MAJOR | **REJECT** — Maestro's deep Anthropic integration and role-based model selection are incompatible with multi-platform support. This is a deliberate architectural choice to optimize for Claude's capabilities. Multi-platform support would require abstracting model selection and hook events. |
| 7 | **Token / Cost Controls** | **Comprehensive tracking:** `adm usage --summary` aggregates token spend by voyage, order, crew. Token data stored in `.adm/usage/orders/{ORDER-ID}.json`. Per-voyage reports via `adm usage --voyage VOY-ID`. (`admiralty/core/fleet_usage_tracker.py` lines 1–50). **No budget enforcement** — tracking-only, no hard limits or alerts. | **No native token tracking.** ECC mentions "recommends Sonnet for 80% of tasks, reserves Opus for complex reasoning" but does not provide token dashboards, budgets, or per-agent cost attribution. Emphasis is on model *selection* strategy, not cost *management*. | **Maestro has complete token visibility; ECC has no cost control.** Maestro provides voyage-level cost breakdowns; ECC provides only strategic guidance. | MINOR | **ALREADY-COVERED** — Maestro's token tracking (`fleet_usage_tracker.py`, `.adm/usage/`) is unique and valuable. ECC has no equivalent. No action needed. Consider adding budget enforcement (hard limits per voyage) as a future enhancement. |
| 8 | **Security Posture** | **Limited scanning.** Pretool hook enforces role-based file access (`admiralty/hooks/pretool.py` lines 26–37: ALWAYS_ALLOWED paths). No OWASP scanning, no secret detection, no code vulnerability analysis. Posttool hook performs artifact inspection (scans for debugging, unused imports) but no security-focused scanning. **Audit log:** voyage/order lifecycle tracked in JSON state files (`.adm/orders/`, `.adm/voyages/`). No immutable audit trail. | **Comprehensive security.** AgentShield integration provides 102+ static analysis rules, secret detection, OWASP/CWE coverage, adversarial red-team analysis. MCP server risk profiling. Pre-execution secret scanning in hooks. Post-execution artifact scanning. (`hooks/` directory with Node.js implementations) | **ECC is significantly stronger on security.** Maestro has basic file-level RBAC; ECC has deep code vulnerability scanning, secret patterns, and adversarial testing. | MAJOR | **ADOPT** — ECC's AgentShield security framework is a major gap in Maestro. Recommend: integrate OWASP/CWE scanning into LKT role. Port ECC's secret detection patterns to Python pretool hook. Implement MCP risk profiling. Priority: secret detection (critical), OWASP scanning (high), adversarial red-team analysis (medium). |
| 9 | **Memory & Context Model** | **Structured memory:** `.adm/plans/` (Navigator planning), `.adm/handoffs/` (role-to-role transition docs), voyage orders (persistent state in `.adm/orders/`), ralph-state.md (per-crew iteration tracking). Memory is file-based, human-readable, and used for inter-crew knowledge transfer. **No automated learning:** Patterns are captured via explicit handoff documents, not extracted from sessions. | **Instinct system:** Extracts patterns from sessions into reusable instincts with confidence scoring. Continuous learning — skills improve over time through recorded evidence from prior sessions. Context compaction via precompact hook. **No formal handoff/planning** — memory is session-internal; next session has no access to prior session's reasoning. | **Opposite models.** Maestro uses explicit file-based handoffs for inter-crew knowledge; ECC uses implicit session-internal instincts. Maestro's memory is *persistent across sessions*; ECC's is *lost at session end*. | MAJOR | **ALREADY-COVERED** — Maestro's handoff system (`maestro/docs/CHAIN-OF-COMMAND.md`, `.adm/handoffs/`) is superior for multi-crew orchestration. ECC's instinct system is optimized for single-session learning and is incompatible with Maestro's crew-based model. No adoption recommended. |
| 10 | **Distribution & Install** | **pip package + project scaffolding:** `pip install maestro --extra-index-url https://maestrodevs.github.io/simple/` → `adm init --project ACRONYM` → `.adm/` structure bootstrapped. All roles available immediately. License activation required (proprietary). No plugin marketplace — direct GitHub installation. No cross-project sharing (each project has own `.adm/`). | **Plugin marketplace install:** `/plugin install everything-claude-code` (recommended in Claude Code). Manual install: clone repo and copy agents/skills/rules/hooks selectively. Cross-IDE configs enable partial installation (e.g., only agents, only skills). Distributed via npm as ecc-universal package. MIT license. Community-driven. | **Enterprise vs community model.** Maestro is a proprietary pip package with formal release cycles; ECC is an open-source plugin with community contributions. Maestro enforces full install (all 6 roles); ECC allows selective feature install (only skills, only hooks). | MAJOR | **REJECT** — Maestro's pip-based distribution is intentional for IP protection and version control. ECC's plugin marketplace model would require open-sourcing the framework. Distribution philosophy is incompatible with Maestro's licensing and commercial positioning. |
| 11 | **Documentation Surface** | **3-layer CLAUDE.md model:** Layer 1 (project CLAUDE.md — architecture/stack), Layer 2 (`.adm/claude.md` — Maestro integration/naming), Layer 3 (pip package docs — system spec). (`admiralty/templates/claude-project.md.j2`, `admiralty/templates/claude-adm.md.j2`, `maestro/docs/`). Consumer docs in `maestro/docs/` (QUICKSTART, GETTING-STARTED, CLI-REFERENCE, ROLES-GUIDE, OPERATOR-GUIDE, OWNER-GUIDE). | **Layered documentation:** README.md, AGENTS.md, RULES.md, CLAUDE.md, CONTRIBUTING.md. Guide docs: the-shorthand-guide.md, the-longform-guide.md, the-security-guide.md, the-troubleshooting.md. Language-specific docs in `docs/` directory. `docs/examples/` with worked examples. Repository markdown lint enforced. | **Complementary approaches.** Maestro emphasizes CLAUDE.md as executable context; ECC emphasizes markdown guides and examples. Both have good structure. Maestro's docs are pip-delivered; ECC's are repo-integrated. | INFO | **ALREADY-COVERED** — Both documentation models are adequate for their respective audiences. ECC's shorthand/longform/security guides are well-organized; Maestro's CLAUDE.md layering is more context-aware. No action needed. |
| 12 | **Testing** | **Limited test coverage.** Core modules (`fleet_runner.py`, `crew.py`, `fleet_monitor.py`) lack unit tests. Integration tests are manual (test via `adm dispatch --max-crews 1`). No CI/CD pipeline visible in main repo (test runs are crew-internal via BOS role). No test fixtures or mocking. Quality gates are manual (BOS role validation, COX deployment checks). | **Comprehensive test suite.** Node.js test harness for agents, commands, rules, skills, and hooks. ESLint and markdown linting enforced. Schema validation (JSON Schema via ajv). Test directory: `tests/`. CI/CD: `.github/workflows/` (not visible via WebFetch, inferred from repository structure). Code coverage tracking. Automated validation on merge. | **ECC has formalized testing; Maestro relies on crew-driven QA.** ECC uses automated linting/validation; Maestro uses BOS role (manual review). ECC's test harness is developer-facing; Maestro's is user-facing (through BOS QA process). | MAJOR | **ADAPT** — Maestro should formalize unit tests for core modules. Recommend: add pytest test suite for `fleet_runner.py`, `crew.py`, `fleet_monitor.py`. Integrate into CI/CD via GitHub Actions. Target: 70% coverage for core dispatch logic. This complements (not replaces) the BOS QA role — automated tests catch regressions; BOS validates business logic. |

---

## Where Everything Claude Code Is Ahead

Maestro is built for a different job than ECC, but honesty about gaps serves our users better than silence.

### Security Scanning

ECC's AgentShield integration (102+ OWASP/CWE rules, secret detection patterns, adversarial red-team analysis) is substantially more comprehensive than Maestro's current pretool RBAC. We enforce *who can write where*; we do not yet catch *what* is being written. This is a critical gap — secret credentials written by any crew are not detected before commit.

**Status:** Planned — see candidate voyage VOY-ADM-2026-0022 (secret detection) and VOY-ADM-2026-0024 (OWASP/CWE scanning).

### MCP Server Governance

ECC ships a curated manifest of 15+ MCP servers with security risk profiles. Maestro currently has no canonical MCP registry — each project manages server config independently in `.claude/settings.json`. For multi-project organisations, this means no centralised governance over which servers are approved or what risk level they carry.

**Status:** Planned — see candidate voyage VOY-ADM-2026-0023 (MCP registry).

### Automated Test Coverage

ECC enforces tests on merge via CI/CD, with JSON schema validation and markdown linting. Maestro's core dispatch modules (`fleet_runner.py`, `crew.py`, `fleet_monitor.py`) have no unit test suite. Quality gates are crew-driven (BOS validation), which is right for business logic but insufficient for regression prevention.

**Status:** Planned — see candidate voyage VOY-ADM-2026-0025 (unit test suite + CI/CD).

---

## Roadmap Closure

The gaps above are documented honestly because we have concrete plans to close them. The voyage plans referenced below are live roadmap documents:

| Gap | Planned Voyage |
|-----|----------------|
| Secret detection (critical) | [VOY-ADM-2026-0022](../.adm/plans/) — candidate |
| MCP server registry | [VOY-ADM-2026-0023](../.adm/plans/) — candidate |
| OWASP/CWE scanning | [VOY-ADM-2026-0024](../.adm/plans/) — candidate |
| Unit test suite + CI/CD | [VOY-ADM-2026-0025](../.adm/plans/) — candidate |
| Enterprise hardening (audit trail, secrets mgmt) | [PLAN-VOY-ADM-2026-0020](../.adm/plans/PLAN-VOY-ADM-2026-0020.md) — active roadmap |

---

## Summary

Maestro and Everything Claude Code are not competitors — they solve different problems.

| | Maestro | Everything Claude Code |
|--|-----------|------------------------|
| **Best for** | Coordinated teams, complex multi-crew projects, cost accountability | Individual developers, quick workflow reuse, cross-IDE flexibility |
| **Orchestration** | Multi-process fleet with chain-of-command | Single-session subagent delegation |
| **Quality gates** | Enforced role sequencing, acceptance criteria | Optional, convention-based |
| **Cost tracking** | Per-voyage, per-order, per-crew attribution | None |
| **Memory** | Persistent handoff documents across crews | Session-internal, ephemeral |
| **Security scanning** | Basic RBAC; gaps being closed | AgentShield: 102+ OWASP/CWE rules |
| **Distribution** | pip package, proprietary | Plugin marketplace, MIT |

If you need *orchestration, accountability, and cost visibility* across a team and a complex project lifecycle, Maestro is the right tool. If you need *a rich library of workflow prompts* that work in any IDE you happen to be using today, ECC is the right tool.

---

*Source of truth for all findings: [.adm/reports/investigation/INV-ADM-2026-0001.md](../.adm/reports/investigation/INV-ADM-2026-0001.md)*
