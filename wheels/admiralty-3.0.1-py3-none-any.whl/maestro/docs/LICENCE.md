# Maestro licence — activation, status, recovery

> Customer-facing reference for the `adm licence` CLI. The CLI talks to **`api.polar.sh` directly** — Maestro does not operate any licence-server infrastructure. Polar handles subscription billing, key issuance, and key state (granted / revoked / expired); the CLI reads that state via the Polar API.

## What a licence key is

A 26-character base32 string Polar issues to you on subscription. Looks like `adm_lic_AB12CD34EF56GH78IJ90KL`. **Treat it like an API token** — anyone with the key can activate Maestro as you, until you deactivate.

## Activate

```bash
adm licence activate <KEY>
```

What happens:
1. The CLI calls Polar's `customers/{cid}/license-keys/{key}/validate` endpoint to confirm the key is granted.
2. On success, your machine writes `~/.maestro/licence.json` (mode 0600) signed with a per-customer secret stored in your OS keychain (Keychain on macOS, Credential Manager on Windows, libsecret on Linux).
3. From now on, `adm` commands run normally.

**Activation requires the internet.** Without an online round-trip we can't trust the key.

### CI / non-interactive activation

```bash
ADMIRALTY_LICENCE_KEY=adm_lic_xxxxx adm <any-command>
```

The CLI activates on first run if no record is present. Useful for ephemeral build agents.

## Status

```bash
adm licence status         # human text
adm licence status --json  # JSON for scripts
```

Shows your tier, customer ID, issue date, expiry, last-validated time, and offline-grace deadline.

## Force a re-check

```bash
adm licence revalidate
```

Skips the 24-hour cache and calls Polar immediately. Use this if you've just renewed a subscription and want to refresh `expires_at` straight away.

> **Test-only:** `adm licence revalidate --offline-mark-stale` rewinds your local `last_validated_at` so the next `adm` run exercises the offline-grace path. Refuses to run unless `ADMIRALTY_LICENCE_TEST_FLAGS=1` is set in your shell. Used during the live-test plan; not for everyday use.

> **Polar bypass for pre-launch testing:** set `ADMIRALTY_LICENCE_FAKE_ACTIVATION=1` to skip the Polar API call entirely on `activate` and `revalidate`. The CLI synthesises a real-shape signed record (1-year Pro tier, customer ID prefixed `cust_FAKE_`). All other behaviour — HMAC tamper detection, keychain binding, offline grace, status banner — is unchanged. `adm licence status` shows `[FAKE ACTIVATION]` instead of `[TEST MODE]` so the synthetic state is obvious. Use this when Polar is unreachable (e.g. account under review) and you need to verify the install / activate / status / deactivate flow on a fresh machine.

## Deactivate

```bash
adm licence deactivate
```

Removes `~/.maestro/licence.json` and the keychain entry. **Does not** cancel your Polar subscription — manage that at https://polar.sh.

## Offline grace

After every successful online validation you get **14 days** of offline grace. During the window:

- If the network's down or Polar is degraded, `adm` keeps working with a warning banner like:
  > `⚠ Couldn't reach the licence backend; running on offline grace (10 days remaining). Reconnect to revalidate.`
- Reconnecting refreshes the window automatically the next time `adm` runs.
- Past 14 days with no online check → `adm` refuses to start until you connect or run `adm licence revalidate`.

For longer offline operation, see [Air-gapped operation](AIR-GAPPED.md).

## Tamper detection

If `~/.maestro/licence.json` is edited or copied from another machine, `adm` refuses to start with:

```
Licence file signature mismatch. The file may have been edited or copied
from another machine. Re-run `adm licence activate <KEY>` to recover.
```

The fix is always the same: re-run `adm licence activate` with your key. The CLI re-issues a fresh signed record bound to the current machine.

This is by design — your subscription is per-seat and we use the keychain entry to bind a record to a machine. **It's not a deactivation.** Polar doesn't know your file was tampered; you can re-activate as many times as your tier allows.

## Subscription cancelled — what happens?

| Event | What you see |
|---|---|
| You cancel via Polar customer portal | `adm` keeps working until end of paid period; on the next cache-stale validate it raises `LicenceRevoked` with a link back to https://polar.sh. |
| Refund processed | Polar marks the key revoked immediately. Next `adm` invocation past the cache window raises `LicenceRevoked`. |
| You re-subscribe | Re-run `adm licence activate <NEW-KEY>` (Polar issues a new key on re-subscribe) — your local state replaces the revoked record. |

## Where things live on your machine

| Path | Purpose | Mode |
|---|---|---|
| `~/.maestro/licence.json` | Signed licence record | 0600 |
| OS keychain entry `admiralty-licence/<customer_id>` | Per-customer signing secret | OS-managed |
| `~/.maestro/secrets/<customer_id>.key` (only on systems without a keychain provider) | Fallback for the signing secret | 0600 |

Nothing else. There are no remote files keyed to your account beyond what Polar holds for billing.

## Privacy

Activation transmits to `api.polar.sh` only:
- the licence key
- HTTP request metadata (User-Agent, IP)

That's it. No code, no prompts, no project names, no hostname. Verifiable from [`admiralty/licence/client.py`](../admiralty/licence/client.py).

## Common issues

### `Activation refused: <reason>`

Polar rejected the key. Most common causes:
- Typo (the key includes mixed case + digits; `0` vs `O`, `1` vs `l` are easy to mis-type).
- Expired subscription (re-subscribe at https://polar.sh).
- Wrong tier for the product (rare; contact `maestro@tech127.com`).

### `Couldn't reach the licence backend`

A network failure during activation — activation requires online verification. Try again on a live network. If Polar itself is down (check https://status.polar.sh), wait it out.

### `Licence file signature mismatch` after a system update

Some OS updates rotate the keychain master key (rare; macOS Migration Assistant is the most common cause). Re-run `adm licence activate <KEY>`.

### `Offline grace expired`

You've been offline > 14 days. Connect to the internet and run `adm licence revalidate`.

## Where to ask questions

- Email: `maestro@tech127.com`
- GitHub issues: https://github.com/tavisbasing/Maestro/issues
- Status of the licence backend: https://status.maestroai.com (not yet live; placeholder)
