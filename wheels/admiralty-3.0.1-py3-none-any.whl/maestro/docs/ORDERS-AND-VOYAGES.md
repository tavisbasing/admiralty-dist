# Orders and Voyages

Orders and voyages are how you define and organise work in Maestro.

- An **order** is a discrete unit of work assigned to a single role.
- A **voyage** is a collection of related orders — the equivalent of a sprint or a feature release.

---

## Contents

- [Orders](#orders)
  - [Order Format](#order-format)
  - [Order ID Convention](#order-id-convention)
  - [Order Types](#order-types)
  - [Order Lifecycle](#order-lifecycle)
  - [Creating an Order](#creating-an-order)
  - [Dependencies](#dependencies)
- [Voyages](#voyages)
  - [Voyage Format](#voyage-format)
  - [Voyage ID Convention](#voyage-id-convention)
  - [Voyage Lifecycle](#voyage-lifecycle)
  - [Creating a Voyage](#creating-a-voyage)
- [Queue Tiers](#queue-tiers)
- [Escalations](#escalations)
- [Checking Status](#checking-status)

---

## Orders

### Order Format

An order is a JSON file. Here is the full format:

```json
{
  "orderId": "FTR-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "type": "FTR",
  "role": "SHP",
  "title": "Add user authentication",
  "description": "Implement JWT-based login and registration. Use the existing User model in src/Models/User.cs. Endpoints: POST /auth/login returns a JWT; POST /auth/register creates a user. Return 401 on invalid credentials.",
  "acceptanceCriteria": [
    "POST /auth/login returns 200 with a valid JWT on correct credentials",
    "POST /auth/register creates user and returns 201",
    "Invalid credentials return 401 with a clear error message",
    "No changes to the User model schema"
  ],
  "dependsOn": [],
  "voyageId": "VOY-MYPROJ-2026-0001",
  "targetFiles": [
    "my-project/src/Controllers/AuthController.cs",
    "my-project/src/Services/AuthService.cs"
  ],
  "status": "QUEUED",
  "maxIterations": 25
}
```

**Field reference:**

| Field | Required | Type | Description |
|-------|----------|------|-------------|
| `orderId` | Yes | string | Unique ID following the naming convention below. |
| `project` | Yes | string | Project acronym matching your `projects.json` registration. |
| `type` | Yes | string | Order type code (FTR, BUG, DOC, INT, SEC, etc.). |
| `role` | Yes | string | Role code: `NAV`, `SHP`, `BOS`, `SCR`, `LKT`, or `COX`. |
| `title` | Yes | string | Short human-readable title. |
| `description` | Yes | string | Full description of the work. Be specific — this is the crew's primary instruction. |
| `acceptanceCriteria` | Yes | array of strings | What "done" looks like. Used by crews to verify their output. |
| `dependsOn` | No | array of strings | Order IDs that must reach `COMPLETE` before this order dispatches. |
| `voyageId` | No | string | The voyage this order belongs to. |
| `targetFiles` | No | array of strings | Suggested files the crew should focus on. |
| `status` | Yes | string | Initial status. Always set to `"QUEUED"` when creating. |
| `maxIterations` | No | integer | Override the default 25 iteration limit for this order. |

### Order ID Convention

```
{TYPE}-{PROJECT}-{YEAR}-{SEQUENCE}
```

Examples:
- `FTR-MYPROJ-2026-0001` — first feature order for MYPROJ in 2026
- `BUG-MYPROJ-2026-0015` — fifteenth bug order
- `DOC-MYPROJ-2026-0003` — third documentation order

Keep sequences zero-padded to four digits.

### Order Types

| Type | Description |
|------|-------------|
| `FTR` | New feature |
| `BUG` | Bug fix |
| `DOC` | Documentation |
| `INT` | Integration or deployment |
| `SEC` | Security fix or audit |
| `QA` | Quality assurance / test coverage |
| `REF` | Refactoring |

You can use any type code that is meaningful to your project — the dispatcher does not validate type codes against an enumeration.

### Order Lifecycle

Orders move through these states:

```
QUEUED  →  ACTIVE  →  COMPLETE
                  ↘  FAILED
```

| State | Location | Description |
|-------|---------|-------------|
| `QUEUED` | `.maestro/queues/{tier}/` | Awaiting dispatch. |
| `ACTIVE` | `.maestro/orders/active/` | Currently being worked by a crew. |
| `COMPLETE` | `.maestro/orders/complete/` | Crew signalled completion and order was verified. |
| `FAILED` | `.maestro/orders/failed/` | Crew failed or timed out. |

The dispatcher moves files between these directories automatically. You should not move them manually while a dispatch session is running.

### Creating an Order

1. Write the order JSON using the format above.
2. Save it to the appropriate queue directory (usually `.maestro/queues/orders/`).
3. Run `admiralty dispatch` — the Fleet Admiral will pick it up.

**Example:**

```bash
# Create the order file
cat > .maestro/queues/orders/FTR-MYPROJ-2026-0001.json << 'EOF'
{
  "orderId": "FTR-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "type": "FTR",
  "role": "SHP",
  "title": "Add CSV export endpoint",
  "description": "Add GET /api/reports/export that returns the current report data as a CSV file. Use the existing ReportService to fetch data. Set Content-Disposition: attachment; filename=report.csv.",
  "acceptanceCriteria": [
    "GET /api/reports/export returns a valid CSV with correct column headers",
    "Response has Content-Type: text/csv and Content-Disposition: attachment",
    "Empty result set returns a CSV with headers only (no 500 error)"
  ],
  "dependsOn": [],
  "voyageId": "VOY-MYPROJ-2026-0002",
  "status": "QUEUED"
}
EOF

# Dispatch
admiralty dispatch --max-crews 3
```

### Dependencies

Use `dependsOn` to ensure orders run in the right sequence. The dispatcher will not assign an order to a crew until all orders in its `dependsOn` array are `COMPLETE`.

```json
{
  "orderId": "BUG-MYPROJ-2026-0002",
  "dependsOn": ["FTR-MYPROJ-2026-0001"]
}
```

**Common patterns:**

Sequential feature + test:
```json
// SHP order
{ "orderId": "FTR-MYPROJ-2026-0005", "role": "SHP", "dependsOn": [] }

// BOS order waits for SHP
{ "orderId": "FTR-MYPROJ-2026-0006", "role": "BOS", "dependsOn": ["FTR-MYPROJ-2026-0005"] }
```

Plan-first workflow:
```json
// NAV plans first
{ "orderId": "FTR-MYPROJ-2026-0010", "role": "NAV", "dependsOn": [] }

// SHP waits for the plan
{ "orderId": "FTR-MYPROJ-2026-0011", "role": "SHP", "dependsOn": ["FTR-MYPROJ-2026-0010"] }
```

---

## Voyages

### Voyage Format

```json
{
  "voyageId": "VOY-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "title": "Authentication feature",
  "description": "Implement login, registration, and JWT token management.",
  "orders": [
    "FTR-MYPROJ-2026-0001",
    "FTR-MYPROJ-2026-0002",
    "FTR-MYPROJ-2026-0003"
  ],
  "branch": "voyage/VOY-MYPROJ-2026-0001",
  "status": "ACTIVE",
  "createdAt": "2026-03-30"
}
```

**Field reference:**

| Field | Required | Type | Description |
|-------|----------|------|-------------|
| `voyageId` | Yes | string | Unique ID following the naming convention. |
| `project` | Yes | string | Project acronym. |
| `title` | Yes | string | Short description of the voyage goal. |
| `description` | No | string | Full description of the voyage scope. |
| `orders` | Yes | array of strings | All order IDs that belong to this voyage. |
| `branch` | No | string | The git branch crews commit to during this voyage. |
| `status` | Yes | string | `ACTIVE` or `COMPLETE`. |
| `createdAt` | No | string | ISO date string. |

### Voyage ID Convention

```
VOY-{PROJECT}-{YEAR}-{SEQUENCE}
```

Examples:
- `VOY-MYPROJ-2026-0001`
- `VOY-MYPROJ-2026-0002`

### Voyage Lifecycle

```
ACTIVE  →  COMPLETE
```

| State | Location |
|-------|---------|
| `ACTIVE` | `.maestro/voyages/active/` |
| `COMPLETE` | `.maestro/voyages/complete/` |

A voyage is complete when all its orders have reached `COMPLETE`. You can run `admiralty verify` to confirm the build and tests pass before marking the voyage complete.

### Creating a Voyage

1. Create the voyage JSON and save it to `.maestro/voyages/active/`.
2. Create all associated orders and save them to the appropriate queues.
3. Dispatch the fleet.

**Tip:** Create orders and voyages in a batch before dispatching. The dispatcher handles ordering and dependency resolution automatically.

---

## Queue Tiers

Place an order in a specific queue directory to control its dispatch priority.

| Directory | Priority | Use For |
|-----------|----------|---------|
| `queues/explicit/` | Highest | Emergency or manually-forced dispatch |
| `queues/security/` | High | Security vulnerabilities and fixes |
| `queues/bugs/` | High | Bug fixes |
| `queues/requests/` | Medium-High | Crew-generated requests for follow-on work |
| `queues/orders/` | Medium | Normal feature work (default) |
| `queues/defects/` | Medium-Low | Defects identified in QA |
| `queues/breakdown/` | Low | Sub-tasks broken down from higher-level orders |
| `queues/high-level/` | Lowest | NAV planning tasks and high-level requirements |
| `queues/escalations/` | Not dispatched | Requires Captain/QM review before proceeding |

For most orders, `queues/orders/` is the right choice.

---

## Escalations

A crew that encounters a blocking issue it cannot resolve will write an escalation to `.maestro/queues/escalations/`. Escalations with `"blocking": true` halt all subsequent orders in the same voyage until the Captain or Quartermaster resolves them.

**To resolve an escalation:**

1. Read the escalation JSON in `.maestro/queues/escalations/`
2. Investigate the issue described
3. Set `"status": "RESOLVED"` and add a `"resolution"` string explaining what to do
4. Save the file — the dispatcher will unblock the voyage automatically on the next run

```json
{
  "escalationId": "ESC-MYPROJ-2026-0001",
  "orderId": "FTR-MYPROJ-2026-0005",
  "blocking": true,
  "issue": "Cannot find the User model at the path specified in the order. src/Models/User.cs does not exist.",
  "status": "RESOLVED",
  "resolution": "User model is at src/Domain/User.cs — update targetFiles in the order and re-queue."
}
```

---

## Checking Status

**Fleet-wide status:**
```bash
admiralty status --once
```

**Token usage per voyage:**
```bash
admiralty usage --voyage VOY-MYPROJ-2026-0001
```

**View completed orders:**
```bash
ls .maestro/orders/complete/
```

**View failed orders:**
```bash
ls .maestro/orders/failed/
```

**View an individual crew's progress:**
```bash
cat .maestro/crews/crew1/progress.md
```

---

*Maestro Maestro v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
