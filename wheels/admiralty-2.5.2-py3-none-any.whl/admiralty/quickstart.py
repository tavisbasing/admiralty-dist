"""
admiralty/quickstart.py — Guided first-run experience for Admiralty.

Phases:
  0  Pre-flight checks
  1  Workspace init
  2  Demo voyage creation
  3  Fleet dispatch (streams crew output)
  4  Completion summary
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

# ---------------------------------------------------------------------------
# Demo voyage content (embedded — immune to template drift)
# ---------------------------------------------------------------------------

# Order templates — orderId is filled in at runtime once we know
# {project} / {year} / {seq}. dependsOn references use the same template.
DEMO_ORDER_TEMPLATES: list[dict] = [
    {
        "orderIdTemplate": "NAV-{project}-{year}-{seq}",
        "type": "NAV",
        "title": "Draft a hello-world plan",
        "description": (
            "Write a one-page plan for a Python script that prints "
            "'Hello from Admiralty!'. Save the plan to "
            ".adm/plans/PLAN-{project}-{year}-{seq}.md. The plan must include: "
            "purpose, one implementation step, and success criteria."
        ),
        "priority": "NORMAL",
        "targetRole": "NAV",
        "dependsOnTemplates": [],
    },
    {
        "orderIdTemplate": "FTR-{project}-{year}-{seq}",
        "type": "FTR",
        "title": "Implement hello.py",
        "description": (
            "Read the plan at .adm/plans/PLAN-{project}-{year}-{seq}.md. Create "
            "a file hello.py in the current directory that prints "
            "'Hello from Admiralty!' when run with `python hello.py`. The file "
            "must be executable and contain a __main__ guard."
        ),
        "priority": "NORMAL",
        "targetRole": "SHP",
        "dependsOnTemplates": ["NAV-{project}-{year}-{seq}"],
    },
    {
        "orderIdTemplate": "BOS-{project}-{year}-{seq}",
        "type": "BOS",
        "title": "Verify hello.py",
        "description": (
            "Run `python hello.py` and confirm the output is exactly "
            "'Hello from Admiralty!'. Write a one-sentence QA report to "
            ".adm/reports/qa/QA-{project}-{year}-{seq}.md stating PASS or FAIL "
            "with the actual output observed."
        ),
        "priority": "NORMAL",
        "targetRole": "BOS",
        "dependsOnTemplates": ["FTR-{project}-{year}-{seq}"],
    },
]


# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------

def check_api_key() -> None:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print(
            "\nError: ANTHROPIC_API_KEY is not set.\n\n"
            "  Admiralty crews use Claude via the Anthropic API.\n"
            "  Set your API key before running quickstart:\n\n"
            "    export ANTHROPIC_API_KEY=sk-ant-...   # macOS / Linux / WSL\n"
            '    $env:ANTHROPIC_API_KEY="sk-ant-..."   # Windows PowerShell\n\n'
            "  Get a key at: https://console.anthropic.com/settings/keys",
            file=sys.stderr,
        )
        sys.exit(1)


def check_claude_cli() -> None:
    if sys.platform == "win32" and shutil.which("claude") is None:
        print(
            "\nError: Claude Code is not available natively on Windows.\n\n"
            "  Admiralty on Windows requires WSL2 (Windows Subsystem for Linux).\n\n"
            "  Setup steps:\n"
            "    1. Install WSL2:  wsl --install\n"
            "    2. Open a WSL terminal and install Admiralty inside it:\n"
            "         pip install admiralty --extra-index-url https://tavisbasing.github.io/admiralty-dist/simple/\n"
            "    3. Run from WSL: adm quickstart\n\n"
            "  See: https://learn.microsoft.com/windows/wsl/install",
            file=sys.stderr,
        )
        sys.exit(1)

    if shutil.which("claude") is None:
        print(
            "\nError: Claude Code CLI not found on PATH.\n\n"
            "  Admiralty crews run inside Claude Code sessions.\n"
            "  Install Claude Code first:\n\n"
            "    npm install -g @anthropic-ai/claude-code   # requires Node 18+\n\n"
            "  Then re-run: adm quickstart\n\n"
            "  Docs: https://docs.anthropic.com/claude-code",
            file=sys.stderr,
        )
        sys.exit(1)

    # Verify claude responds
    try:
        result = subprocess.run(
            ["claude", "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            raise RuntimeError("non-zero exit")
        version = result.stdout.strip() or result.stderr.strip()
        print(f"✓ Claude Code detected ({version})")
    except Exception:
        print(
            "\nError: Claude Code CLI found but did not respond to --version.\n\n"
            "  Try: claude --version\n"
            "  If that fails, reinstall Claude Code:\n"
            "    npm install -g @anthropic-ai/claude-code",
            file=sys.stderr,
        )
        sys.exit(1)


def check_python_version() -> None:
    # Track pyproject.toml `requires-python = ">=3.9"`; bump both together.
    if sys.version_info < (3, 9):
        print(
            f"\nError: Python 3.9+ required (found {sys.version}).\n"
            "  Upgrade Python and re-run: adm quickstart",
            file=sys.stderr,
        )
        sys.exit(1)


def check_no_running_fleet(adm_dir: Path) -> None:
    pid_file = adm_dir / "dispatcher.pid"
    if pid_file.exists():
        print(
            "\nWarning: An adm dispatch process may already be running "
            f"(PID file: {pid_file}).\n"
            "  Stop it first with: adm cleanup\n"
            "  Or proceed at your own risk — crews may conflict.",
        )


def run_preflight(adm_dir: Path, skip: bool = False) -> None:
    if skip:
        print("⚡ Pre-flight checks skipped (--skip-checks).")
        return

    check_api_key()
    print("✓ API key found")

    check_claude_cli()  # prints its own success line

    check_python_version()
    print("✓ Python version OK")

    check_no_running_fleet(adm_dir)

    print("✓ Environment ready\n")


# ---------------------------------------------------------------------------
# Phase 1 — Workspace init
# ---------------------------------------------------------------------------

def init_workspace(project: str, directory: Path) -> None:
    from admiralty.init import scaffold_workspace

    adm_dir = directory / ".adm"
    if adm_dir.exists():
        print(f"⚠  Workspace already initialised at {directory} — continuing.")
    else:
        print("Initialising demo workspace...")
        scaffold_workspace(project=project, directory=directory, force=False)
        print("✓ Workspace initialised (.adm/)\n")


# ---------------------------------------------------------------------------
# Phase 2 — Demo voyage creation
# ---------------------------------------------------------------------------

def _next_demo_seq(adm_dir: Path, project: str, year: int) -> str:
    """Pick a 4-digit sequence that doesn't collide with existing demo artefacts.

    Scans queues + orders + voyages for `*-{project}-{year}-NNNN.json` and returns
    one greater than the highest match (or 0001 if none).
    """
    import re

    pattern = re.compile(rf"-{re.escape(project)}-{year}-(\d{{4}})")
    highest = 0
    for sub in ("queues/orders", "queues/proposed", "orders/active",
                "orders/complete", "voyages/active", "voyages/complete"):
        d = adm_dir / sub
        if not d.exists():
            continue
        for f in d.glob(f"*-{project}-{year}-*.json"):
            m = pattern.search(f.stem)
            if m:
                highest = max(highest, int(m.group(1)))
    return f"{highest + 1:04d}"


def create_demo_voyage(project: str, adm_dir: Path) -> tuple[str, list[str]]:
    """Materialise the demo voyage + orders into the dispatcher's queue.

    Returns (voyage_id, [order_id, ...]) for callers that need to poll completion.
    """
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    year = now.year
    seq = _next_demo_seq(adm_dir, project, year)

    fmt = {"project": project, "year": year, "seq": seq}
    voyage_id = f"VOY-{project}-{year}-{seq}"

    # Materialise each order from its template, preserving template→ID mapping
    # so dependsOn references stay correct after substitution.
    orders: list[dict] = []
    for tpl in DEMO_ORDER_TEMPLATES:
        order_id = tpl["orderIdTemplate"].format(**fmt)
        orders.append({
            "orderId": order_id,
            "type": tpl["type"],
            "project": project,
            "title": tpl["title"],
            "description": tpl["description"].format(**fmt),
            "priority": tpl["priority"],
            "status": "PENDING",
            "voyageId": voyage_id,
            "targetRole": tpl["targetRole"],
            "role": tpl["targetRole"],
            "roleSequence": [tpl["targetRole"]],
            "dependsOn": [d.format(**fmt) for d in tpl["dependsOnTemplates"]],
        })

    # Write voyage JSON
    voyage = {
        "voyageId": voyage_id,
        "project": project,
        "title": "Admiralty Demo",
        "status": "ACTIVE",
        "createdAt": now.isoformat(),
        "orders": [o["orderId"] for o in orders],
    }
    voyages_dir = adm_dir / "voyages" / "active"
    voyages_dir.mkdir(parents=True, exist_ok=True)
    (voyages_dir / f"{voyage_id}.json").write_text(
        json.dumps(voyage, indent=2), encoding="utf-8"
    )

    # Write orders into the dispatcher's queue (it scans .adm/queues/**, not
    # .adm/orders/active/, so PENDING here is the only thing that actually runs).
    queues_dir = adm_dir / "queues" / "orders"
    queues_dir.mkdir(parents=True, exist_ok=True)
    for order in orders:
        (queues_dir / f"{order['orderId']}.json").write_text(
            json.dumps(order, indent=2), encoding="utf-8"
        )

    order_ids = [o["orderId"] for o in orders]
    print(f"✓ Demo voyage created  ({voyage_id})")
    print(f"✓ 3 orders queued      ({' · '.join(order_ids)})\n")
    return voyage_id, order_ids


# ---------------------------------------------------------------------------
# Phase 3 — Dispatch
# ---------------------------------------------------------------------------

QUICKSTART_TIMEOUT_SECONDS = 600  # 10 min cap on the demo run


def stream_dispatch(
    crews: int,
    adm_dir: Path,
    expected_order_ids: list[str] | None = None,
) -> float:
    """Kick `adm dispatch` (which detaches) and wait for the demo orders to land
    in `.adm/orders/complete/`. Returns elapsed seconds.

    The dispatcher launches detached so its stdout is unreachable; instead
    we poll the filesystem for terminal-state evidence.
    """
    crews = max(1, min(crews, 3))
    print(f"Dispatching {crews} crew(s)… (Ctrl-C to detach — crews keep running)\n")

    cmd = [sys.executable, "-m", "admiralty.cli", "dispatch", "--max-crews", str(crews)]
    subprocess.run(cmd, check=False)

    t0 = time.monotonic()
    complete_dir = adm_dir / "orders" / "complete"
    expected = list(expected_order_ids or [])
    expected_count = len(expected) or 3
    last_done = -1
    metric_recorded = False

    try:
        while time.monotonic() - t0 < QUICKSTART_TIMEOUT_SECONDS:
            if complete_dir.exists():
                done_files = (
                    [f for f in complete_dir.glob("*.json") if f.stem in expected]
                    if expected
                    else list(complete_dir.glob("*.json"))
                )
            else:
                done_files = []
            done = len(done_files)
            if done != last_done:
                print(f"  {done}/{expected_count} demo orders complete")
                last_done = done
                if done >= 1 and not metric_recorded:
                    _record_first_output_metric(adm_dir, int((time.monotonic() - t0) * 1000))
                    metric_recorded = True
            if done >= expected_count:
                return time.monotonic() - t0
            time.sleep(2)
    except KeyboardInterrupt:
        print("\n⚡ Detached — crews are still running. Monitor with: adm status")
        sys.exit(0)

    print("  ⚠ Timed out after 10 min. Run `adm status` to inspect crew state.")
    return time.monotonic() - t0


def _record_first_output_metric(adm_dir: Path, first_ms: int) -> None:
    usage_dir = adm_dir / "usage" / "orders"
    usage_dir.mkdir(parents=True, exist_ok=True)
    metric_file = usage_dir / "QS-FIRST-OUTPUT.json"
    metric_file.write_text(
        json.dumps({"quickstart_phase3_first_output_ms": first_ms}, indent=2),
        encoding="utf-8",
    )


# ---------------------------------------------------------------------------
# Phase 4 — Completion banner
# ---------------------------------------------------------------------------

def print_completion_banner(elapsed: float, orders: int) -> None:
    mins = int(elapsed // 60)
    secs = int(elapsed % 60)
    elapsed_str = f"{mins}m {secs}s" if mins else f"{secs}s"

    print(
        "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        " Admiralty quickstart complete! 🎉\n\n"
        f" {orders} orders completed in {elapsed_str}\n"
        " Results: .adm/orders/complete/\n\n"
        " Next steps:\n"
        "   adm status          — monitor a real fleet\n"
        "   adm docs            — full documentation\n"
        "   adm voyage create   — start a real voyage\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    )


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_quickstart(args) -> None:
    project = args.project.upper()
    directory = Path.cwd()
    adm_dir = directory / ".adm"

    run_preflight(adm_dir, skip=getattr(args, "skip_checks", False))

    init_workspace(project, directory)

    if getattr(args, "no_demo", False):
        print("✓ Environment verified. Run `adm dispatch` to start a real fleet.")
        return

    _voyage_id, order_ids = create_demo_voyage(project, adm_dir)

    elapsed = stream_dispatch(
        getattr(args, "crews", 1), adm_dir, expected_order_ids=order_ids
    )

    print_completion_banner(elapsed, len(order_ids))
