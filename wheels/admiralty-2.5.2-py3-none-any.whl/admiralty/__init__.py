# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Admiralty — Fleet Command System
AI-powered multi-agent Claude Code orchestration framework.

Version: 2.5.2
Repository: https://github.com/tavisbasing/Admiralty
"""

__version__ = "2.5.2"
__title__ = "Admiralty — Fleet Command System"

# Licence check — runs on every CLI startup (skipped for version/init — see cli.py)
from admiralty import auth as _auth
_auth.check()
