"""Licence-system error hierarchy.

Surfaces in the CLI as exit codes and human-readable messages.
"""

from __future__ import annotations


class LicenceError(Exception):
    """Base class for all licence-system errors."""


class LicenceMissing(LicenceError):
    """No licence file is present — user has not run `adm licence activate`."""

    def __init__(self) -> None:
        super().__init__(
            "No licence found. Run `adm licence activate <KEY>` to start."
        )


class LicenceInvalid(LicenceError):
    """Polar rejected the key as invalid (key not found, malformed, etc.)."""


class LicenceRevoked(LicenceError):
    """Polar reported the key as revoked (cancelled or refunded subscription)."""


class LicenceExpired(LicenceError):
    """Licence has expired (or grace window has elapsed without revalidation)."""


class LicenceTampered(LicenceError):
    """Stored licence file's signature does not match — file has been
    edited or copied from another machine without the keychain secret.
    """

    def __init__(self) -> None:
        super().__init__(
            "Licence file signature mismatch. The file may have been edited "
            "or copied from another machine. Re-run `adm licence activate <KEY>` "
            "to recover."
        )
