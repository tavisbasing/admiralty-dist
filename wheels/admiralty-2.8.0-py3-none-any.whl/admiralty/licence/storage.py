"""Licence record storage at ~/.admiralty/licence.json.

- File mode: 0600 on POSIX (Windows ignores this — see _set_perms note).
- HMAC-SHA256 signature over the canonical JSON of all signed fields,
  keyed by a per-customer secret stored in the OS keychain (so a stolen
  licence.json on its own is useless without the secret on the source
  machine).
- Schema version included for forward compat.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from admiralty.licence.errors import LicenceMissing, LicenceTampered


SCHEMA_VERSION = 1
KEYCHAIN_SERVICE = "admiralty-licence"

# Fields included in the signed payload (order matters for canonical JSON).
SIGNED_FIELDS = (
    "schema_version",
    "licence_key",
    "tier",
    "product_id",
    "customer_id",
    "issued_at",
    "expires_at",
    "last_validated_at",
    "offline_grace_until",
)


@dataclass
class LicenceRecord:
    licence_key: str
    tier: str
    product_id: str
    customer_id: str
    issued_at: str
    expires_at: str
    last_validated_at: str
    offline_grace_until: str
    schema_version: int = SCHEMA_VERSION
    # Transient, in-memory only. Never roundtrip to disk; not part of
    # the signed payload. Set by validate() so the CLI can render a
    # warning banner when grace fallback is active.
    signing_secret: Optional[str] = field(default=None, repr=False)
    used_grace: bool = field(default=False, repr=False)
    grace_remaining_days: int = field(default=0, repr=False)
    # Note: signing_secret is set when we receive a fresh secret from
    # Polar at activate-time. It's *consumed once* — written to keychain
    # then cleared from memory. Not part of the on-disk record.

    def to_signed_payload(self) -> dict:
        return {k: getattr(self, k) for k in SIGNED_FIELDS}


# ---------------------------------------------------------------------------
# Keychain helpers
# ---------------------------------------------------------------------------

def _keychain_set(customer_id: str, secret: str) -> None:
    """Store the per-customer signing secret in the OS keychain."""
    try:
        import keyring  # type: ignore
        keyring.set_password(KEYCHAIN_SERVICE, customer_id, secret)
    except Exception:
        # Fallback: write to ~/.admiralty/secrets/<customer_id>.key with mode 0600.
        # Less secure than keychain but functional on systems without keyring.
        secrets_dir = _adm_dir() / "secrets"
        secrets_dir.mkdir(parents=True, exist_ok=True)
        f = secrets_dir / f"{customer_id}.key"
        f.write_text(secret, encoding="utf-8")
        _set_perms(f, 0o600)


def _keychain_get(customer_id: str) -> Optional[str]:
    try:
        import keyring  # type: ignore
        return keyring.get_password(KEYCHAIN_SERVICE, customer_id)
    except Exception:
        f = _adm_dir() / "secrets" / f"{customer_id}.key"
        if f.exists():
            return f.read_text(encoding="utf-8")
        return None


def _keychain_delete(customer_id: str) -> None:
    try:
        import keyring  # type: ignore
        keyring.delete_password(KEYCHAIN_SERVICE, customer_id)
    except Exception:
        f = _adm_dir() / "secrets" / f"{customer_id}.key"
        if f.exists():
            f.unlink()


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------

def _adm_dir() -> Path:
    """~/.admiralty/  — created on demand. Independent of project workspace."""
    home = Path(os.path.expanduser("~"))
    d = home / ".admiralty"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _record_path() -> Path:
    return _adm_dir() / "licence.json"


def _set_perms(path: Path, mode: int) -> None:
    """Best-effort chmod. Windows file ACLs aren't equivalent — we accept
    that and rely on per-user home directory permissions there.
    """
    try:
        os.chmod(path, mode)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Signing
# ---------------------------------------------------------------------------

def _canonical_json(payload: dict) -> bytes:
    """Stable serialisation: sorted keys, no whitespace, UTF-8."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _sign(payload: dict, secret: str) -> str:
    return hmac.new(
        secret.encode("utf-8"), _canonical_json(payload), hashlib.sha256
    ).hexdigest()


def _verify(payload: dict, secret: str, expected: str) -> bool:
    return hmac.compare_digest(_sign(payload, secret), expected)


# ---------------------------------------------------------------------------
# Public read/write API
# ---------------------------------------------------------------------------

def save_record(record: LicenceRecord) -> None:
    """Persist `record` to ~/.admiralty/licence.json.

    Side-effect: stores `record.signing_secret` in the OS keychain on
    first save, then clears it from the in-memory dataclass.
    """
    if record.signing_secret:
        _keychain_set(record.customer_id, record.signing_secret)
        record.signing_secret = None

    secret = _keychain_get(record.customer_id)
    if not secret:
        # Should never happen — we just wrote it. Defensive only.
        raise RuntimeError("Keychain write succeeded but read failed.")

    payload = record.to_signed_payload()
    # Field name follows the pinned PLAN-VOY-0031 schema (`validated_signature`).
    on_disk = {**payload, "validated_signature": _sign(payload, secret)}
    p = _record_path()
    p.write_text(json.dumps(on_disk, indent=2), encoding="utf-8")
    _set_perms(p, 0o600)


# Required signed fields (a subset of SIGNED_FIELDS that must be non-empty).
# `schema_version` has a default and is allowed to be implicit.
_REQUIRED_FIELDS = (
    "licence_key", "tier", "product_id", "customer_id",
    "issued_at", "expires_at", "last_validated_at", "offline_grace_until",
)


def load_record() -> LicenceRecord:
    """Load + verify the stored record.

    Raises LicenceMissing if no file present.
    Raises LicenceTampered if signature doesn't match, the keychain
    entry is missing (cross-machine theft), or the on-disk file is
    truncated/missing required fields.
    """
    p = _record_path()
    if not p.exists():
        raise LicenceMissing()

    try:
        on_disk = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeDecodeError) as exc:
        raise LicenceTampered() from exc

    # Honour the canonical schema field name first; fall back to the
    # legacy `signature` key for any record written by a pre-rename build.
    sig = on_disk.pop("validated_signature", "") or on_disk.pop("signature", "")
    if not sig:
        raise LicenceTampered()

    customer_id = on_disk.get("customer_id", "")
    secret = _keychain_get(customer_id)
    if not secret:
        # Keychain entry missing — this is the cross-machine-copy attack.
        raise LicenceTampered()

    # Verify only the canonical signed payload — unknown future fields
    # are ignored so forward-compat works as intended.
    known = {k: v for k, v in on_disk.items() if k in SIGNED_FIELDS}
    if not _verify(known, secret, sig):
        raise LicenceTampered()

    # Truncated / edited file: required fields missing → tampered, not a
    # bare TypeError on the dataclass constructor.
    missing = [f for f in _REQUIRED_FIELDS if not known.get(f)]
    if missing:
        raise LicenceTampered()

    return LicenceRecord(**known)


def delete_record() -> None:
    """Remove the licence file and the keychain entry."""
    p = _record_path()
    customer_id = ""
    if p.exists():
        try:
            on_disk = json.loads(p.read_text(encoding="utf-8"))
            customer_id = on_disk.get("customer_id", "")
        except Exception:
            pass
        p.unlink()
    if customer_id:
        _keychain_delete(customer_id)
