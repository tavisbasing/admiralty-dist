# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. See LICENSE for full terms.

"""
admiralty.licence — licence-key activation / validation / storage.

Public API:
    activate(key) -> LicenceRecord     # online verify + persist
    validate(strict=False) -> LicenceRecord
                                       # fast path: cached-OK if recent;
                                       # online re-validate beyond 24h;
                                       # raises LicenceError on hard fail.
                                       # When grace fallback is used,
                                       # record.used_grace == True so the
                                       # CLI can render a warning banner.
    deactivate() -> None               # local-side deactivation
    status() -> LicenceRecord | None   # read-only inspection

Backend: Polar.sh (selected in PLAN-VOY-ADM-2026-0031.md). All Polar
calls go through admiralty.licence.client; storage is at
~/.admiralty/licence.json (mode 0600) signed with a per-customer
keychain secret. Offline grace: 14 days from last successful online
validation.

Config (env vars):
    ADMIRALTY_LICENCE_API_BASE   default https://api.polar.sh/v1
    ADMIRALTY_LICENCE_KEY        non-interactive activation (CI/CD)
    ADMIRALTY_LICENCE_GRACE_DAYS default 14 (test override only)
"""

from __future__ import annotations

from datetime import datetime, timezone

from admiralty.licence.client import PolarClient, PolarError
from admiralty.licence.errors import (
    LicenceError,
    LicenceExpired,
    LicenceInvalid,
    LicenceRevoked,
    LicenceTampered,
    LicenceMissing,
)
from admiralty.licence.grace import (
    GRACE_DEFAULT_DAYS,
    grace_remaining_days,
    in_grace_window,
    next_grace_until,
    parse_iso,
)
from admiralty.licence.storage import (
    LicenceRecord,
    delete_record,
    load_record,
    save_record,
)


__all__ = [
    "activate",
    "validate",
    "deactivate",
    "status",
    "LicenceRecord",
    "LicenceError",
    "LicenceExpired",
    "LicenceInvalid",
    "LicenceRevoked",
    "LicenceTampered",
    "LicenceMissing",
]


def _is_fake_activation_enabled() -> bool:
    """Test-only Polar bypass.

    Honoured ONLY when ADMIRALTY_LICENCE_FAKE_ACTIVATION=1 is set in the
    operator's parent shell. Used to verify the CLI install/activate/
    status/deactivate path on a fresh machine while Polar is under
    review or otherwise unreachable. Never accidentally on by default.
    """
    import os
    return os.environ.get("ADMIRALTY_LICENCE_FAKE_ACTIVATION") == "1"


def _fake_id_from_key(key: str) -> str:
    """Stable 14-hex-char digest of a licence key for synthetic IDs.

    Uses sha256 (NOT Python's built-in hash, which is salted per-process
    via PYTHONHASHSEED). This guarantees the same key produces the same
    `customer_id` across processes / machines — the "deterministic per
    key" property the fake-activation path advertises.
    """
    import hashlib
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:14]


# Records produced by the fake-activation path are tagged with this prefix
# on `customer_id`. The CLI status banner + the validate() bypass guard
# both branch on this marker — never on the env var alone.
_FAKE_CUSTOMER_PREFIX = "cust_FAKE_"


def _fake_payload(key: str) -> dict:
    """Synthetic Polar response for the fake-activation path."""
    from datetime import timedelta
    from admiralty.licence.config import POLAR_PRODUCT_PRO
    now = datetime.now(timezone.utc)
    digest = _fake_id_from_key(key)
    return {
        "customer_id": f"{_FAKE_CUSTOMER_PREFIX}{digest}",
        "tier": "pro",
        "product_id": POLAR_PRODUCT_PRO,
        "issued_at": now.isoformat(),
        "expires_at": (now + timedelta(days=365)).isoformat(),
        "signing_secret": f"fake-secret-for-{digest}",
    }


def activate(key: str) -> LicenceRecord:
    """Activate `key` via Polar's online validation and persist the result.

    Raises LicenceInvalid if Polar rejects the key (4xx).
    Raises PolarError on network/5xx — does NOT cache anything; activation
    requires a successful online round-trip.

    Test-only escape: ADMIRALTY_LICENCE_FAKE_ACTIVATION=1 bypasses Polar
    entirely and synthesises a 1-year "pro" record so the CLI install
    flow can be tested without a Polar account / under-review org. The
    record is real-shape — same HMAC signing, same keychain entry, same
    tamper detection — only the upstream check is faked.
    """
    if not key or not key.strip():
        raise LicenceInvalid("Licence key is empty.")

    fake = _is_fake_activation_enabled()
    if fake:
        payload = _fake_payload(key.strip())
    else:
        client = PolarClient()
        payload = client.validate(key.strip())  # raises on 4xx/5xx/network

    now = datetime.now(timezone.utc)
    record = LicenceRecord(
        licence_key=key.strip(),
        tier=payload["tier"],
        product_id=payload["product_id"],
        customer_id=payload["customer_id"],
        issued_at=payload["issued_at"],
        expires_at=payload["expires_at"],
        last_validated_at=now.isoformat(),
        offline_grace_until=next_grace_until(now).isoformat(),
        signing_secret=payload["signing_secret"],  # consumed once → keychain
    )
    save_record(record)
    return record


def validate(strict: bool = False) -> LicenceRecord:
    """Read the stored record, refresh online if stale, return a valid record.

    Behaviour:
      - record missing → LicenceMissing
      - signature tampered → LicenceTampered
      - last_validated_at < 24h ago AND not strict → fast path, no HTTP
      - else → call Polar; on 200 refresh timestamps, on revoked/expired
        raise the corresponding error, on network failure honour the
        14-day grace window then raise LicenceExpired beyond it
      - strict=True forces an online check regardless of cache age
      - When grace fallback is used, the returned record has
        `used_grace=True` and `grace_remaining_days` populated, so the
        CLI can render a warning banner without changing public types.
    """
    record = load_record()  # raises LicenceMissing/LicenceTampered

    now = datetime.now(timezone.utc)
    last = parse_iso(record.last_validated_at)
    cached_ok = (now - last).total_seconds() < 24 * 3600

    if cached_ok and not strict:
        if parse_iso(record.expires_at) <= now:
            raise LicenceExpired(record.expires_at)
        record.used_grace = False
        return record

    # Test-only bypass: refresh timestamps locally without hitting Polar.
    # Two guards before we'll skip Polar:
    #   1. The env var must be on (operator opt-in).
    #   2. The stored record must itself be synthetic (cust_FAKE_ prefix).
    # This means flipping the env var on a machine with a *real* licence
    # record will NOT keep that real record alive past Polar revocation —
    # the bypass only applies to records that were synthesised by
    # _fake_payload() in the first place.
    # Expiry is still enforced here (matches the cached-OK fast path).
    if _is_fake_activation_enabled() and record.customer_id.startswith(_FAKE_CUSTOMER_PREFIX):
        if parse_iso(record.expires_at) <= now:
            raise LicenceExpired(record.expires_at)
        record.last_validated_at = now.isoformat()
        record.offline_grace_until = next_grace_until(now).isoformat()
        save_record(record)
        record.used_grace = False
        return record

    try:
        payload = PolarClient().validate(record.licence_key)
        record.last_validated_at = now.isoformat()
        record.offline_grace_until = next_grace_until(now).isoformat()
        record.expires_at = payload.get("expires_at", record.expires_at)
        save_record(record)
        record.used_grace = False
        return record
    except PolarError as exc:
        if exc.status in (401, 403):
            if exc.is_revoked():
                raise LicenceRevoked(exc.reason or exc.polar_status) from exc
            raise LicenceExpired(exc.reason or "Polar marked the key as not granted") from exc
        if in_grace_window(now, record.offline_grace_until):
            record.used_grace = True
            record.grace_remaining_days = grace_remaining_days(now, record.offline_grace_until)
            return record
        raise LicenceExpired(
            f"Offline grace expired ({grace_remaining_days(now, record.offline_grace_until)} days remaining). "
            "Connect to the internet to revalidate."
        ) from exc


def deactivate() -> None:
    """Drop the local licence record (file + keychain entry).

    Note: this does NOT cancel the Polar subscription — that's the
    customer's billing portal action.
    """
    delete_record()


def status() -> "LicenceRecord | None":
    """Return the current record, or None if no licence is activated.
    Never raises — callers ask "do we have a licence at all?".
    """
    try:
        return load_record()
    except LicenceMissing:
        return None
    except LicenceTampered:
        return None
