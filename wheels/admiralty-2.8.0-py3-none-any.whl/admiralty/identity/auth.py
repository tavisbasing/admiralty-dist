from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def resolve_caller(workspace: Path) -> str:
    """
    Resolve the caller's identity as 'user:<email>' or 'anonymous'.

    Resolution order (highest priority first):
    1. ADM_USER env var
    2. OIDC: ADM_OIDC_TOKEN (stub — full OIDC exchange is phase-2)
    3. GitHub CLI: gh api user --jq .email
    4. Git config: git config user.email
    5. OS username (low-trust; warns)
    6. anonymous
    """
    # 1. ADM_USER
    adm_user = os.environ.get("ADM_USER", "").strip()
    if adm_user:
        return f"user:{adm_user}"

    # 2. OIDC token (stub — just extract sub claim if present as email)
    oidc_token = os.environ.get("ADM_OIDC_TOKEN", "").strip()
    if oidc_token:
        email = _extract_oidc_email(oidc_token)
        if email:
            return f"user:{email}"

    # 3. GitHub CLI
    try:
        result = subprocess.run(
            ["gh", "api", "user", "--jq", ".email"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            email = result.stdout.strip()
            if email and "@" in email and email != "null":
                return f"user:{email}"
    except Exception:
        pass

    # 4. Git config
    try:
        result = subprocess.run(
            ["git", "config", "user.email"],
            capture_output=True,
            text=True,
            cwd=str(workspace),
            timeout=5,
        )
        if result.returncode == 0:
            email = result.stdout.strip()
            if email and "@" in email:
                return f"user:{email}"
    except Exception:
        pass

    # 5. OS username (low-trust)
    import getpass
    try:
        username = getpass.getuser()
        if username:
            print(
                f"[Admiralty] WARNING: identity unverified — using OS username '{username}'. "
                "Set ADM_USER=<email> for verified identity.",
                file=sys.stderr,
            )
            return f"user:{username}"
    except Exception:
        pass

    # 6. Anonymous
    return "anonymous"


def _extract_oidc_email(token: str) -> str | None:
    """Extract email from OIDC JWT payload (base64url decode, no signature verify)."""
    try:
        import base64
        import json
        parts = token.split(".")
        if len(parts) != 3:
            return None
        payload_b64 = parts[1]
        # Add base64url padding (0–3 '=' chars). Using `4 - len % 4` would
        # append 4 chars when len is a multiple of 4, which causes
        # binascii.Error: Incorrect padding.
        payload_b64 += "=" * ((-len(payload_b64)) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64).decode("utf-8"))
        email = payload.get("email") or payload.get("sub")
        if email and "@" in str(email):
            return str(email)
    except Exception:
        pass
    return None
