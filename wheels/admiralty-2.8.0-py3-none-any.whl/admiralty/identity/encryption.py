"""
Identity encryption — FTR-ADM-2026-0071 (V6 LKT HIGH GDPR).

Optional at-rest encryption for .adm/identity/ files via git-crypt or sops.
Configured in workspace.json: identity.encryption = {tool, keyref}.

When encryption is enabled:
- .adm/identity/users/*.json and .adm/identity/integrity.json are added to
  .gitattributes with the appropriate filter.
- Integrity hashes are computed over plaintext before encryption so the
  manifest stays stable across re-encryptions.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Literal

EncryptionTool = Literal["git-crypt", "sops", "none"]

_GITATTR_MARKER = "# admiralty-identity-encryption"
_GITCRYPT_ATTR = "filter=git-crypt diff=git-crypt merge=git-crypt -text"
_SOPS_ATTR = "filter=sops diff=sops merge=sops"


def load_encryption_config(workspace: Path) -> dict:
    """Return the identity.encryption block from workspace.json, or {}."""
    cfg_path = workspace / ".adm" / "config" / "workspace.json"
    if not cfg_path.exists():
        return {}
    try:
        data = json.loads(cfg_path.read_text(encoding="utf-8"))
        enc = data.get("identity", {}).get("encryption", {})
        return enc if isinstance(enc, dict) else {}
    except Exception:
        return {}


def encryption_tool(workspace: Path) -> EncryptionTool:
    cfg = load_encryption_config(workspace)
    tool = cfg.get("tool", "none")
    if tool not in ("git-crypt", "sops", "none"):
        return "none"
    return tool  # type: ignore[return-value]


def is_encryption_enabled(workspace: Path) -> bool:
    return encryption_tool(workspace) != "none"


# ---------------------------------------------------------------------------
# .gitattributes management
# ---------------------------------------------------------------------------

def _gitattributes_path(workspace: Path) -> Path:
    return workspace / ".gitattributes"


def _identity_patterns(identity_dir: Path, workspace: Path) -> list[str]:
    try:
        rel = identity_dir.relative_to(workspace)
    except ValueError:
        rel = Path(".adm/identity")
    return [
        f"{rel}/users/*.json",
        f"{rel}/integrity.json",
    ]


def _attr_line(pattern: str, tool: EncryptionTool) -> str:
    attr = _GITCRYPT_ATTR if tool == "git-crypt" else _SOPS_ATTR
    return f"{pattern} {attr}"


def add_gitattributes(workspace: Path, identity_dir: Path) -> None:
    """Append encryption filter entries to .gitattributes (idempotent)."""
    tool = encryption_tool(workspace)
    if tool == "none":
        return

    ga = _gitattributes_path(workspace)
    existing = ga.read_text(encoding="utf-8") if ga.exists() else ""

    lines_to_add: list[str] = []
    for pattern in _identity_patterns(identity_dir, workspace):
        line = _attr_line(pattern, tool)
        if line not in existing:
            lines_to_add.append(line)

    if not lines_to_add:
        return

    block = "\n" + _GITATTR_MARKER + "\n" + "\n".join(lines_to_add) + "\n"
    with ga.open("a", encoding="utf-8") as fh:
        fh.write(block)
    print(f"[Identity] Updated .gitattributes for {tool} encryption.")


def remove_gitattributes(workspace: Path) -> None:
    """Remove the admiralty-identity-encryption block from .gitattributes."""
    ga = _gitattributes_path(workspace)
    if not ga.exists():
        return
    lines = ga.read_text(encoding="utf-8").splitlines(keepends=True)
    out: list[str] = []
    skip = False
    for line in lines:
        if line.strip() == _GITATTR_MARKER:
            skip = True
            continue
        if skip and (line.startswith("#") or line.strip() == ""):
            skip = False
        if not skip:
            out.append(line)
    ga.write_text("".join(out), encoding="utf-8")


# ---------------------------------------------------------------------------
# git-crypt helpers
# ---------------------------------------------------------------------------

def _require_git_crypt() -> None:
    if shutil.which("git-crypt") is None:
        print("[Identity] ERROR: git-crypt is not installed or not on PATH.", file=sys.stderr)
        print("  Install via: brew install git-crypt  (macOS)", file=sys.stderr)
        print("               apt-get install git-crypt  (Debian/Ubuntu)", file=sys.stderr)
        sys.exit(1)


def init_git_crypt(workspace: Path, identity_dir: Path) -> None:
    """Run 'git-crypt init' and add identity patterns to .gitattributes."""
    _require_git_crypt()
    result = subprocess.run(
        ["git-crypt", "init"],
        cwd=workspace,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0 and "already initialized" not in result.stderr:
        print(f"[Identity] git-crypt init failed: {result.stderr.strip()}", file=sys.stderr)
        sys.exit(1)
    add_gitattributes(workspace, identity_dir)
    print("[Identity] git-crypt initialised. Run 'git-crypt export-key <keyfile>' to back up your key.")


def export_git_crypt_key(workspace: Path, keyfile: Path) -> None:
    _require_git_crypt()
    result = subprocess.run(
        ["git-crypt", "export-key", str(keyfile)],
        cwd=workspace,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"[Identity] git-crypt export-key failed: {result.stderr.strip()}", file=sys.stderr)
        sys.exit(1)
    print(f"[Identity] Key exported to {keyfile}. Store it securely — losing it means losing access.")


# ---------------------------------------------------------------------------
# sops helpers
# ---------------------------------------------------------------------------

def _require_sops() -> None:
    if shutil.which("sops") is None:
        print("[Identity] ERROR: sops is not installed or not on PATH.", file=sys.stderr)
        print("  Install via: brew install sops  (macOS)", file=sys.stderr)
        print("               https://github.com/getsops/sops/releases  (other)", file=sys.stderr)
        sys.exit(1)


def init_sops(workspace: Path, identity_dir: Path, keyref: str | None = None) -> None:
    _require_sops()
    add_gitattributes(workspace, identity_dir)
    if keyref:
        print(f"[Identity] sops mode enabled. Key reference: {keyref}")
        print("  Ensure .sops.yaml is configured with your KMS/age key.")
    else:
        print("[Identity] sops mode enabled. Configure .sops.yaml with your key reference.")


# ---------------------------------------------------------------------------
# Encryption init wizard (called from cli.py)
# ---------------------------------------------------------------------------

def encryption_init_wizard(workspace: Path, identity_dir: Path, tool: EncryptionTool) -> None:
    """Interactive wizard to set up encryption for the identity store."""
    if tool == "none":
        print("[Identity] No encryption configured (tool=none).")
        return

    # Update workspace.json
    cfg_path = workspace / ".adm" / "config" / "workspace.json"
    if cfg_path.exists():
        data = json.loads(cfg_path.read_text(encoding="utf-8"))
    else:
        data = {}
    data.setdefault("identity", {})["encryption"] = {"tool": tool}
    cfg_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"[Identity] workspace.json updated: identity.encryption.tool = {tool!r}")

    if tool == "git-crypt":
        init_git_crypt(workspace, identity_dir)
    elif tool == "sops":
        init_sops(workspace, identity_dir)
