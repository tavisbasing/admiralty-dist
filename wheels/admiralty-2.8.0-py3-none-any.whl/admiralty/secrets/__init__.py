"""admiralty.secrets — Provider-agnostic secrets access with ACL gating and audit (V6 Enterprise)."""

from .base import SecretsProvider
from .env import EnvSecretsProvider
from .registry import get_provider
from .refs import (
    SecretRef,
    SecretScrubFilter,
    get_scrub_filter,
    install_log_scrub,
    maybe_warn_cleartext,
    parse_ref,
    resolve_ref,
    resolve_secret_refs,
    scan_config_for_cleartext,
)
from .secrets import Secrets

__all__ = [
    "SecretsProvider",
    "EnvSecretsProvider",
    "OsKeyringSecretsProvider",
    "get_provider",
    "Secrets",
    "SecretRef",
    "SecretScrubFilter",
    "get_scrub_filter",
    "install_log_scrub",
    "maybe_warn_cleartext",
    "parse_ref",
    "resolve_ref",
    "resolve_secret_refs",
    "scan_config_for_cleartext",
]


def __getattr__(name: str):  # noqa: N807
    if name == "OsKeyringSecretsProvider":
        from .os_keyring import OsKeyringSecretsProvider
        return OsKeyringSecretsProvider
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
