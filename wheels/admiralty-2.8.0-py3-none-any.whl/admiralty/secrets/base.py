from __future__ import annotations

from abc import ABC, abstractmethod


class SecretsProvider(ABC):
    """Abstract base for secrets backends."""

    @abstractmethod
    def get(self, key: str) -> str | None:
        """Return secret value for key, or None if not found."""

    @abstractmethod
    def set(self, key: str, value: str) -> None:
        """Store secret value for key."""

    @abstractmethod
    def delete(self, key: str) -> None:
        """Delete secret by key. No-op if key does not exist."""

    @abstractmethod
    def list(self) -> list[str]:
        """Return all stored keys. Never returns values."""
