from __future__ import annotations

import json
from pathlib import Path

from .base import SecretsProvider


def _load_enterprise_flag(workspace: Path) -> bool:
    ws_cfg = workspace / ".adm" / "config" / "workspace.json"
    if not ws_cfg.exists():
        return False
    try:
        data = json.loads(ws_cfg.read_text(encoding="utf-8"))
        flag = data.get("enterprise", False)
        if isinstance(flag, bool):
            return flag
        if isinstance(flag, dict):
            return True
        return bool(flag)
    except Exception:
        return False


def get_provider(workspace: Path | None = None) -> SecretsProvider:
    """
    Resolve the active SecretsProvider from workspace.json secretsProvider field.

    workspace.json shape:
        {
          "secretsProvider": {
            "type": "env" | "os_keyring",
            "config": { ... }
          }
        }

    Defaults to EnvSecretsProvider when field is absent.
    """
    if workspace is None:
        cwd = Path.cwd()
        for p in [cwd, *cwd.parents]:
            if (p / ".adm" / "config").is_dir():
                workspace = p
                break
        else:
            workspace = cwd

    provider_cfg: dict = {}
    ws_cfg = workspace / ".adm" / "config" / "workspace.json"
    if ws_cfg.exists():
        try:
            data = json.loads(ws_cfg.read_text(encoding="utf-8"))
            provider_cfg = data.get("secretsProvider") or {}
        except Exception:
            pass

    provider_type = provider_cfg.get("type", "env")
    config = provider_cfg.get("config") or {}

    if provider_type == "os_keyring":
        from .os_keyring import OsKeyringSecretsProvider
        return OsKeyringSecretsProvider(config=config, workspace=workspace)

    if provider_type == "azure_keyvault":
        from .azure_keyvault import AzureKeyVaultSecretsProvider
        return AzureKeyVaultSecretsProvider(config=config)

    if provider_type == "aws_secrets":
        from .aws_secrets import AwsSecretsManagerProvider
        return AwsSecretsManagerProvider(config=config)

    if provider_type == "vault":
        from .vault import HashiCorpVaultProvider
        return HashiCorpVaultProvider(config=config)

    if provider_type == "one_password":
        from .one_password import OnePasswordConnectProvider
        return OnePasswordConnectProvider(config=config)

    # Default: env
    from .env import EnvSecretsProvider
    return EnvSecretsProvider(config=config)
