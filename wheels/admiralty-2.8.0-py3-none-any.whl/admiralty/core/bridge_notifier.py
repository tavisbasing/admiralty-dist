#!/usr/bin/env python3
"""
Bridge Notifier v1.0 — Outbound Slack notifications for Fleet Command.

Sends project-scoped Slack messages when crews need Captain approval or
encounter blockers. Integrates with the fleet monitor's approval scan loop.

Features:
- 5-minute grace timer: only notifies if Captain hasn't responded locally
- Project-scoped channels: each project routes to its own Slack channel
- Rich Block Kit messages with Approve/Reject action buttons
- Duplicate prevention via notified.json state file
- Immediate notification bypass for BLOCKED status (configurable)
- Zero external dependencies (uses urllib.request for Slack API)

Usage:
    from bridge_notifier import BridgeNotifier
    notifier = BridgeNotifier(admiralty_dir)
    notifier.check_and_notify(approval_items, escalation_items)
"""

import json
import os
import re
import time
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

try:
    from admiralty.egress.filter import EgressDenied, is_host_allowed
    _EGRESS_AVAILABLE = True
except ImportError:
    _EGRESS_AVAILABLE = False
    # Define a dedicated dummy type — aliasing to Exception would make any
    # later `except EgressDenied:` clause swallow unrelated errors and
    # mis-report them as egress denials.
    class EgressDenied(Exception):  # type: ignore[no-redef]
        pass


class BridgeNotifier:
    """Manages outbound Slack notifications with grace period tracking."""

    def __init__(self, admiralty_dir: Path):
        self.admiralty_dir = admiralty_dir
        self.bridge_dir = admiralty_dir / "bridge"
        self.state_file = self.bridge_dir / "notified.json"
        self.log_file = admiralty_dir / "logs" / "bridge.log"
        self.settings = self._load_settings()
        self._state = self._load_state()

    # -----------------------------------------------------------------
    # Configuration
    # -----------------------------------------------------------------

    def _load_settings(self) -> Dict:
        """Load bridge settings, resolving env var placeholders."""
        config_path = self.admiralty_dir / "config" / "bridge-settings.json"
        if not config_path.exists():
            return {"bridge": {"enabled": False}}

        try:
            raw = config_path.read_text(encoding="utf-8")
            settings = json.loads(raw)
        except Exception:
            return {"bridge": {"enabled": False}}

        try:
            from admiralty.secrets.refs import resolve_secret_refs, install_log_scrub
            install_log_scrub()
            settings = resolve_secret_refs(settings, self.admiralty_dir.parent)
        except Exception:
            pass

        return settings

    def _resolve_env(self, value: str) -> str:
        """Resolve ${VAR} placeholders from environment variables."""
        if not isinstance(value, str):
            return value
        match = re.match(r'^\$\{(\w+)\}$', value)
        if match:
            return os.environ.get(match.group(1), "")
        return value

    @property
    def enabled(self) -> bool:
        return self.settings.get("bridge", {}).get("enabled", False)

    @property
    def bot_token(self) -> str:
        return self._resolve_env(
            self.settings.get("bridge", {}).get("slack", {}).get("botToken", "")
        )

    @property
    def grace_period_minutes(self) -> int:
        return self.settings.get("bridge", {}).get("notifications", {}).get(
            "gracePeriodMinutes", 5
        )

    @property
    def immediate_on_blocked(self) -> bool:
        return self.settings.get("bridge", {}).get("notifications", {}).get(
            "immediateOnBlocked", True
        )

    @property
    def include_approvals(self) -> bool:
        return self.settings.get("bridge", {}).get("notifications", {}).get(
            "includeApprovals", True
        )

    @property
    def include_escalations(self) -> bool:
        return self.settings.get("bridge", {}).get("notifications", {}).get(
            "includeEscalations", True
        )

    def get_channel_for_project(self, project: str) -> Optional[str]:
        """Get the Slack channel for a project, if enabled."""
        projects = self.settings.get("bridge", {}).get("projects", {})
        proj_config = projects.get(project, {})
        if not proj_config.get("enabled", True):
            return None
        return proj_config.get(
            "channel",
            self.settings.get("bridge", {}).get("slack", {}).get("defaultChannel", "")
        )

    # -----------------------------------------------------------------
    # State tracking (grace timer + duplicate prevention)
    # -----------------------------------------------------------------

    def _load_state(self) -> Dict:
        """Load notification state (first-seen times, notified flags)."""
        if not self.state_file.exists():
            return {"items": {}}
        try:
            return json.loads(self.state_file.read_text(encoding="utf-8"))
        except Exception:
            return {"items": {}}

    def _save_state(self):
        """Persist notification state to disk."""
        self.bridge_dir.mkdir(parents=True, exist_ok=True)
        tmp = self.state_file.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(self._state, indent=2), encoding="utf-8")
            tmp.replace(self.state_file)
        except Exception:
            pass

    def _item_key(self, item: Dict) -> str:
        """Generate a unique key for a trackable item."""
        return f"{item.get('type', 'UNK')}:{item.get('id', 'unknown')}"

    def _get_first_seen(self, key: str) -> Optional[float]:
        """Get the epoch timestamp when an item was first seen."""
        return self._state.get("items", {}).get(key, {}).get("first_seen")

    def _mark_first_seen(self, key: str):
        """Record the first time we saw an item."""
        if "items" not in self._state:
            self._state["items"] = {}
        if key not in self._state["items"]:
            self._state["items"][key] = {
                "first_seen": time.time(),
                "notified": False,
            }

    def _is_notified(self, key: str) -> bool:
        """Check if we already sent a notification for this item."""
        return self._state.get("items", {}).get(key, {}).get("notified", False)

    def _mark_notified(self, key: str):
        """Mark an item as having been notified."""
        if key in self._state.get("items", {}):
            self._state["items"][key]["notified"] = True
            self._state["items"][key]["notified_at"] = time.time()

    def _cleanup_resolved(self, current_keys: set):
        """Remove state entries for items that are no longer pending."""
        stale = [k for k in self._state.get("items", {}) if k not in current_keys]
        for k in stale:
            del self._state["items"][k]

    # -----------------------------------------------------------------
    # Grace period logic
    # -----------------------------------------------------------------

    def _grace_period_elapsed(self, key: str) -> bool:
        """Check if the grace period has elapsed for an item."""
        first_seen = self._get_first_seen(key)
        if first_seen is None:
            return False
        elapsed_minutes = (time.time() - first_seen) / 60
        return elapsed_minutes >= self.grace_period_minutes

    # -----------------------------------------------------------------
    # Slack API
    # -----------------------------------------------------------------

    def _slack_post(self, channel: str, blocks: List[Dict],
                    text: str = "") -> bool:
        """Post a message to Slack using the Bot API. Returns True on success."""
        token = self.bot_token
        if not token:
            self._log("ERROR", "No Slack bot token configured")
            return False

        payload = {
            "channel": channel,
            "text": text or "Fleet Command notification",
            "blocks": blocks,
        }

        req = urllib.request.Request(
            "https://slack.com/api/chat.postMessage",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json; charset=utf-8",
                "Authorization": f"Bearer {token}",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = json.loads(resp.read().decode("utf-8"))
                if not body.get("ok"):
                    self._log("ERROR", f"Slack API error: {body.get('error', 'unknown')}")
                    return False
                return True
        except EgressDenied as e:
            self._log("ERROR", f"Egress denied for Slack API: {e}")
            return False
        except urllib.error.URLError as e:
            self._log("ERROR", f"Slack request failed: {e}")
            return False

    # -----------------------------------------------------------------
    # Message builders (Slack Block Kit)
    # -----------------------------------------------------------------

    def _build_approval_blocks(self, item: Dict) -> List[Dict]:
        """Build rich Slack blocks for an approval notification."""
        project = item.get("project", "?")
        item_type = item.get("type", "UNKNOWN")
        item_id = item.get("id", "?")
        title = item.get("title", "")
        note = item.get("note", "")

        header_text = f":anchor: [{project}] {item_type} Awaiting Approval"

        blocks = [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": header_text, "emoji": True}
            },
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*Project:*\n{project}"},
                    {"type": "mrkdwn", "text": f"*Type:*\n{item_type}"},
                    {"type": "mrkdwn", "text": f"*ID:*\n`{item_id}`"},
                ]
            },
        ]

        if title:
            blocks.append({
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"*Title:* {title}"}
            })

        if note:
            blocks.append({
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"*Note:* {note}"}
            })

        # Action buttons
        blocks.append({
            "type": "actions",
            "block_id": f"approval_{item_id}",
            "elements": [
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Approve", "emoji": True},
                    "style": "primary",
                    "action_id": "bridge_approve",
                    "value": json.dumps({"id": item_id, "project": project, "action": "approve"}),
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Reject", "emoji": True},
                    "style": "danger",
                    "action_id": "bridge_reject",
                    "value": json.dumps({"id": item_id, "project": project, "action": "reject"}),
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "View Details", "emoji": True},
                    "action_id": "bridge_details",
                    "value": json.dumps({"id": item_id, "project": project, "path": item.get("path", "")}),
                },
            ]
        })

        blocks.append({
            "type": "context",
            "elements": [
                {"type": "mrkdwn", "text": f"Fleet Command Bridge | {datetime.now().strftime('%H:%M:%S')}"}
            ]
        })

        return blocks

    def _build_escalation_blocks(self, escalation: Dict) -> List[Dict]:
        """Build rich Slack blocks for an escalation notification."""
        esc_id = escalation.get("id", "?")
        title = escalation.get("title", "Unknown escalation")
        project = escalation.get("project", "?")
        blocking = escalation.get("blocking", False)
        severity = escalation.get("severity", "MEDIUM")

        emoji = ":rotating_light:" if blocking else ":warning:"
        header = f"{emoji} [{project}] Escalation: {title[:40]}"

        blocks = [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": header, "emoji": True}
            },
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*ID:*\n`{esc_id}`"},
                    {"type": "mrkdwn", "text": f"*Project:*\n{project}"},
                    {"type": "mrkdwn", "text": f"*Severity:*\n{severity}"},
                    {"type": "mrkdwn", "text": f"*Blocking:*\n{'YES' if blocking else 'No'}"},
                ]
            },
        ]

        if escalation.get("description"):
            blocks.append({
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"*Details:*\n{escalation['description'][:300]}"}
            })

        blocks.append({
            "type": "actions",
            "block_id": f"escalation_{esc_id}",
            "elements": [
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Acknowledge", "emoji": True},
                    "style": "primary",
                    "action_id": "bridge_ack_escalation",
                    "value": json.dumps({"id": esc_id, "project": project}),
                },
            ]
        })

        blocks.append({
            "type": "context",
            "elements": [
                {"type": "mrkdwn", "text": f"Fleet Command Bridge | {datetime.now().strftime('%H:%M:%S')}"}
            ]
        })

        return blocks

    def _build_blocked_blocks(self, crew_num: int, order_id: str,
                               project: str, reason: str = "") -> List[Dict]:
        """Build Slack blocks for a crew BLOCKED notification."""
        blocks = [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": f":octagonal_sign: [{project}] Crew {crew_num} BLOCKED", "emoji": True}
            },
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*Order:*\n`{order_id}`"},
                    {"type": "mrkdwn", "text": f"*Project:*\n{project}"},
                    {"type": "mrkdwn", "text": f"*Crew:*\n{crew_num}"},
                ]
            },
        ]

        if reason:
            blocks.append({
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"*Reason:*\n{reason[:500]}"}
            })

        blocks.append({
            "type": "context",
            "elements": [
                {"type": "mrkdwn", "text": f"Fleet Command Bridge | {datetime.now().strftime('%H:%M:%S')}"}
            ]
        })

        return blocks

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------

    def check_and_notify(self, approval_items: List[Dict],
                         escalation_items: Optional[List[Dict]] = None):
        """Main entry point — called by fleet_monitor on each refresh cycle.

        Tracks first-seen time for each item. Sends Slack notification only
        after the grace period has elapsed without local resolution.
        """
        if not self.enabled:
            return

        escalation_items = escalation_items or []
        current_keys = set()
        state_changed = False

        # Process approval items
        if self.include_approvals:
            for item in approval_items:
                key = self._item_key(item)
                current_keys.add(key)
                self._mark_first_seen(key)

                if self._is_notified(key):
                    continue

                if self._grace_period_elapsed(key):
                    channel = self.get_channel_for_project(item.get("project", "?"))
                    if channel:
                        blocks = self._build_approval_blocks(item)
                        text = f"[{item.get('project')}] {item.get('type')} {item.get('id')} awaiting approval"
                        if self._slack_post(channel, blocks, text):
                            self._mark_notified(key)
                            self._log("INFO", f"Notified: {key} -> {channel}")
                            state_changed = True

        # Process escalations
        if self.include_escalations:
            for esc in escalation_items:
                key = f"ESC:{esc.get('id', 'unknown')}"
                current_keys.add(key)
                self._mark_first_seen(key)

                if self._is_notified(key):
                    continue

                # Blocking escalations bypass grace period
                if esc.get("blocking") or self._grace_period_elapsed(key):
                    project = esc.get("project", "?")
                    channel = self.get_channel_for_project(project)
                    if channel:
                        blocks = self._build_escalation_blocks(esc)
                        text = f"[{project}] Escalation: {esc.get('title', '?')}"
                        if self._slack_post(channel, blocks, text):
                            self._mark_notified(key)
                            self._log("INFO", f"Notified escalation: {key} -> {channel}")
                            state_changed = True

        # Cleanup resolved items
        old_count = len(self._state.get("items", {}))
        self._cleanup_resolved(current_keys)
        if len(self._state.get("items", {})) != old_count:
            state_changed = True

        if state_changed:
            self._save_state()

    def notify_crew_blocked(self, crew_num: int, order_id: str,
                            project: str, reason: str = ""):
        """Send an immediate BLOCKED notification (bypasses grace period).

        Called by the stop hook when a crew signals <promise>BLOCKED</promise>.
        """
        if not self.enabled or not self.immediate_on_blocked:
            return

        channel = self.get_channel_for_project(project)
        if not channel:
            return

        blocks = self._build_blocked_blocks(crew_num, order_id, project, reason)
        text = f"[{project}] Crew {crew_num} BLOCKED on {order_id}"
        if self._slack_post(channel, blocks, text):
            self._log("INFO", f"BLOCKED notification: crew{crew_num} {order_id} -> {channel}")

    def send_question(self, question: str, project: str = "") -> bool:
        """Send a Quartermaster question to Slack so the Captain can respond remotely.

        Called by the bridge-question hook when AskUserQuestion fires in a QM session.
        Uses the project channel if available, otherwise falls back to defaultChannel.
        """
        if not self.enabled:
            return False

        # Resolve channel: project-scoped if available, else default
        channel = ""
        if project:
            channel = self.get_channel_for_project(project) or ""
        if not channel:
            channel = self._resolve_env(
                self.settings.get("bridge", {}).get("slack", {}).get("defaultChannel", "")
            )
        if not channel:
            self._log("ERROR", "send_question: no channel configured")
            return False

        blocks = self._build_question_blocks(question, project)
        text = f":raising_hand: QM Question: {question[:80]}"
        ok = self._slack_post(channel, blocks, text)
        if ok:
            self._log("INFO", f"Question relayed to {channel}: {question[:80]}")
        return ok

    def _build_question_blocks(self, question: str, project: str = "") -> List[Dict]:
        """Build Slack Block Kit message for a QM question."""
        header = ":raising_hand: Quartermaster Question"
        if project:
            header = f":raising_hand: [{project}] Quartermaster Question"

        blocks = [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": header, "emoji": True}
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": question[:3000]}
            },
            {
                "type": "context",
                "elements": [
                    {"type": "mrkdwn", "text": f"Fleet Command Bridge | {datetime.now().strftime('%H:%M:%S')}"}
                ]
            },
        ]
        return blocks

    def send_test_notification(self, project: str) -> bool:
        """Send a test notification to verify Slack connectivity."""
        channel = self.get_channel_for_project(project)
        if not channel:
            print(f"[Bridge] No channel configured for project '{project}'")
            return False

        blocks = [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": ":test_tube: Fleet Command Bridge — Test", "emoji": True}
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"Bridge connectivity test for project *{project}*.\nIf you see this, notifications are working!"}
            },
            {
                "type": "context",
                "elements": [
                    {"type": "mrkdwn", "text": f"Fleet Command Bridge | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"}
                ]
            },
        ]

        return self._slack_post(channel, blocks, f"[{project}] Bridge test notification")

    def send_question(self, question_text: str, session_id: str) -> bool:
        """Post a QM question to Slack (#fleet-command channel) awaiting Captain response.

        Args:
            question_text: The question the QM is asking the Captain.
            session_id: The current crew session identifier (e.g. crew1, order ID).

        Returns:
            True if the message was posted successfully, False otherwise.
        """
        default_channel = self.settings.get("bridge", {}).get("slack", {}).get(
            "defaultChannel", ""
        )
        if not default_channel:
            self._log("ERROR", "send_question: no defaultChannel configured")
            return False

        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": ":speech_balloon: Quartermaster Question — Awaiting Captain Response",
                    "emoji": True,
                }
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": question_text}
            },
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": (
                            f"Session: `{session_id}` | "
                            f"Fleet Command Bridge | "
                            f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                        )
                    }
                ]
            },
        ]

        text = f"[QM Question] {question_text[:120]}"
        success = self._slack_post(default_channel, blocks, text)
        if success:
            self._log("INFO", f"Question posted: session={session_id} -> {default_channel}")
        return success

    def get_status(self) -> Dict:
        """Return bridge status info for the dashboard."""
        token = self.bot_token
        return {
            "enabled": self.enabled,
            "connected": bool(token),
            "pending_notifications": sum(
                1 for v in self._state.get("items", {}).values()
                if not v.get("notified", False)
            ),
            "total_tracked": len(self._state.get("items", {})),
        }

    # -----------------------------------------------------------------
    # Logging
    # -----------------------------------------------------------------

    def _log(self, level: str, message: str):
        """Append a log entry to the bridge log file."""
        try:
            self.log_file.parent.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(f"[{timestamp}] [{level}] {message}\n")
        except Exception:
            pass  # Fail-open: never block fleet operations for logging
