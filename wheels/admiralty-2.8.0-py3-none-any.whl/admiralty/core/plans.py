"""NAV plan schema parsing and validation."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class NavPlan:
    files_to_modify: list[str] = field(default_factory=list)
    symbols_touched: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    raw_text: str = ""


_IMPACT_MAP_RE = re.compile(
    r"^##\s+(Repository\s+Impact\s+Map|Impact\s+Map)\s*$",
    re.IGNORECASE | re.MULTILINE,
)
_ASSUMPTIONS_RE = re.compile(
    r"^##\s+Assumptions\s+made\b[^\n]*$",
    re.IGNORECASE | re.MULTILINE,
)
_SECTION_RE = re.compile(r"^##\s+\S", re.MULTILINE)
_BULLET_RE = re.compile(r"^\s*[-*]\s+(.+)", re.MULTILINE)


def _extract_section_body(text: str, header_match: re.Match) -> str:
    """Return the text between a matched section header and the next ## section."""
    start = header_match.end()
    next_section = _SECTION_RE.search(text, start)
    end = next_section.start() if next_section else len(text)
    return text[start:end]


def _parse_bullets(body: str) -> list[str]:
    return [m.group(1).strip() for m in _BULLET_RE.finditer(body)]


def parse_nav_plan(path: str | Path, order_id: str = "") -> NavPlan:
    """Parse a NAV plan markdown file and return a NavPlan dataclass.

    Emits NAV_PLAN_SCHEMA_WARN lifecycle events when required sections are
    missing (warn-only in v2.7.0 — does not block dispatch).
    """
    raw = Path(path).read_text(encoding="utf-8")
    plan = NavPlan(raw_text=raw)

    impact_match = _IMPACT_MAP_RE.search(raw)
    assumptions_match = _ASSUMPTIONS_RE.search(raw)

    missing: list[str] = []

    if impact_match:
        body = _extract_section_body(raw, impact_match)
        bullets = _parse_bullets(body)
        # Parser strategy: if the Impact Map has `### Files...` / `### Symbols...`
        # sub-headings, parse each sub-section's bullets into the matching field.
        # Otherwise treat every bullet in the section as a file path — operators
        # who omit sub-headings tend to be listing files, not splitting symbols
        # out separately. Promote to the stricter "first block = files, second
        # = symbols" heuristic in v2.8.0 once schema is mandatory (per plan).
        sub_files = re.search(r"###\s+Files", body, re.IGNORECASE)
        sub_sym = re.search(r"###\s+Symbols", body, re.IGNORECASE)
        if sub_files or sub_sym:
            # Parse sub-sections separately
            boundaries = sorted(
                [m.start() for m in re.finditer(r"^###\s+", body, re.MULTILINE)]
                + [len(body)]
            )
            for i, bstart in enumerate(boundaries[:-1]):
                chunk = body[bstart:boundaries[i + 1]]
                header_line = chunk.split("\n", 1)[0].lower()
                chunk_bullets = _parse_bullets(chunk)
                if "file" in header_line:
                    plan.files_to_modify = chunk_bullets
                elif "symbol" in header_line:
                    plan.symbols_touched = chunk_bullets
        else:
            plan.files_to_modify = bullets
    else:
        missing.append("Repository Impact Map")

    if assumptions_match:
        body = _extract_section_body(raw, assumptions_match)
        plan.assumptions = _parse_bullets(body)
    else:
        missing.append("Assumptions made")

    if missing:
        _emit_warnings(missing, order_id)

    return plan


def _emit_warnings(missing: list[str], order_id: str) -> None:
    try:
        from admiralty.core.fleet_runner import write_lifecycle_event
    except Exception:
        return

    for section in missing:
        tag = f" [{order_id}]" if order_id else ""
        write_lifecycle_event(
            "NAV_PLAN_SCHEMA_WARN",
            f"Missing section '{section}' in NAV plan{tag}",
        )
