"""
admiralty/core/gates.py — Human review gate configuration and checks.

Reads .adm/config/gates.json to determine whether an order should pause
for human review after NAV completes (before SHP picks it up).
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Literal


_DEFAULT_GATE_CONFIG: Dict[str, Any] = {
    "post_nav_review": {
        "enabled": False,
        "exempt_priorities": ["LOW"],
        "auto_approve_after_hours": 0,
    }
}


def _get_admiralty_dir() -> Path:
    """Import-time safe reference — avoids circular import with fleet_runner."""
    try:
        from admiralty.core.fleet_runner import get_admiralty_dir
        return get_admiralty_dir()
    except Exception:
        return Path(".adm")


def load_gate_config(adm_dir: Path | None = None) -> Dict[str, Any]:
    """Load .adm/config/gates.json, returning the default config when missing."""
    if adm_dir is None:
        adm_dir = _get_admiralty_dir()
    gates_file = adm_dir / "config" / "gates.json"
    if not gates_file.exists():
        return json.loads(json.dumps(_DEFAULT_GATE_CONFIG))
    try:
        return json.loads(gates_file.read_text(encoding="utf-8"))
    except Exception:
        return json.loads(json.dumps(_DEFAULT_GATE_CONFIG))


def gate_check_post_nav(
    order_data: Dict[str, Any],
    config: Dict[str, Any],
) -> Literal["advance", "pause"]:
    """Return 'pause' or 'advance' for an order that just completed NAV.

    Per-order override wins over workspace default:
      gates: ["nav_human_review"]        → always pause
      gates: ["skip_nav_human_review"]   → always advance
    Workspace default:
      enabled=true + priority not in exempt_priorities → pause
    Otherwise: advance.
    """
    order_gates: list[str] = order_data.get("gates", [])
    if "nav_human_review" in order_gates:
        return "pause"
    if "skip_nav_human_review" in order_gates:
        return "advance"

    gate_cfg = config.get("post_nav_review", {})
    if not gate_cfg.get("enabled", False):
        return "advance"

    priority = order_data.get("priority", "NORMAL")
    exempt = gate_cfg.get("exempt_priorities", [])
    if priority in exempt:
        return "advance"

    return "pause"


def should_auto_approve(
    order_data: Dict[str, Any],
    config: Dict[str, Any],
    paused_at: str,
) -> bool:
    """Return True if the order has been paused long enough for auto-approval.

    paused_at is an ISO-8601 timestamp string written when the order was moved
    to queues/review/.  Returns False when auto_approve_after_hours is 0.
    """
    gate_cfg = config.get("post_nav_review", {})
    hours = gate_cfg.get("auto_approve_after_hours", 0)
    if not hours:
        return False
    try:
        paused_dt = datetime.fromisoformat(paused_at)
    except (ValueError, TypeError):
        return False
    return datetime.now() >= paused_dt + timedelta(hours=hours)
