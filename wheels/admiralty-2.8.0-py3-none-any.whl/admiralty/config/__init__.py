# admiralty.config — Fleet Command System default configuration
