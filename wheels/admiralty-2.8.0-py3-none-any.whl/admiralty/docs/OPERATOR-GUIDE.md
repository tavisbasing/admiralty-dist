# Admiralty — Operator Guide

> For teams running Admiralty in production. Covers day-to-day operations, scaling, cost control, failure handling, notifications, and reporting. For initial setup, see [GETTING-STARTED.md](GETTING-STARTED.md).

> **Version scope:** This guide covers features through **v2.4.0**. Commands and flags marked with a version tag (e.g., `--retry-failed` in a planned release, `admiralty replay/export/notify` in a planned release) are not yet available in the current release. Sections describing future features are included so operators can plan ahead.

---

## Contents

1. [Daily Operations](#1-daily-operations)
2. [Scaling Crews](#2-scaling-crews)
3. [Cost Management](#3-cost-management)
4. [Handling Failures](#4-handling-failures)
5. [Backup Strategy](#5-backup-strategy)
6. [Notification Setup](#6-notification-setup)
7. [Multi-Project Operations](#7-multi-project-operations)
8. [Performance Tuning](#8-performance-tuning)
9. [Team Workflows](#9-team-workflows)
10. [Reporting](#10-reporting)
11. [Acceptance Criteria](#11-acceptance-criteria)

---

## 1. Daily Operations

### Morning checklist

Start each day by reviewing the current fleet state:

```bash
# Check overall fleet status
admiralty status --once

# Check pending orders
admiralty status --once --compact

# Review token usage since yesterday
admiralty usage --summary
```

### Dispatching work

Queue orders for the day, then launch the dispatcher:

```bash
# Standard launch — up to 3 concurrent crews
admiralty dispatch --max-crews 3

# Clean up any stale state from previous runs first
admiralty dispatch --cleanup --max-crews 3
```

The dispatcher runs until all queued orders are processed or the session is interrupted. Leave it running in a dedicated terminal; it manages itself.

### Monitoring running crews

```bash
# Live dashboard (auto-refreshes)
admiralty status

# Watch a specific crew
admiralty crew --crew 1 --watch

# One-shot snapshot (for scripting)
admiralty status --once
```

The **APPROVALS** panel appears in the dashboard when items are waiting for your sign-off — voyages, plans, or requirements with `AWAITING_APPROVAL` status. Review these promptly; crews may be blocked waiting for your decision.

The **ESCALATIONS** panel appears when a crew has raised a blocking issue it cannot resolve autonomously. Check `.admiralty/queues/escalations/` for details and take the indicated action.

### End-of-day shutdown

The dispatcher will stop itself when all queues are drained. If you need to stop it early:

```bash
# Check whether dispatcher is still running
admiralty status --once

# If crews are stalled, clean up
admiralty cleanup
```

`admiralty cleanup` creates an automatic backup before removing stale state — your work is safe.

### Checking completed work

```bash
# List completed orders
ls .admiralty/orders/complete/

# Review a specific order
cat .admiralty/orders/complete/FTR-MYPROJ-2026-0001.json

# Check what changed (crews commit to voyage branches)
git log --oneline voyage/VOY-MYPROJ-2026-0001
```

---

## 2. Scaling Crews

### Concurrency limits

Admiralty supports 1–5 concurrent crews. The right number depends on your API tier and the nature of the work:

| Crew count | Suitable for |
|-----------|-------------|
| 1–2 | Exploratory work, tight budget, sequential dependencies |
| 3 | Standard daily operations — balances throughput and rate pressure |
| 4–5 | Large voyages with independent parallel orders; high-tier API access |

```bash
# Run 5 crews in parallel
admiralty dispatch --max-crews 5

# Conservative: 2 crews for sensitive or high-cost orders
admiralty dispatch --max-crews 2
```

### Stagger delay

When launching multiple crews, Admiralty staggers crew starts to reduce API rate pressure. The default is 30 seconds between crew launches:

```bash
# Slower stagger for large crews or shared API keys
admiralty dispatch --max-crews 5 --stagger-delay 60

# Faster stagger if you have a high rate limit
admiralty dispatch --max-crews 5 --stagger-delay 15
```

### Per-crew timeouts

The default crew timeout is 90 minutes. Complex orders (large features, full test suites) may need more:

```bash
# Allow 3 hours per crew for complex orders
admiralty dispatch --max-crews 3 --timeout 180

# Shorter timeout for documentation or investigation orders
admiralty dispatch --max-crews 5 --timeout 45
```

When a crew exceeds its timeout, it is marked failed and the order is moved to the retry queue. Automatic retry behavior is determined by the dispatcher; failed orders are retried until they succeed or are manually removed from the queue.

> **Planned:** The `--retry-failed N` flag will allow bounding automatic retries:
> ```bash
> admiralty dispatch --max-crews 3 --retry-failed 2
> ```

### Queue priority

The dispatcher processes queues in priority order. If you need work done urgently, place the order in a higher-priority queue:

| Queue | Priority | Use for |
|-------|---------|---------|
| `queues/explicit/` | Highest | Captain-directed urgent work |
| `queues/security/` | High | Security findings |
| `queues/bugs/` | High | Production bugs |
| `queues/requests/` | Medium-High | User-facing requests |
| `queues/orders/` | Medium | Standard feature work |
| `queues/defects/` | Medium-Low | Non-critical defects |
| `queues/breakdown/` | Low | Sub-tasks broken down from higher-level work |
| `queues/high-level/` | Lowest | High-level work awaiting breakdown |

```bash
# Place an order in the explicit queue for immediate pickup
cp .admiralty/queues/orders/BUG-MYPROJ-2026-0042.json .admiralty/queues/explicit/
```

### Horizontal scaling considerations

Each crew runs as an independent `claude` subprocess. On a shared machine, ensure:

- Sufficient RAM: each crew session consumes ~500MB–1GB
- Your API key has sufficient rate limits for your crew count
- Use `--stagger-delay` to spread API calls in time

---

## 3. Cost Management

### Understanding billing modes

Admiralty supports two billing modes, configured in `.admiralty/config/fleet-settings.json`:

| Mode | How cost is counted | Use when |
|------|-------------------|---------|
| `api` | USD cost based on token pricing | Paying per-token via Anthropic API |
| `max` | Token count against a daily cap | On a Claude Max subscription with token limits |

### Checking costs

```bash
# Overall usage summary
admiralty usage --summary

# Breakdown by voyage
admiralty usage --voyage VOY-MYPROJ-2026-0001

# Token detail for a specific order
admiralty usage --order FTR-MYPROJ-2026-0001

# Full usage report to file
admiralty usage --report --output .admiralty/reports/usage-$(date +%Y-%m-%d).md
```

### Setting budget limits

Configure a daily budget in `.admiralty/config/fleet-settings.json`:

```json
{
  "billingMode": "api",
  "budget": 50.00,
  "dailyTokenCap": 0
}
```

When usage reaches 80% of the budget, a `budget-warning` notification fires. At 100%, a `budget-exceeded` notification fires. See [Notification Setup](#6-notification-setup) for how to receive these alerts.

For `max` billing mode:

```json
{
  "billingMode": "max",
  "budget": 0,
  "dailyTokenCap": 5000000
}
```

### Cost-efficient order design

- **Scope orders tightly.** A single focused order (one endpoint, one component) is faster and cheaper than a broad order.
- **Use lower-complexity roles for lower-complexity work.** Lookout (Haiku) is significantly cheaper than Navigator or Shipwright (Sonnet) for investigation tasks.
- **Group documentation orders.** `DOC` orders are cheap; batch them together in one voyage rather than dispatching individually.
- **Set `--timeout` appropriately.** Long timeouts allow crews to explore when they're stuck; short timeouts force faster completion or escalation.
- **Review `export roi`.** The ROI export shows which order types deliver the most value per dollar spent. Use this to guide your backlog priorities.

### Exporting cost data

```bash
# Export all order costs to CSV
admiralty export orders --format csv --output orders-cost.csv

# ROI analysis for the last month
admiralty export roi --hourly-rate 150 --from 2026-04-01 --to 2026-04-30 --output roi-april.csv

# Usage breakdown by day
admiralty export usage --format csv --output usage.csv
```

---

## 4. Handling Failures

### Types of failure

| Failure type | Symptom | Action |
|-------------|---------|--------|
| Crew crash | Crew status shows CRASHED | Run `admiralty cleanup`, then `admiralty dispatch` |
| Order timeout | Order marked FAILED after timeout | Replay with `admiralty replay` |
| Dependency block | Order shows QUEUED but not picked up | Check `dependsOn` fields; ensure prerequisites are complete |
| API error | Crew exits with API error in activity | Check API key, rate limits; retry after a pause |
| Escalation | ESCALATIONS panel appears in dashboard | Read escalation file, take indicated action, re-dispatch |

### Checking what went wrong

```bash
# Check crew activity for a specific crew
cat .admiralty/crews/crew2/activity.txt

# Check crew progress log
cat .admiralty/crews/crew2/progress.md

# List failed orders
ls .admiralty/orders/failed/

# Inspect a failed order
cat .admiralty/orders/failed/FTR-MYPROJ-2026-0001.json

# Check escalations
ls .admiralty/queues/escalations/
cat .admiralty/queues/escalations/ESC-MYPROJ-2026-0001.json
```

### Replaying a failed order

Use `admiralty replay` to re-queue a failed or stalled order for another attempt:

```bash
# Re-queue a single order
admiralty replay FTR-MYPROJ-2026-0001

# Replay with a different role (e.g. escalate to Coxswain for integration issues)
admiralty replay FTR-MYPROJ-2026-0001 --role COX

# Replay all failed orders from a voyage
admiralty replay --voyage VOY-MYPROJ-2026-0001 --failed-only

# Replay ALL orders from a voyage (re-run the whole voyage)
admiralty replay --voyage VOY-MYPROJ-2026-0001
```

The original order is preserved in `.admiralty/orders/failed/` before re-queuing. A `retryCount` field is incremented on each replay.

### Automatic retry limits

When dispatching, use `--retry-failed` to cap how many times a crashing order is automatically retried:

```bash
# Orders that crash more than 3 times are permanently failed
admiralty dispatch --max-crews 3 --retry-failed 3
```

Without `--retry-failed`, crashed orders are retried indefinitely. Setting a limit prevents a bad order from consuming repeated compute budget.

### Handling stale state

After an unexpected interruption (machine restart, OOM kill, network loss), clean up before re-dispatching:

```bash
admiralty cleanup
admiralty dispatch --max-crews 3
```

`cleanup` will:
1. Create a full backup snapshot
2. Terminate any orphaned crew processes
3. Remove stale lock files
4. Reset idle crew state

---

## 5. Backup Strategy

### What gets backed up

The `admiralty backup` command archives:

- All orders (active, complete, failed)
- All voyages (active, complete)
- Plans, handoffs, and requirements
- Usage records
- Workspace configuration

Framework scripts (`.admiralty/core/`) are excluded — they are provided by pip or the submodule and do not need backup.

### Recommended backup schedule

| Frequency | Command | Rationale |
|-----------|---------|-----------|
| Before each cleanup | Automatic | `admiralty cleanup` creates a backup automatically |
| End of each voyage | Manual | Capture the complete voyage state |
| Weekly | Cron / scheduled | Safety net for continuous workspaces |
| Before framework upgrades | Manual | Preserve state before upgrading Admiralty |

### Creating backups

```bash
# Full workspace backup
admiralty backup

# Single project (multi-project workspaces)
admiralty backup --project OTM

# Custom output directory
admiralty backup --output /mnt/backups/admiralty/

# List existing backups
admiralty backup --list
```

Backups are ZIP archives named with the scope and timestamp:
```
admiralty-backups/admiralty-backup-all-2026-04-01-090000.zip
```

### Restoring from backup

Always preview before restoring into an active workspace:

```bash
# Preview what would be restored
admiralty restore admiralty-backup-all-2026-04-01-090000.zip --dry-run

# Restore, skipping files that already exist (default — safe)
admiralty restore admiralty-backup-all-2026-04-01-090000.zip

# Restore only one project from a full backup
admiralty restore admiralty-backup-all-2026-04-01-090000.zip --project OTM

# Overwrite existing files unconditionally (use for clean slate restore)
admiralty restore admiralty-backup-all-2026-04-01-090000.zip --force

# Keep the newer file when conflicts occur (use for merging two workspaces)
admiralty restore admiralty-backup-all-2026-04-01-090000.zip --merge
```

### Offsite backup strategy

Admiralty backups are local ZIP files. For durable offsite backup:

```bash
# After backup, copy to S3 (example)
admiralty backup --output /tmp/admiralty-backups/
aws s3 cp /tmp/admiralty-backups/ s3://your-bucket/admiralty/ --recursive

# Or to a mounted network drive
admiralty backup --output /mnt/nas/backups/admiralty/
```

For git-tracked workspaces, commit the backup archive to a separate branch or push to a private storage repo.

---

## 6. Notification Setup

### Overview

Admiralty can send webhook notifications when significant fleet events occur. Supported platforms: Slack, Microsoft Teams, Discord, and any service that accepts HTTP POST with a JSON body.

### Adding a webhook

```bash
# Subscribe to all events
admiralty notify add --name my-webhook --url https://hooks.example.com/abc123

# Subscribe to specific events only
admiralty notify add --name slack-ops --url https://hooks.slack.com/services/... \
  --events voyage-complete,crew-crash,budget-warning

# Teams webhook
admiralty notify add --name teams-alerts \
  --url https://yourorg.webhook.office.com/webhookb2/... \
  --events order-failed,budget-exceeded,dispatch-complete
```

### Available events

| Event | Fires when |
|-------|-----------|
| `order-complete` | A crew completes an order successfully |
| `order-failed` | An order is permanently failed or stalled |
| `crew-crash` | A crew process crashes unexpectedly |
| `voyage-complete` | All orders in a voyage are complete |
| `budget-warning` | Usage reaches 80% of the configured budget |
| `budget-exceeded` | Usage reaches 100% of the configured budget |
| `approval-needed` | A plan or voyage is awaiting captain sign-off |
| `dispatch-complete` | All queues are drained and all crews are idle |

Omit `--events` to subscribe to all events.

### Listing and testing webhooks

```bash
# List all configured webhooks
admiralty notify list

# Send a test payload to verify connectivity
admiralty notify test slack-ops
```

The test command sends a synthetic payload to confirm the URL is reachable. No real fleet event is generated.

### Removing a webhook

```bash
admiralty notify remove slack-ops
```

### Webhook payload format

All webhook payloads share a common envelope:

```json
{
  "event": "voyage-complete",
  "timestamp": "2026-04-01T09:15:00Z",
  "admiraltyVersion": "2.0.0",
  "data": {
    "voyageId": "VOY-MYPROJ-2026-0001",
    "title": "Sprint 1 features",
    "ordersComplete": 5,
    "totalTokens": 450000,
    "totalCostUSD": 3.20,
    "billingMode": "api",
    "totalDurationMinutes": 87
  }
}
```

For Slack, Teams, and Discord URLs, the payload is automatically adapted to include a human-readable summary line in the platform's native format. Generic webhook URLs receive the raw Admiralty JSON payload unchanged.

### Configuration file

Webhook configuration is stored in `.admiralty/config/webhooks.json`. You can edit this file directly to manage multiple webhooks:

```json
{
  "webhooks": [
    {
      "name": "slack-ops",
      "url": "https://hooks.slack.com/services/T.../B.../xxx",
      "events": ["voyage-complete", "crew-crash", "budget-warning"]
    },
    {
      "name": "teams-alerts",
      "url": "https://yourorg.webhook.office.com/webhookb2/...",
      "events": []
    }
  ]
}
```

An empty `events` list subscribes the webhook to all events.

---

## 7. Multi-Project Operations

### Workspace structure for multiple projects

A single Admiralty workspace can manage multiple projects simultaneously. Each project has its own:

- Configuration: `.admiralty/config/projects/{ACRONYM}.json`
- Orders: prefixed `{TYPE}-{ACRONYM}-{YEAR}-{SEQ}`
- Voyages: prefixed `VOY-{ACRONYM}-{YEAR}-{SEQ}`
- Repository clone: managed in the directory specified by `projects.json`

### Registering a new project

Edit `.admiralty/config/projects.json` to add the project:

```json
{
  "projects": {
    "PROJ1": {
      "name": "Project One",
      "acronym": "PROJ1",
      "directory": "proj1",
      "repo": "your-org/proj1",
      "org": "your-org",
      "defaultBranch": "main",
      "voyageBranchPattern": "voyage/{VOYAGE-ID}"
    },
    "PROJ2": {
      "name": "Project Two",
      "acronym": "PROJ2",
      "directory": "proj2",
      "repo": "your-org/proj2",
      "org": "your-org",
      "defaultBranch": "main",
      "voyageBranchPattern": "voyage/{VOYAGE-ID}"
    }
  }
}
```

Create a per-project role configuration at `.admiralty/config/projects/PROJ2.json`.

### Dispatching across projects

The dispatcher picks up orders from all projects simultaneously. Orders carry a `project` field that routes them to the correct repo and configuration:

```bash
# Dispatch work across all projects
admiralty dispatch --max-crews 5
```

Crews are assigned to orders from any project. If you need to limit work to a specific project, place only that project's orders in the queues.

### Per-project usage tracking

```bash
# Usage for a specific voyage (project-scoped by voyage ID convention)
admiralty usage --voyage VOY-PROJ1-2026-0001

# Export all orders for PROJ1
admiralty export orders --format csv --output proj1-orders.csv
# Then filter by the "project" column in the CSV
```

### Per-project backups

```bash
# Back up only PROJ1 (leaves PROJ2 data out of the archive)
admiralty backup --project PROJ1

# Restore PROJ1 to a new workspace
admiralty restore admiralty-backup-PROJ1-2026-04-01-090000.zip --project PROJ1
```

### Coordination patterns for multi-project work

**Sequential cross-project dependency:** If work in PROJ2 depends on a completed order in PROJ1, use the `dependsOn` field in the PROJ2 order to reference the PROJ1 order ID. The dispatcher will hold the PROJ2 order until the dependency is complete.

**Dedicated voyage per project:** Keep voyages project-scoped (a single voyage covers only one project). This makes progress tracking, backup scoping, and usage reporting cleaner.

**Role allocation:** If PROJ1 work is all Shipwright orders and PROJ2 work is all Navigator orders, they can run concurrently without role contention.

---

## 8. Performance Tuning

### Dispatcher configuration

The key levers for dispatcher performance are `--max-crews`, `--stagger-delay`, and `--timeout`. See [Scaling Crews](#2-scaling-crews) for guidance on values.

For workspaces with many small orders, increase `--max-crews` and decrease `--stagger-delay`. For workspaces with few large orders, a smaller crew count with a longer timeout is more appropriate.

### Dependency graph design

Orders with `dependsOn` dependencies are held until all prerequisites complete. Poor dependency design creates bottlenecks:

- **Avoid fan-in from many orders to one.** If 10 orders all feed into a single integration order, the integration order cannot start until all 10 finish. Restructure to allow incremental integration.
- **Favour parallel voyages.** Group independent work into separate voyages. The dispatcher picks up work from all voyages simultaneously.
- **Reserve the explicit queue** for unblocking stalled work, not for routine prioritisation.

### Model selection

Each role uses a default model. The models differ significantly in cost and capability:

| Role | Model | Relative cost |
|------|-------|--------------|
| Lookout (LKT) | Haiku 4.5 | Low |
| Navigator (NAV) | Sonnet 4.6 | Medium |
| Shipwright (SHP) | Sonnet 4.6 | Medium |
| Bosun (BOS) | Sonnet 4.6 | Medium |
| Scribe (SCR) | Sonnet 4.6 | Medium |
| Coxswain (COX) | Opus 4.7 | High |

Route investigation and triage work to Lookout to minimise cost. Reserve Coxswain for integration and deployment work that genuinely benefits from Opus-class capability.

### Order scoping for throughput

Well-scoped orders complete faster and cheaper than broad ones. General guidance:

- **One concern per order.** An order to "implement the cart service" is too broad. Break it into: create data model, implement service layer, add API endpoints, write tests.
- **Reference target files explicitly.** Orders with `targetFiles` set allow crews to navigate the codebase faster.
- **Write precise acceptance criteria.** Vague acceptance criteria cause crews to over-explore. Each criterion should be independently verifiable.

### Cache-aware API usage

The Anthropic API caches prompt prefixes, reducing cost and latency for repeated context. Admiralty benefits from this when:

- Your workspace `CLAUDE.md` is stable (cached across all crew sessions)
- Orders within a voyage share large context blocks (project config, role paths)

Avoid changing `CLAUDE.md` or role config files mid-voyage; doing so invalidates the cache and increases per-crew token cost.

---

## 9. Team Workflows

### Captain / operator responsibilities

The **Captain** (human operator) is responsible for:

- Approving voyages, plans, and requirements before crews proceed
- Reviewing escalations and providing direction to unblocked crews
- Merging completed voyage branches back to main
- Monitoring daily usage and cost
- Running `admiralty cleanup` and `admiralty dispatch` to keep the fleet moving

### Handling approvals

When the **APPROVALS** panel appears in the dashboard:

1. Identify the item (voyage, plan, or requirement) listed
2. Read the relevant file in `.admiralty/plans/` or `.admiralty/voyages/active/`
3. Update the `status` field to `APPROVED` or `REJECTED` with a note
4. Crews waiting on the approval will resume automatically on the next dispatch

```bash
# Find files awaiting approval
grep -r "AWAITING_APPROVAL" .admiralty/plans/ .admiralty/voyages/
```

### Code review workflow

Crew output is committed to voyage branches. Typical review flow:

1. `admiralty verify --voyage VOY-MYPROJ-2026-0001` — run build and tests
2. `git log --oneline voyage/VOY-MYPROJ-2026-0001` — review commits
3. Open a pull request from the voyage branch to `main`
4. Review and merge via standard PR process

### Shared workspace (team of operators)

If multiple operators share a single Admiralty workspace:

- Only one operator should run `admiralty dispatch` at a time
- Coordinate on which orders are in which queues before dispatching
- Use the notification system to alert the team when a voyage completes or when approvals are needed (see [Notification Setup](#6-notification-setup))
- Back up the workspace at the end of each operator's session

### Escalation handling protocol

When a crew raises an escalation:

1. The ESCALATIONS panel appears in the dashboard (red)
2. Read the escalation file: `.admiralty/queues/escalations/{ESC-ID}.json`
3. Determine the blocking issue (dependency, ambiguity, permissions, etc.)
4. Take the action indicated: update an order, provide a missing credential, clarify requirements
5. Remove the escalation file once resolved
6. Re-dispatch: `admiralty dispatch --max-crews 3`

---

## 10. Reporting

### Usage reports

```bash
# Console summary (daily use)
admiralty usage --summary

# Per-voyage breakdown
admiralty usage --voyage VOY-MYPROJ-2026-0001

# Full report to markdown (weekly use)
admiralty usage --report --output .admiralty/reports/usage-$(date +%Y-%m-%d).md
```

### Exporting data for external tools

Use `admiralty export` to produce CSV or JSON data suitable for spreadsheets, BI tools, or management reports.

**All completed orders:**
```bash
admiralty export orders --format csv --output orders.csv
```

CSV columns: `orderId, project, type, role, title, status, startedAt, completedAt, tokensInput, tokensOutput, costUSD, hoursEquivalent`

**All voyages with aggregate stats:**
```bash
admiralty export voyages --format csv --output voyages.csv
```

CSV columns: `voyageId, project, title, status, ordersTotal, ordersComplete, ordersStalled, startedAt, completedAt, totalTokens, totalCostUSD, hoursEquivalent`

**Daily token usage breakdown:**
```bash
admiralty export usage --format csv --output usage.csv
```

CSV columns: `date, orderId, crewNumber, totalTokens, tokensInput, tokensOutput, cacheCreationTokens, cacheReadTokens, costUSD`

**ROI summary for management reporting:**
```bash
# Monthly ROI at $150/hr developer rate
admiralty export roi --hourly-rate 150 --format csv --output roi-summary.csv

# Specific date range
admiralty export roi --hourly-rate 150 --from 2026-04-01 --to 2026-04-30 --output roi-april.csv
```

CSV columns: `month, ordersCompleted, apiCostUSD, hoursEquivalent, hoursSaved, valueSavedUSD, roiMultiple`

`roiMultiple` expresses value saved divided by API cost — a `roiMultiple` of 30 means the fleet delivered 30x return on its API spend.

### Date filtering

All export commands accept `--from` and `--to` date filters (inclusive, format `YYYY-MM-DD`):

```bash
# Last quarter
admiralty export orders --from 2026-01-01 --to 2026-03-31 --output q1-orders.csv

# This week
admiralty export usage --from 2026-04-01 --to 2026-04-07 --output this-week.csv
```

### JSON output

All export commands support `--format json` for programmatic consumption:

```bash
admiralty export orders --format json --output orders.json
admiralty export roi --hourly-rate 150 --format json
```

JSON output is an array of flat objects using the same field names as the CSV columns.

### Lifecycle and audit log

The fleet writes lifecycle events to `.admiralty/logs/lifecycle.log` (crew starts, completions, role transitions, failures). This log provides an audit trail of all fleet activity.

```bash
# Recent lifecycle events
tail -50 .admiralty/logs/lifecycle.log

# Filter for failures
grep FAILED .admiralty/logs/lifecycle.log
```

---

---

## 11. Acceptance Criteria

Acceptance criteria give you confidence that completed orders actually meet their definition of done — without manual review of every piece of crew output.

### Writing ACs in orders

Add an `acceptanceCriteria` array to any order. Each item specifies a criterion, how to validate it, and whether a failure should block promotion:

```json
"acceptanceCriteria": [
  {
    "id": "ac-01",
    "description": "All unit tests pass",
    "validationType": "command",
    "command": "python -m pytest -q",
    "severity": "blocking"
  },
  {
    "id": "ac-02",
    "description": "Config file scaffolded at expected path",
    "validationType": "file-exists",
    "path": ".adm/config/role-paths.json",
    "severity": "blocking"
  },
  {
    "id": "ac-03",
    "description": "CHANGELOG entry added",
    "validationType": "manual",
    "severity": "advisory"
  }
]
```

### Validation types

| Type | How BOS validates |
|------|-------------------|
| `command` | Runs the command; exit code 0 = PASS |
| `file-exists` | Checks the path exists after work is done |
| `manual` | BOS inspects the output using its own judgement |

### Severity levels

| Severity | On failure |
|----------|-----------|
| `blocking` (default) | COX hard-stops, moves order to `failed/` |
| `advisory` | COX logs a warning, continues |

### Reviewing results

BOS writes results into the order JSON as `acResults`. To inspect them after a dispatch:

```bash
# View results for a completed order
cat .adm/orders/complete/FTR-MYPROJ-2026-0001.json | python -m json.tool | grep -A 5 acResults
```

A failed blocking criterion looks like:

```json
{
  "id": "ac-01",
  "status": "FAIL",
  "checkedAt": "2026-04-17T14:23:00Z",
  "notes": "pytest: 3 failed, 39 passed"
}
```

### Upgrading existing workspaces

Run `adm update` to add `acceptanceCriteria: []` scaffolding to your order templates and update BOS/COX role prompts with AC gating logic:

```bash
adm update --dry-run   # preview changes
adm update             # apply
```

---

*Admiralty Fleet Command System v2.4.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
