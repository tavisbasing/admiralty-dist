#!/usr/bin/env python3
"""
Fleet PreToolUse Hook v8.1 — Role Permission Enforcement.

Prevents crews from writing files outside their role permissions.
Reads the crew's role from state.json and checks file paths against
the prohibited patterns in role-paths.json.

IMPORTANT: This hook ONLY activates for crew sessions (ADMIRALTY_CREW env set).
The Captain's interactive sessions are NEVER affected.

Fail-open: If role-paths.json or state.json can't be read, the operation is allowed.

Input:  JSON on stdin (from Claude Code hook system)
Output: JSON on stdout with {"decision": "deny", "reason": "..."} to block
        OR exit 0 with no output to allow
"""

import fnmatch
import json
import logging
import os
import sys
from pathlib import Path

logger = logging.getLogger("admiralty.secret_scan")


# Paths that ALL roles are allowed to write to (bypass enforcement)
ALWAYS_ALLOWED = [
    ".adm/crews/*",
    ".adm/handoffs/*",
    ".adm/queues/*",
    ".adm/orders/*",
    # Legacy .admiralty/ paths (backward compat)
    ".admiralty/crews/*",
    ".admiralty/handoffs/*",
    ".admiralty/queues/*",
    ".admiralty/orders/*",
]


def normalize_path(file_path: str, cwd: str) -> str:
    """Normalize a file path to forward slashes relative to project root."""
    path = file_path.replace("\\", "/")

    # Make relative to project root if absolute
    cwd_normalized = cwd.replace("\\", "/").rstrip("/")
    if path.startswith(cwd_normalized):
        path = path[len(cwd_normalized):].lstrip("/")

    return path


def is_always_allowed(rel_path: str) -> bool:
    """Check if path is in the always-allowed list."""
    for pattern in ALWAYS_ALLOWED:
        if fnmatch.fnmatch(rel_path, pattern):
            return True
    return False


def matches_pattern_list(rel_path: str, patterns: list) -> bool:
    """Check if path matches any pattern in a list."""
    for pattern in patterns:
        pattern = pattern.replace("\\", "/")
        if fnmatch.fnmatch(rel_path, pattern):
            return True
    return False


def main():
    try:
        # ===================================================================
        # STEP 1: Read hook input from stdin
        # ===================================================================
        raw_input = sys.stdin.read()
        hook_input = json.loads(raw_input) if raw_input.strip() else {}
    except Exception:
        sys.exit(0)  # Can't parse — allow

    # ===================================================================
    # STEP 2: Check if this is a crew session
    # ===================================================================
    crew_str = os.environ.get("ADMIRALTY_CREW")
    if not crew_str:
        sys.exit(0)  # Captain's session — always allow everything

    try:
        crew_number = int(crew_str)
    except ValueError:
        sys.exit(0)

    # ===================================================================
    # STEP 2.5: Branch discipline (BUG-ADM-2026-0004)
    # ===================================================================
    # For Bash tool calls, refuse git/gh mutations whose target branch
    # disagrees with the order's voyageBranch. Runs before the file-path
    # check because this is a more fundamental discipline violation.
    try:
        from admiralty.hooks.branch_guard import check_branch
        tool_name = hook_input.get("tool_name", "")
        tool_input = hook_input.get("tool_input", {})
        bash_command = tool_input.get("command", "") if tool_name == "Bash" else ""
        if bash_command:
            allow, reason = check_branch(tool_name, bash_command)
            if not allow:
                print(json.dumps({"decision": "deny", "reason": reason}))
                sys.exit(0)
    except Exception:
        # Fail-open on guard failure — branch discipline is belt-and-braces;
        # the dispatcher's _verify_dispatcher_branch is the load-bearing layer.
        pass

    # ===================================================================
    # STEP 3: Get the target file path
    # ===================================================================
    tool_input = hook_input.get("tool_input", {})
    file_path = tool_input.get("file_path") or tool_input.get("filePath") or ""

    if not file_path:
        sys.exit(0)  # No file path — allow

    # ===================================================================
    # STEP 4: Normalize path and check always-allowed
    # ===================================================================
    cwd = hook_input.get("cwd", os.getcwd())
    from admiralty.hooks import find_admiralty_root
    workspace = find_admiralty_root(cwd)
    if workspace is None:
        sys.exit(0)  # Not an Admiralty workspace — no-op
    cwd = str(workspace)
    rel_path = normalize_path(file_path, cwd)

    # ===================================================================
    # STEP 3.5: Secret scan (runs for all paths, including always-allowed)
    # ===================================================================
    try:
        from admiralty.hooks.secret_patterns import Scanner

        def _extract_write_content(tname: str, tinput: dict) -> list[tuple[str, str]]:
            if tname == "Write":
                content = tinput.get("content", "")
                return [("content", content)] if content else []
            if tname == "Edit":
                new_str = tinput.get("new_string", "")
                return [("new_string", new_str)] if new_str else []
            if tname == "MultiEdit":
                results = []
                for i, edit in enumerate(tinput.get("edits", [])):
                    ns = edit.get("new_string", "")
                    if ns:
                        results.append((f"edits[{i}].new_string", ns))
                return results
            if tname == "NotebookEdit":
                # Claude Code NotebookEdit input shape:
                #   {notebook_path, cell_id, new_source, cell_type, edit_mode}
                # The cell payload is `new_source`. Older clients sometimes send
                # `cell_source` — accept either to be safe.
                new_source = tinput.get("new_source") or tinput.get("cell_source") or ""
                return [("new_source", new_source)] if new_source else []
            return []

        tool_name = hook_input.get("tool_name", "")
        write_contents = _extract_write_content(tool_name, tool_input)
        if write_contents:
            scanner = Scanner(workspace_root=workspace)
            for field_label, content in write_contents:
                matches = scanner.scan(content, field_label=field_label, rel_path=rel_path, stop_on_first=True)
                if matches:
                    hit = matches[0]
                    logger.warning(
                        "Secret scan: pattern=%s severity=%s file=%s crew=%s field=%s",
                        hit.pattern_name, hit.severity, rel_path, crew_number, field_label,
                    )
                    decision = {
                        "decision": "deny",
                        "reason": (
                            f"SECRET DETECTED: Pattern '{hit.pattern_name}' matched in "
                            f"{field_label} of {tool_name} → '{rel_path}'. "
                            f"Severity: {hit.severity}. "
                            f"The matched value has NOT been logged. "
                            f"Remove the secret and retry, or add to allowlist if this is a test fixture."
                        ),
                    }
                    print(json.dumps(decision))
                    sys.exit(0)
    except SystemExit:
        raise
    except Exception as exc:
        # Log full traceback so this fail-closed branch is diagnosable.
        # logger.exception() includes the traceback. We deliberately log only
        # the tool name, file path and crew — never any payload that could
        # contain the matched (and unredacted) secret value.
        logger.exception(
            "Secret scanner crashed (fail-closed): tool=%s file=%s crew=%s error=%s",
            hook_input.get("tool_name", "?"), rel_path, crew_number, type(exc).__name__,
        )
        decision = {
            "decision": "deny",
            "reason": (
                f"SECRET SCANNER CRASH: failing closed. "
                f"Error type: {type(exc).__name__}. Check fleet logs."
            ),
        }
        print(json.dumps(decision))
        sys.exit(0)

    if is_always_allowed(rel_path):
        sys.exit(0)  # Always-allowed path — bypass role enforcement

    # ===================================================================
    # STEP 5: Get crew's role from state.json
    # ===================================================================
    _adm_root = Path(cwd) / ".adm" if (Path(cwd) / ".adm").is_dir() else Path(cwd) / ".admiralty"
    crew_dir = _adm_root / "crews" / f"crew{crew_number}"
    state_file = crew_dir / "state.json"

    if not state_file.exists():
        sys.exit(0)  # No state — fail-open

    try:
        state = json.loads(state_file.read_text(encoding='utf-8'))
    except Exception:
        sys.exit(0)  # Can't read state — fail-open

    role = state.get("role", "")
    if not role:
        sys.exit(0)  # No role — fail-open

    # ===================================================================
    # STEP 6: Load role-paths.json and get prohibited patterns
    # ===================================================================
    role_paths_file = _adm_root / "config" / "role-paths.json"

    if not role_paths_file.exists():
        sys.exit(0)  # No config — fail-open

    try:
        config = json.loads(role_paths_file.read_text(encoding='utf-8'))
    except Exception:
        sys.exit(0)  # Can't parse config — fail-open

    role_config = config.get("roles", {}).get(role, {})
    prohibited = role_config.get("prohibited", {})
    prohibited_paths = prohibited.get("paths", [])
    prohibited_reason = prohibited.get("reason", "Permission denied by role")

    if not prohibited_paths:
        sys.exit(0)  # No prohibitions — allow

    # ===================================================================
    # STEP 6b: Load allowed override patterns (allowed wins over prohibited)
    # ===================================================================
    allowed = role_config.get("allowed", {})
    allowed_paths = allowed.get("paths", [])

    # ===================================================================
    # STEP 7: Check file against prohibited patterns (with allowed override)
    # ===================================================================
    if matches_pattern_list(rel_path, prohibited_paths):
        # Check if an allowed pattern overrides the prohibition
        if matches_pattern_list(rel_path, allowed_paths):
            sys.exit(0)  # Allowed override — permit despite prohibition
        role_name = role_config.get("roleName", role)
        filename = Path(file_path).name
        decision = {
            "decision": "deny",
            "reason": (
                f"ROLE ENFORCEMENT: {role} ({role_name}) cannot write to '{filename}'. "
                f"{prohibited_reason}. "
                f"Matched prohibited pattern for path: {rel_path}"
            )
        }
        print(json.dumps(decision))
        sys.exit(0)

    # Allowed
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        sys.exit(0)  # Fail-open: never block on hook errors
