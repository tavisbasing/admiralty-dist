"""
Secret pattern library for fleet write-time detection.

Patterns are evaluated in a fixed order to avoid prefix collisions (e.g.
sk-ant- must be checked before the generic sk- OpenAI pattern).

Scanner.scan() returns a list of Match objects; it NEVER includes the matched
value — only pattern name, severity, and location.
"""

import hashlib
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class SecretPattern:
    name: str
    pattern: re.Pattern
    severity: str
    false_positive_notes: str


@dataclass(frozen=True)
class Match:
    pattern_name: str
    severity: str
    field_label: str
    value_hash: str  # sha256 of matched group — never the value itself


# Patterns evaluated in this order (most specific first to avoid prefix swallowing)
PATTERNS: list[SecretPattern] = [
    SecretPattern(
        name="anthropic_api_key",
        pattern=re.compile(r"(?P<secret>sk-ant-[A-Za-z0-9\-]{40,})"),
        severity="CRITICAL",
        false_positive_notes="Pattern is unambiguous; check before generic sk- pattern",
    ),
    SecretPattern(
        name="openai_api_key",
        pattern=re.compile(r"(?P<secret>sk-[A-Za-z0-9]{48,})"),
        severity="CRITICAL",
        false_positive_notes="Collides with sk-ant- — Anthropic pattern must run first",
    ),
    SecretPattern(
        name="aws_access_key_id",
        pattern=re.compile(r"(?<![A-Z0-9])(?P<secret>AKIA[0-9A-Z]{16})(?![A-Z0-9])"),
        severity="CRITICAL",
        false_positive_notes="AKIAIOSFODNN7EXAMPLE is the AWS docs example — add to allowlist for test fixtures",
    ),
    SecretPattern(
        name="aws_secret_access_key",
        pattern=re.compile(r"(?i)aws.{0,20}(?P<secret>[0-9a-zA-Z/+]{40})"),
        severity="CRITICAL",
        false_positive_notes="Gate on surrounding aws keyword to reduce base64 false positives",
    ),
    SecretPattern(
        name="github_pat_fine_grained",
        pattern=re.compile(r"(?P<secret>github_pat_[A-Za-z0-9_]{40,})"),
        severity="CRITICAL",
        false_positive_notes="Fine-grained tokens introduced 2022; prefix is authoritative",
    ),
    SecretPattern(
        name="github_pat_classic",
        pattern=re.compile(r"(?P<secret>gh[pso]_[A-Za-z0-9]{36,})"),
        severity="CRITICAL",
        false_positive_notes="ghp_/gho_/ghs_ prefix uniquely identifies GitHub PATs — very low FP rate",
    ),
    SecretPattern(
        name="slack_token",
        pattern=re.compile(r"(?P<secret>xox[bpas]-[0-9A-Za-z\-]{10,})"),
        severity="HIGH",
        false_positive_notes="FPs possible in test mocks — use allowlist",
    ),
    SecretPattern(
        name="private_key_header",
        pattern=re.compile(r"(?P<secret>-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)"),
        severity="CRITICAL",
        false_positive_notes="PEM headers are authoritative; no FP concern for the header itself",
    ),
    SecretPattern(
        name="jwt_token",
        pattern=re.compile(r"(?P<secret>eyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_.+/=]*)"),
        severity="HIGH",
        false_positive_notes="Test JWTs are common — allowlist by known test values",
    ),
    SecretPattern(
        name="bearer_token",
        pattern=re.compile(r"(?i)bearer\s+(?P<secret>[A-Za-z0-9\-._~+/]{20,})"),
        severity="HIGH",
        false_positive_notes="Generic — high FP risk in test fixtures and example docs; allowlist by file path",
    ),
]

_HIGH_ENTROPY_CANDIDATE = re.compile(r"[A-Za-z0-9+/=_\-]{40,}")
_ENTROPY_KEYWORDS = re.compile(
    r"(?i)\b(?:secret|token|key|password|api_key|apikey|credential|auth|bearer)\b"
)


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


def _check_high_entropy(text: str, field_label: str) -> list[Match]:
    matches: list[Match] = []
    for m in _HIGH_ENTROPY_CANDIDATE.finditer(text):
        value = m.group(0)
        if _shannon_entropy(value) < 4.5:
            continue
        # Check 50-char window around match for a keyword
        start = max(0, m.start() - 50)
        end = min(len(text), m.end() + 50)
        window = text[start:end]
        if not _ENTROPY_KEYWORDS.search(window):
            continue
        matches.append(Match(
            pattern_name="high_entropy_string",
            severity="MEDIUM",
            field_label=field_label,
            value_hash=hashlib.sha256(value.encode()).hexdigest(),
        ))
        break  # one match per field is sufficient
    return matches


def _load_allowlist(workspace_root: Path) -> list[dict]:
    # Prefer .adm/config (v2.x); fall back to .admiralty/config (v1.x legacy)
    # so allowlist entries in legacy workspaces are honoured.
    candidates = [
        workspace_root / ".adm" / "config" / "secret-allowlist.json",
        workspace_root / ".admiralty" / "config" / "secret-allowlist.json",
    ]
    for allowlist_path in candidates:
        if allowlist_path.exists():
            data = json.loads(allowlist_path.read_text(encoding="utf-8"))
            return data.get("entries", [])
    return []


def _is_allowlisted(
    pattern_name: str,
    value_hash: str,
    rel_path: str,
    entries: list[dict],
) -> bool:
    import fnmatch
    for entry in entries:
        if entry.get("pattern_name") != pattern_name:
            continue
        if entry.get("value_hash") != f"sha256:{value_hash}":
            continue
        glob = entry.get("file_glob", "")
        if glob and fnmatch.fnmatch(rel_path, glob):
            return True
    return False


class Scanner:
    """Scans text for secrets. Never logs or returns matched values."""

    def __init__(self, workspace_root: Optional[Path] = None):
        self._workspace_root = workspace_root
        self._allowlist: Optional[list[dict]] = None

    def _get_allowlist(self) -> list[dict]:
        if self._allowlist is None:
            if self._workspace_root is None:
                self._allowlist = []
            else:
                self._allowlist = _load_allowlist(self._workspace_root)
        return self._allowlist

    def scan(
        self,
        text: str,
        field_label: str = "content",
        rel_path: str = "",
        stop_on_first: bool = False,
    ) -> list[Match]:
        """
        Scan text for secrets. Returns Match objects (no matched values).
        Raises on unexpected error — caller is responsible for fail-closed handling.

        When `stop_on_first=True`, returns immediately after the first
        non-allowlisted match. The pretool hook only needs to know whether to
        deny the write, so it short-circuits this way to avoid scanning every
        pattern across large Write/MultiEdit/NotebookEdit payloads.
        """
        results: list[Match] = []
        allowlist = self._get_allowlist()

        for sp in PATTERNS:
            for m in sp.pattern.finditer(text):
                value = m.group("secret")
                value_hash = hashlib.sha256(value.encode()).hexdigest()
                if _is_allowlisted(sp.name, value_hash, rel_path, allowlist):
                    continue
                results.append(Match(
                    pattern_name=sp.name,
                    severity=sp.severity,
                    field_label=field_label,
                    value_hash=value_hash,
                ))
                if stop_on_first:
                    return results

        # High entropy check (runs last per plan ordering)
        for he_match in _check_high_entropy(text, field_label):
            if not _is_allowlisted(he_match.pattern_name, he_match.value_hash, rel_path, allowlist):
                results.append(he_match)
                if stop_on_first:
                    return results

        return results
