"""
admiralty/templates_loader.py — Requirement template discovery and rendering.

Built-in templates live in admiralty/templates/requirements/*.md.j2.
Custom templates live in <adm_dir>/templates/requirements/*.md.j2.
Custom templates override built-ins with the same name.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, StrictUndefined, TemplateNotFound

_BUILTIN_TEMPLATES_DIR = Path(__file__).parent / "templates" / "requirements"

_BUILTIN_NAMES = [
    "new-feature",
    "project-setup",
    "security-review",
    "test-coverage",
    "doc-audit",
    "bug-report",
    "performance",
    "refactor",
]


def list_builtin_templates() -> list[str]:
    """Return the names of the 8 built-in requirement templates (without extension)."""
    return list(_BUILTIN_NAMES)


def list_custom_templates(adm_dir: Path) -> list[str]:
    """Return template names found in <adm_dir>/templates/requirements/*.md.j2."""
    custom_dir = adm_dir / "templates" / "requirements"
    if not custom_dir.is_dir():
        return []
    return [p.stem.removesuffix(".md") for p in sorted(custom_dir.glob("*.md.j2"))]


def load_template(name: str, adm_dir: Path) -> str:
    """Return the raw template source for *name*.

    Resolution order: custom (adm_dir) → built-in.
    Raises FileNotFoundError if neither exists.
    """
    custom_path = adm_dir / "templates" / "requirements" / f"{name}.md.j2"
    if custom_path.is_file():
        return custom_path.read_text(encoding="utf-8")

    builtin_path = _BUILTIN_TEMPLATES_DIR / f"{name}.md.j2"
    if builtin_path.is_file():
        return builtin_path.read_text(encoding="utf-8")

    available = list_builtin_templates() + list_custom_templates(adm_dir)
    raise FileNotFoundError(
        f"Requirement template '{name}' not found. "
        f"Available templates: {', '.join(available) if available else '(none)'}"
    )


def render_template(name: str, context: dict[str, Any], adm_dir: Path) -> str:
    """Render the named template with *context* and return the result as a string."""
    custom_dir = adm_dir / "templates" / "requirements"

    loaders: list[Any] = []
    if custom_dir.is_dir():
        loaders.append(FileSystemLoader(str(custom_dir)))
    loaders.append(FileSystemLoader(str(_BUILTIN_TEMPLATES_DIR)))

    from jinja2 import ChoiceLoader

    env = Environment(
        loader=ChoiceLoader(loaders),
        undefined=StrictUndefined,
        keep_trailing_newline=True,
    )

    try:
        template = env.get_template(f"{name}.md.j2")
    except TemplateNotFound:
        available = list_builtin_templates() + list_custom_templates(adm_dir)
        raise FileNotFoundError(
            f"Requirement template '{name}' not found. "
            f"Available templates: {', '.join(available) if available else '(none)'}"
        )

    return template.render(**context)
