from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


GENESIS_HASH = "0000000000000000000000000000000000000000000000000000000000000000"


@dataclass
class AuditEntry:
    seq: int
    timestamp: str
    actor: str
    action: str
    target: str
    result: str
    metadata: dict[str, Any]
    prev_hash: str
    hash: str = ""
    signature: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "seq": self.seq,
            "timestamp": self.timestamp,
            "actor": self.actor,
            "action": self.action,
            "target": self.target,
            "result": self.result,
            "metadata": self.metadata,
            "prevHash": self.prev_hash,
            "hash": self.hash,
            "signature": self.signature,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "AuditEntry":
        return AuditEntry(
            seq=d["seq"],
            timestamp=d["timestamp"],
            actor=d["actor"],
            action=d["action"],
            target=d["target"],
            result=d["result"],
            metadata=d.get("metadata", {}),
            prev_hash=d.get("prevHash", GENESIS_HASH),
            hash=d.get("hash", ""),
            signature=d.get("signature", ""),
        )
