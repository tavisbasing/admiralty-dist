from __future__ import annotations

import base64
import hashlib
import hmac
import json
from pathlib import Path
from typing import Any


def _canonical(d: dict[str, Any]) -> bytes:
    """Deterministic JSON serialisation (sorted keys, no trailing whitespace)."""
    return json.dumps(d, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def compute_hash(entry_body: dict[str, Any]) -> str:
    """SHA-256 over the canonical entry body (excluding hash and signature fields)."""
    body = {k: v for k, v in entry_body.items() if k not in ("hash", "signature")}
    return hashlib.sha256(_canonical(body)).hexdigest()


def _load_workspace_key(workspace: Path) -> bytes | None:
    key_path = workspace / ".adm" / "identity" / "workspace-signing.key"
    if not key_path.exists():
        return None
    try:
        raw = key_path.read_text(encoding="utf-8").strip()
        return base64.b64decode(raw)
    except Exception:
        return None


def sign_entry(entry_body: dict[str, Any], workspace: Path) -> str:
    """
    Sign the canonical entry body.  Returns a 'hmac:<hex>' string.
    Falls back to empty string when no signing key is available.
    """
    key = _load_workspace_key(workspace)
    if key is None:
        return ""
    body = {k: v for k, v in entry_body.items() if k not in ("hash", "signature")}
    mac = hmac.new(key, _canonical(body), hashlib.sha256).hexdigest()
    return f"hmac:{mac}"


def verify_signature(entry_body: dict[str, Any], signature: str, workspace: Path) -> bool:
    """Return True when signature is valid or when signing was not configured."""
    if not signature:
        return True
    key = _load_workspace_key(workspace)
    if key is None:
        return True
    body = {k: v for k, v in entry_body.items() if k not in ("hash", "signature")}
    expected = hmac.new(key, _canonical(body), hashlib.sha256).hexdigest()
    if not signature.startswith("hmac:"):
        return False
    return hmac.compare_digest(expected, signature[5:])
