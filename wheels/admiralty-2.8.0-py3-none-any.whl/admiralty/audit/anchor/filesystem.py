from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .base import Anchor, AnchorReceipt


class FilesystemAnchor(Anchor):
    """Dev/test anchor — writes receipts to a local directory."""

    PROVIDER = "filesystem"

    def __init__(self, anchor_dir: Path) -> None:
        self._dir = anchor_dir

    def anchor(self, root_hash: str, metadata: dict[str, Any] | None = None) -> AnchorReceipt:
        self._dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        safe_ts = ts.replace(":", "-").replace(".", "-")
        fname = f"anchor-{safe_ts}-{root_hash[:16]}.json"
        path = self._dir / fname

        receipt = AnchorReceipt(
            provider=self.PROVIDER,
            root_hash=root_hash,
            timestamp=ts,
            location=str(path.resolve()),
            metadata=metadata or {},
        )
        path.write_text(json.dumps(receipt.to_dict(), indent=2), encoding="utf-8")
        return receipt

    @classmethod
    def from_env(cls) -> "FilesystemAnchor":
        import warnings
        anchor_dir = os.environ.get("ADM_ANCHOR_FS_DIR")
        if anchor_dir:
            warnings.warn(
                "ADM_ANCHOR_FS_DIR via environment variable is deprecated; "
                "use a secrets reference in anchor config instead.",
                DeprecationWarning,
                stacklevel=3,
            )
            return cls(Path(anchor_dir))
        return cls(Path(".adm") / "audit" / "anchors")
