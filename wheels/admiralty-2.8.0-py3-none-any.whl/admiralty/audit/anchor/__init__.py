from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .base import Anchor, AnchorReceipt
from .filesystem import FilesystemAnchor
from .s3 import S3Anchor
from .azure_blob import AzureBlobAnchor
from .s3_compatible import S3CompatibleAnchor

__all__ = [
    "Anchor",
    "AnchorReceipt",
    "FilesystemAnchor",
    "S3Anchor",
    "AzureBlobAnchor",
    "S3CompatibleAnchor",
    "load_provider",
]

_PROVIDERS = {
    "fs": FilesystemAnchor,
    "filesystem": FilesystemAnchor,
    "s3": S3Anchor,
    "azure": AzureBlobAnchor,
    "azure_blob": AzureBlobAnchor,
    "s3-compat": S3CompatibleAnchor,
    "s3_compatible": S3CompatibleAnchor,
}


def load_provider(provider: str, config_file: Path | None = None) -> Anchor:
    """
    Resolve and instantiate an Anchor provider.

    If config_file is given it must be a JSON file whose top-level keys are
    passed as constructor kwargs.  Otherwise the provider is constructed via
    from_env() (which emits a DeprecationWarning for env-var-based config).
    """
    cls = _PROVIDERS.get(provider)
    if cls is None:
        raise ValueError(
            f"Unknown anchor provider {provider!r}. "
            f"Valid options: {', '.join(sorted(set(_PROVIDERS)))}"
        )

    if config_file is not None:
        try:
            cfg: dict[str, Any] = json.loads(config_file.read_text(encoding="utf-8"))
        except Exception as exc:
            raise ValueError(f"Cannot read anchor config file {config_file}: {exc}") from exc
        return cls(**cfg)

    return cls.from_env()
