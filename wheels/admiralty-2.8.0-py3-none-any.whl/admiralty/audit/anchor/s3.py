from __future__ import annotations

import json
import os
import warnings
from datetime import datetime, timezone
from typing import Any

from .base import Anchor, AnchorReceipt

_REQUIRED_ENV = ("ADM_ANCHOR_S3_BUCKET", "ADM_ANCHOR_S3_KEY_PREFIX")


class S3Anchor(Anchor):
    """
    Anchors root hashes to S3 with Object Lock (COMPLIANCE or GOVERNANCE mode).

    Requires boto3. Object Lock must be enabled on the bucket before use.
    """

    PROVIDER = "s3"

    def __init__(
        self,
        bucket: str,
        key_prefix: str = "audit-anchors/",
        region: str | None = None,
        retain_years: int = 7,
        mode: str = "COMPLIANCE",
    ) -> None:
        self._bucket = bucket
        self._prefix = key_prefix.rstrip("/") + "/"
        self._region = region
        self._retain_years = retain_years
        self._mode = mode

    def anchor(self, root_hash: str, metadata: dict[str, Any] | None = None) -> AnchorReceipt:
        try:
            import boto3
            from botocore.exceptions import BotoCoreError, ClientError
        except ImportError as exc:
            raise RuntimeError("boto3 is required for the S3 anchor provider") from exc

        ts = datetime.now(timezone.utc)
        ts_str = ts.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        safe_ts = ts_str.replace(":", "-").replace(".", "-")
        key = f"{self._prefix}anchor-{safe_ts}-{root_hash[:16]}.json"

        payload = {
            "provider": self.PROVIDER,
            "rootHash": root_hash,
            "timestamp": ts_str,
            "location": f"s3://{self._bucket}/{key}",
            "metadata": metadata or {},
        }

        retain_until = ts.replace(year=ts.year + self._retain_years)

        kwargs: dict[str, Any] = {
            "Bucket": self._bucket,
            "Key": key,
            "Body": json.dumps(payload, indent=2).encode(),
            "ContentType": "application/json",
            "ObjectLockMode": self._mode,
            "ObjectLockRetainUntilDate": retain_until,
        }

        client_kwargs: dict[str, Any] = {}
        if self._region:
            client_kwargs["region_name"] = self._region

        s3 = boto3.client("s3", **client_kwargs)
        try:
            s3.put_object(**kwargs)
        except (BotoCoreError, ClientError) as exc:
            raise RuntimeError(f"S3 anchor failed: {exc}") from exc

        return AnchorReceipt(
            provider=self.PROVIDER,
            root_hash=root_hash,
            timestamp=ts_str,
            location=f"s3://{self._bucket}/{key}",
            metadata=metadata or {},
        )

    @classmethod
    def from_env(cls) -> "S3Anchor":
        warnings.warn(
            "S3 anchor configured via environment variables is deprecated; "
            "use a secrets reference in anchor config instead.",
            DeprecationWarning,
            stacklevel=3,
        )
        bucket = os.environ.get("ADM_ANCHOR_S3_BUCKET", "")
        if not bucket:
            raise ValueError("ADM_ANCHOR_S3_BUCKET environment variable is required")
        return cls(
            bucket=bucket,
            key_prefix=os.environ.get("ADM_ANCHOR_S3_KEY_PREFIX", "audit-anchors/"),
            region=os.environ.get("ADM_ANCHOR_S3_REGION"),
            retain_years=int(os.environ.get("ADM_ANCHOR_S3_RETAIN_YEARS", "7")),
            mode=os.environ.get("ADM_ANCHOR_S3_MODE", "COMPLIANCE"),
        )
