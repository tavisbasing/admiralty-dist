from __future__ import annotations

import json
import os
import warnings
from datetime import datetime, timezone
from typing import Any

from .base import Anchor, AnchorReceipt


class S3CompatibleAnchor(Anchor):
    """
    Anchors root hashes to an S3-compatible endpoint (MinIO, Wasabi, Cloudflare R2, etc.).

    Unlike S3Anchor, Object Lock is optional and the endpoint URL is customer-provided.
    Requires boto3.
    """

    PROVIDER = "s3_compatible"

    def __init__(
        self,
        endpoint_url: str,
        bucket: str,
        access_key: str,
        secret_key: str,
        key_prefix: str = "audit-anchors/",
        use_object_lock: bool = False,
        retain_years: int = 7,
        mode: str = "COMPLIANCE",
    ) -> None:
        self._endpoint = endpoint_url
        self._bucket = bucket
        self._access_key = access_key
        self._secret_key = secret_key
        self._prefix = key_prefix.rstrip("/") + "/"
        self._use_object_lock = use_object_lock
        self._retain_years = retain_years
        self._mode = mode

    def anchor(self, root_hash: str, metadata: dict[str, Any] | None = None) -> AnchorReceipt:
        try:
            import boto3
            from botocore.exceptions import BotoCoreError, ClientError
        except ImportError as exc:
            raise RuntimeError("boto3 is required for the S3-compatible anchor provider") from exc

        ts = datetime.now(timezone.utc)
        ts_str = ts.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        safe_ts = ts_str.replace(":", "-").replace(".", "-")
        key = f"{self._prefix}anchor-{safe_ts}-{root_hash[:16]}.json"
        location = f"{self._endpoint.rstrip('/')}/{self._bucket}/{key}"

        payload = {
            "provider": self.PROVIDER,
            "rootHash": root_hash,
            "timestamp": ts_str,
            "location": location,
            "metadata": metadata or {},
        }

        kwargs: dict[str, Any] = {
            "Bucket": self._bucket,
            "Key": key,
            "Body": json.dumps(payload, indent=2).encode(),
            "ContentType": "application/json",
        }

        if self._use_object_lock:
            from datetime import timedelta
            retain_until = ts + timedelta(days=self._retain_years * 365)
            kwargs["ObjectLockMode"] = self._mode
            kwargs["ObjectLockRetainUntilDate"] = retain_until

        s3 = boto3.client(
            "s3",
            endpoint_url=self._endpoint,
            aws_access_key_id=self._access_key,
            aws_secret_access_key=self._secret_key,
        )
        try:
            s3.put_object(**kwargs)
        except (BotoCoreError, ClientError) as exc:
            raise RuntimeError(f"S3-compatible anchor failed: {exc}") from exc

        return AnchorReceipt(
            provider=self.PROVIDER,
            root_hash=root_hash,
            timestamp=ts_str,
            location=location,
            metadata=metadata or {},
        )

    @classmethod
    def from_env(cls) -> "S3CompatibleAnchor":
        warnings.warn(
            "S3-compatible anchor configured via environment variables is deprecated; "
            "use a secrets reference in anchor config instead.",
            DeprecationWarning,
            stacklevel=3,
        )
        endpoint = os.environ.get("ADM_ANCHOR_S3C_ENDPOINT", "")
        if not endpoint:
            raise ValueError("ADM_ANCHOR_S3C_ENDPOINT environment variable is required")
        return cls(
            endpoint_url=endpoint,
            bucket=os.environ.get("ADM_ANCHOR_S3C_BUCKET", "admiralty-audit"),
            access_key=os.environ.get("ADM_ANCHOR_S3C_ACCESS_KEY", ""),
            secret_key=os.environ.get("ADM_ANCHOR_S3C_SECRET_KEY", ""),
            key_prefix=os.environ.get("ADM_ANCHOR_S3C_KEY_PREFIX", "audit-anchors/"),
            use_object_lock=os.environ.get("ADM_ANCHOR_S3C_OBJECT_LOCK", "").lower() in ("1", "true", "yes"),
            retain_years=int(os.environ.get("ADM_ANCHOR_S3C_RETAIN_YEARS", "7")),
            mode=os.environ.get("ADM_ANCHOR_S3C_MODE", "COMPLIANCE"),
        )
