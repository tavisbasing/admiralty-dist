"""
admiralty/setup.py — Prerequisite validation and interactive setup wizard.

Provides:
  - PrereqCheck dataclass
  - 6 validator functions
  - run_all_checks() -> list[PrereqCheck]
  - format_check_report(results, verbose=False) -> str
  - interactive_setup()
  - check_mode_exit_code(results) -> int
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Literal


StatusT = Literal["OK", "WARN", "FAIL"]


@dataclass
class PrereqCheck:
    name: str
    status: StatusT
    message: str
    remediation: str = ""
    repair_fn: Callable[[], None] | None = field(default=None, repr=False)


# ---------------------------------------------------------------------------
# Validators
# ---------------------------------------------------------------------------

def check_python_version() -> PrereqCheck:
    if sys.version_info >= (3, 9):
        return PrereqCheck(
            name="python_version",
            status="OK",
            message=f"Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        )
    vi = sys.version_info
    major, minor = (vi[0], vi[1]) if isinstance(vi, tuple) else (vi.major, vi.minor)
    return PrereqCheck(
        name="python_version",
        status="FAIL",
        message=f"Python {major}.{minor} — 3.9+ required",
        remediation="Upgrade Python: https://www.python.org/downloads/",
    )


def check_claude_cli() -> PrereqCheck:
    if sys.platform == "win32" and shutil.which("claude") is None:
        return PrereqCheck(
            name="claude_cli",
            status="FAIL",
            message="Claude Code CLI not found (Windows requires WSL2)",
            remediation=(
                "Install WSL2 then install Claude Code inside it:\n"
                "  wsl --install\n"
                "  npm install -g @anthropic-ai/claude-code"
            ),
        )
    if shutil.which("claude") is None:
        return PrereqCheck(
            name="claude_cli",
            status="FAIL",
            message="Claude Code CLI not found on PATH",
            remediation="npm install -g @anthropic-ai/claude-code  (requires Node 18+)",
        )
    try:
        result = subprocess.run(
            ["claude", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = (result.stdout.strip() or result.stderr.strip()).splitlines()[0]
            return PrereqCheck(
                name="claude_cli",
                status="OK",
                message=f"Claude Code {version}",
            )
    except Exception:
        pass
    return PrereqCheck(
        name="claude_cli",
        status="FAIL",
        message="Claude Code CLI found but did not respond to --version",
        remediation="Try: npm install -g @anthropic-ai/claude-code",
    )


def check_git() -> PrereqCheck:
    if shutil.which("git") is None:
        return PrereqCheck(
            name="git",
            status="FAIL",
            message="git not found on PATH",
            remediation="Install Git: https://git-scm.com/downloads",
        )
    try:
        result = subprocess.run(
            ["git", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            return PrereqCheck(name="git", status="OK", message=version)
    except Exception:
        pass
    return PrereqCheck(
        name="git",
        status="FAIL",
        message="git found but did not respond",
        remediation="Reinstall Git: https://git-scm.com/downloads",
    )


def check_gh_cli() -> PrereqCheck:
    if shutil.which("gh") is None:
        return PrereqCheck(
            name="gh_cli",
            status="WARN",
            message="GitHub CLI (gh) not found — required for PR workflows",
            remediation="Install gh: https://cli.github.com/",
        )
    try:
        result = subprocess.run(
            ["gh", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = result.stdout.strip().splitlines()[0]
            # Check auth status
            auth = subprocess.run(
                ["gh", "auth", "status"],
                capture_output=True, text=True, timeout=10,
            )
            if auth.returncode != 0:
                return PrereqCheck(
                    name="gh_cli",
                    status="WARN",
                    message=f"{version} — not authenticated",
                    remediation="Run: gh auth login",
                )
            return PrereqCheck(name="gh_cli", status="OK", message=version)
    except Exception:
        pass
    return PrereqCheck(
        name="gh_cli",
        status="WARN",
        message="gh found but did not respond",
        remediation="Reinstall gh: https://cli.github.com/",
    )


def check_anthropic_auth() -> PrereqCheck:
    if os.environ.get("ANTHROPIC_API_KEY"):
        return PrereqCheck(
            name="anthropic_auth",
            status="OK",
            message="ANTHROPIC_API_KEY set",
        )
    # Claude Code subscription auth is also valid — we can't probe it
    # directly, but if claude CLI is available we assume it may be logged in.
    if shutil.which("claude") is not None:
        return PrereqCheck(
            name="anthropic_auth",
            status="OK",
            message="Claude Code subscription auth (no ANTHROPIC_API_KEY — crews use subscription billing)",
        )
    return PrereqCheck(
        name="anthropic_auth",
        status="WARN",
        message="No ANTHROPIC_API_KEY and Claude Code CLI not found",
        remediation=(
            "Set API key: export ANTHROPIC_API_KEY=sk-ant-...\n"
            "  or install Claude Code: npm install -g @anthropic-ai/claude-code"
        ),
    )


def check_workspace_scaffold() -> PrereqCheck:
    cwd = Path.cwd()
    for path in [cwd, *cwd.parents]:
        if (path / ".adm" / "config").is_dir():
            ws_json = path / ".adm" / "config" / "workspace.json"
            if not ws_json.exists():
                return PrereqCheck(
                    name="workspace_scaffold",
                    status="WARN",
                    message=f".adm/ found at {path} but workspace.json is missing",
                    remediation="Run: adm init --project <PRJ>",
                )
            return PrereqCheck(
                name="workspace_scaffold",
                status="OK",
                message=f"Workspace at {path}",
            )

    def _repair():
        # BUG fixed via Copilot review on PR #67: the previous repair_fn called
        # `python -m admiralty.cli init --minimal`, but `adm init` has no
        # `--minimal` flag — it requires `--project`. Instead, ask the operator
        # for a project acronym and call scaffold_workspace() directly, which
        # is the same code path `adm init` would have taken.
        from admiralty.init import scaffold_workspace
        try:
            project = input("    Project acronym (e.g. PSG): ").strip().upper()
        except EOFError:
            project = ""
        if not project:
            print("    No project acronym supplied — skipping scaffold.")
            return
        scaffold_workspace(project, Path.cwd())

    return PrereqCheck(
        name="workspace_scaffold",
        status="FAIL",
        message="No .adm/ workspace found in current directory or any parent",
        remediation="Run: adm init --project <PRJ>",
        repair_fn=_repair,
    )


# ---------------------------------------------------------------------------
# Aggregator
# ---------------------------------------------------------------------------

def run_all_checks() -> list[PrereqCheck]:
    return [
        check_python_version(),
        check_claude_cli(),
        check_git(),
        check_gh_cli(),
        check_anthropic_auth(),
        check_workspace_scaffold(),
    ]


# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------

_STATUS_SYMBOLS = {"OK": "✓", "WARN": "⚠", "FAIL": "✗"}
_STATUS_LABELS = {"OK": "OK  ", "WARN": "WARN", "FAIL": "FAIL"}

# ANSI colour codes (disabled on Windows without ENABLE_VIRTUAL_TERMINAL_PROCESSING
# or when not a TTY — callers that need plain output pass colour=False).
_COLOURS = {
    "OK": "\033[32m",    # green
    "WARN": "\033[33m",  # yellow
    "FAIL": "\033[31m",  # red
    "RESET": "\033[0m",
}

def _colour_supported() -> bool:
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def format_check_report(results: list[PrereqCheck], verbose: bool = False) -> str:
    use_colour = _colour_supported()
    lines: list[str] = []
    for r in results:
        sym = _STATUS_SYMBOLS[r.status]
        label = _STATUS_LABELS[r.status]
        if use_colour:
            c = _COLOURS[r.status]
            reset = _COLOURS["RESET"]
            prefix = f"{c}{sym} [{label}]{reset}"
        else:
            prefix = f"{sym} [{label}]"
        lines.append(f"  {prefix}  {r.name}: {r.message}")
        if verbose and r.remediation and r.status != "OK":
            for rem_line in r.remediation.splitlines():
                lines.append(f"             {rem_line}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Exit-code helper
# ---------------------------------------------------------------------------

def check_mode_exit_code(results: list[PrereqCheck]) -> int:
    """0=all OK, 1=any FAIL, 2=any WARN (no FAIL), 3=internal error."""
    try:
        statuses = {r.status for r in results}
        if "FAIL" in statuses:
            return 1
        if "WARN" in statuses:
            return 2
        return 0
    except Exception:
        return 3


# ---------------------------------------------------------------------------
# Interactive wizard
# ---------------------------------------------------------------------------

def _find_adm_dir() -> Path | None:
    """Walk up from cwd looking for an .adm/ directory."""
    for path in [Path.cwd(), *Path.cwd().parents]:
        if (path / ".adm").is_dir():
            return path / ".adm"
    return None


def _configure_workspace() -> None:
    """Step 3: confirm/update workspace.json."""
    import json

    adm_dir = _find_adm_dir()
    if adm_dir is None:
        print("  ⚠ No .adm/ directory found — skipping workspace configuration.")
        print("    Run `adm init --project <PRJ>` first.")
        return

    ws_path = adm_dir / "config" / "workspace.json"
    if ws_path.exists():
        try:
            ws = json.loads(ws_path.read_text(encoding="utf-8"))
            project = ws.get("project", "UNKNOWN")
            print(f"  Current project : {project}")
            print(f"  workspace.json  : {ws_path}")
            if not _ask("  Configuration looks correct. Keep it as-is?", default="y"):
                print("  Edit workspace.json directly or re-run `adm init` to regenerate.")
        except Exception as exc:
            print(f"  ⚠ Could not read workspace.json: {exc}")
    else:
        print("  ⚠ workspace.json not found.")
        print("    Run `adm init --project <PRJ>` to create it.")


def _offer_template_generation() -> None:
    """Step 4: offer to generate a starter order from a requirement template."""
    import datetime

    from admiralty.templates_loader import (
        list_builtin_templates,
        list_custom_templates,
        render_template,
    )

    adm_dir = _find_adm_dir()
    if adm_dir is None:
        print("  ⚠ No .adm/ directory found — skipping template generation.")
        return

    builtin = list_builtin_templates()
    custom = list_custom_templates(adm_dir)
    all_templates = builtin + [t for t in custom if t not in builtin]

    print("  Available built-in templates:")
    for name in builtin:
        print(f"    • {name}")
    if custom:
        print("  Custom templates:")
        for name in custom:
            marker = " (overrides built-in)" if name in builtin else ""
            print(f"    • {name}{marker}")

    if not _ask("\n  Generate a starter order from a template?", default="n"):
        return

    print("\n  Enter template name (or press Enter to skip): ", end="", flush=True)
    try:
        chosen = input().strip()
    except EOFError:
        chosen = ""

    if not chosen:
        return

    if chosen not in all_templates:
        print(f"  ✗ Unknown template '{chosen}'. Skipping.")
        return

    # Collect minimal fields
    print(f"\n  Filling in '{chosen}' template fields (press Enter to use placeholder):\n")
    def _field(label: str, placeholder: str = "TBD") -> str:
        try:
            val = input(f"    {label} [{placeholder}]: ").strip()
        except EOFError:
            val = ""
        return val or placeholder

    title = _field("Title", "New order title")
    scope = _field("Scope / affected component", "TBD")
    background = _field("Background", "TBD")
    notes = _field("Additional notes", "")

    # Derive type from template name
    _type_map = {
        "new-feature": "FTR",
        "project-setup": "FTR",
        "security-review": "SEC",
        "test-coverage": "FTR",
        "doc-audit": "DOC",
        "bug-report": "BUG",
        "performance": "FTR",
        "refactor": "FTR",
    }
    order_type = _type_map.get(chosen, "FTR")

    # Determine project and next sequence
    import json as _json
    project = "PRJ"
    ws_path = adm_dir / "config" / "workspace.json"
    if ws_path.exists():
        try:
            ws = _json.loads(ws_path.read_text(encoding="utf-8"))
            project = ws.get("project", "PRJ")
        except Exception:
            pass

    year = datetime.datetime.now().year
    proposed_dir = adm_dir / "queues" / "proposed"
    proposed_dir.mkdir(parents=True, exist_ok=True)
    existing = sorted(proposed_dir.glob(f"*-{project}-{year}-*.md"))
    seq = len(existing) + 1
    order_id = f"{order_type}-{project}-{year}-{seq:04d}"

    context = {
        "order_id": order_id,
        "title": title,
        "scope": scope,
        "background": background,
        "notes": notes,
    }

    try:
        rendered = render_template(chosen, context, adm_dir)
    except Exception as exc:
        print(f"  ✗ Render failed: {exc}")
        return

    out_path = proposed_dir / f"{order_id}.md"
    out_path.write_text(rendered, encoding="utf-8")
    print(f"\n  ✓ Starter order written to: {out_path}")
    print("    Review and edit it, then use `adm order` to promote it to the queue.")


def _ask(prompt: str, default: str = "y") -> bool:
    """Prompt yes/no; returns True for yes."""
    indicator = "[Y/n]" if default.lower() == "y" else "[y/N]"
    try:
        answer = input(f"{prompt} {indicator}: ").strip().lower()
    except EOFError:
        return default.lower() == "y"
    if not answer:
        return default.lower() == "y"
    return answer in ("y", "yes")


def interactive_setup() -> None:
    from admiralty import __version__

    print(f"\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f" Admiralty Setup Wizard — v{__version__}")
    print(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

    # Step 1 — Prerequisite checks
    print("[STEP 1] Prerequisite checks\n")
    results = run_all_checks()
    print(format_check_report(results, verbose=True))
    print()

    for check in results:
        if check.status in ("WARN", "FAIL") and check.remediation:
            print(f"  → {check.name}: {check.remediation}")
            if check.repair_fn and check.status == "FAIL":
                if _ask(f"  Attempt automatic repair for '{check.name}'?"):
                    try:
                        check.repair_fn()
                        print(f"  ✓ Repair attempted. Re-run `adm setup` to verify.")
                    except Exception as exc:
                        print(f"  ✗ Repair failed: {exc}")

    # Step 2 — Project analysis
    print("\n[STEP 2] Project analysis\n")
    try:
        from pathlib import Path as _Path
        from admiralty.project_analysis import analyse_project

        analysis = analyse_project(_Path.cwd())
        print(f"  Language   : {analysis.primary_language}")
        if analysis.secondary_languages:
            print(f"  Also uses  : {', '.join(analysis.secondary_languages)}")
        print(f"  Framework  : {analysis.framework}")
        print(f"  Source root: {analysis.source_root}")
        print(f"  Test layout: {', '.join(analysis.test_layouts) or 'none detected'}")
        print(f"  Docs       : {'README ✓' if analysis.has_readme else 'no README'}"
              f"{', docs/ ✓' if analysis.has_docs_dir else ''}")
        print(f"  CI         : {', '.join(analysis.ci_systems) if analysis.ci_systems else 'none detected'}")
        print(f"  Git        : activity={analysis.recent_activity}, branches={analysis.branch_model}")
    except Exception as exc:
        print(f"  ⚠ Project analysis failed: {exc}")

    # Step 3 — Workspace configuration
    print("\n[STEP 3] Workspace configuration\n")
    _configure_workspace()

    # Step 4 — Requirement templates
    print("\n[STEP 4] Requirement templates\n")
    _offer_template_generation()

    # Step 5 — Contextual next-steps cheatsheet
    # BUG fixed via Copilot review on PR #67: previous wizard never surfaced
    # the cheatsheet rules from FTR-ADM-2026-0110, so operators saw zero
    # contextual guidance after setup. Now we always print it before signing off.
    print("\n[STEP 5] Suggested next steps\n")
    try:
        from admiralty.setup_cheatsheet import generate_cheatsheet
        analysis_for_sheet = locals().get("analysis", None)
        print(generate_cheatsheet(analysis_for_sheet, results))
    except Exception as exc:
        print(f"  ⚠ Cheatsheet generation failed: {exc}")

    print("\nSetup complete. Run `adm status` to see your fleet.")
