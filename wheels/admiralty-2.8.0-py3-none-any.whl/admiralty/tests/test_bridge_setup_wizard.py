"""
Tests for adm bridge setup wizard (FTR-ADM-2026-0033).

Covers:
1. Fresh run — wizard writes valid JSON with ${VAR} references
2. Re-run with existing config — decline reconfigure, wizard exits cleanly
3. Re-run with existing config — accept reconfigure, file is overwritten
4. KeyboardInterrupt mid-wizard — exits gracefully, no partial file written
5. Invalid poll interval input ('abc') — falls back to 30
6. No projects entered — config written with empty projects dict
7. bridge_status() reads new config without error
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest import mock

from admiralty.bridge import setup_wizard, bridge_status


def _make_workspace(tmp_path: Path) -> Path:
    """Create a minimal workspace with .adm/config/ structure."""
    (tmp_path / ".adm" / "config").mkdir(parents=True, exist_ok=True)
    return tmp_path


def _default_inputs(
    *,
    enabled: str = "",          # default Y
    bot_var: str = "",           # default ADMIRALTY_SLACK_BOT_TOKEN
    app_var: str = "",
    channel: str = "",
    gist_var: str = "",
    github_var: str = "",
    poll: str = "",
    projects: list[str] | None = None,
    grace: str = "",
    escalations: str = "",
    approvals: str = "",
    blocked: str = "",
) -> list[str]:
    if projects is None:
        projects = [""]  # empty = done
    return [
        enabled,    # Enable bridge? [Y/n]
        bot_var,
        app_var,
        channel,
        gist_var,
        github_var,
        poll,
        *projects,
        grace,
        escalations,
        approvals,
        blocked,
    ]


# ---------------------------------------------------------------------------
# Test 1 — Fresh run, default values, valid JSON written
# ---------------------------------------------------------------------------
def test_fresh_run_writes_valid_config(tmp_path):
    workspace = _make_workspace(tmp_path)
    config_path = workspace / ".adm" / "config" / "bridge-settings.json"
    assert not config_path.exists()

    inputs = _default_inputs()
    with mock.patch("builtins.input", side_effect=inputs):
        setup_wizard(workspace)

    assert config_path.exists(), "Config file should have been written"
    data = json.loads(config_path.read_text(encoding="utf-8"))

    bridge = data["bridge"]
    assert bridge["enabled"] is True
    assert bridge["slack"]["botToken"] == "${ADMIRALTY_SLACK_BOT_TOKEN}"
    assert bridge["slack"]["appToken"] == "${ADMIRALTY_SLACK_APP_TOKEN}"
    assert bridge["slack"]["defaultChannel"] == "#fleet-command"
    assert bridge["queue"]["gistId"] == "${ADMIRALTY_BRIDGE_GIST_ID}"
    assert bridge["queue"]["githubToken"] == "${ADMIRALTY_GITHUB_TOKEN}"
    assert bridge["queue"]["pollIntervalSeconds"] == 30
    assert bridge["projects"] == {}
    assert bridge["notifications"]["gracePeriodMinutes"] == 5


# ---------------------------------------------------------------------------
# Test 2 — Re-run with existing config, decline reconfigure
# ---------------------------------------------------------------------------
def test_existing_config_decline_reconfigure(tmp_path):
    workspace = _make_workspace(tmp_path)
    config_path = workspace / ".adm" / "config" / "bridge-settings.json"

    original = {"bridge": {"enabled": True, "original": True}}
    config_path.write_text(json.dumps(original), encoding="utf-8")

    with mock.patch("builtins.input", side_effect=["n"]) as mock_input:
        setup_wizard(workspace)

    # Only one prompt should have been called (the reconfigure Y/N)
    assert mock_input.call_count == 1
    # File unchanged
    assert json.loads(config_path.read_text()) == original


# ---------------------------------------------------------------------------
# Test 3 — Re-run with existing config, accept reconfigure, file overwritten
# ---------------------------------------------------------------------------
def test_existing_config_accept_reconfigure(tmp_path):
    workspace = _make_workspace(tmp_path)
    config_path = workspace / ".adm" / "config" / "bridge-settings.json"

    original = {"bridge": {"enabled": True, "original": True}}
    config_path.write_text(json.dumps(original), encoding="utf-8")

    inputs = ["y"] + _default_inputs()  # "y" to reconfigure, then defaults
    with mock.patch("builtins.input", side_effect=inputs):
        setup_wizard(workspace)

    data = json.loads(config_path.read_text(encoding="utf-8"))
    assert "original" not in data["bridge"], "Old config should have been overwritten"
    assert "slack" in data["bridge"]


# ---------------------------------------------------------------------------
# Test 4 — KeyboardInterrupt mid-wizard, no partial file written
# ---------------------------------------------------------------------------
def test_keyboard_interrupt_no_partial_file(tmp_path):
    workspace = _make_workspace(tmp_path)
    config_path = workspace / ".adm" / "config" / "bridge-settings.json"

    # Interrupt on the first real prompt (enable bridge)
    with mock.patch("builtins.input", side_effect=KeyboardInterrupt):
        try:
            setup_wizard(workspace)
        except KeyboardInterrupt:
            pass  # propagation is acceptable; what matters is no partial file

    assert not config_path.exists(), "No partial config file should have been written"


# ---------------------------------------------------------------------------
# Test 5 — Invalid poll interval falls back to 30
# ---------------------------------------------------------------------------
def test_invalid_poll_interval_fallback(tmp_path):
    workspace = _make_workspace(tmp_path)
    inputs = _default_inputs(poll="abc")
    with mock.patch("builtins.input", side_effect=inputs):
        setup_wizard(workspace)

    config_path = workspace / ".adm" / "config" / "bridge-settings.json"
    data = json.loads(config_path.read_text(encoding="utf-8"))
    assert data["bridge"]["queue"]["pollIntervalSeconds"] == 30


# ---------------------------------------------------------------------------
# Test 6 — No projects entered, empty projects dict
# ---------------------------------------------------------------------------
def test_no_projects_empty_dict(tmp_path):
    workspace = _make_workspace(tmp_path)
    inputs = _default_inputs(projects=[""])  # immediately blank = done
    with mock.patch("builtins.input", side_effect=inputs):
        setup_wizard(workspace)

    config_path = workspace / ".adm" / "config" / "bridge-settings.json"
    data = json.loads(config_path.read_text(encoding="utf-8"))
    assert data["bridge"]["projects"] == {}


# ---------------------------------------------------------------------------
# Test 7 — bridge_status reads new config without error
# ---------------------------------------------------------------------------
def test_bridge_status_reads_config_after_setup(tmp_path):
    workspace = _make_workspace(tmp_path)
    (workspace / ".adm" / "bridge").mkdir(parents=True, exist_ok=True)

    inputs = _default_inputs()
    with mock.patch("builtins.input", side_effect=inputs):
        setup_wizard(workspace)

    # bridge_status should not raise
    status = bridge_status(workspace)
    assert status["config_exists"] is True
