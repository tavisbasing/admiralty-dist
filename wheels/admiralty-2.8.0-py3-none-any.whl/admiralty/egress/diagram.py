# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Admiralty data-flow diagram generator.

Produces a Mermaid (default) or Graphviz diagram of every outbound
destination the workspace is configured to reach.

Known static destinations are hard-coded; dynamic destinations (bridge
Slack channel, gist, etc.) are read from workspace configuration files.

CLI:  adm data-flow [--format mermaid|graphviz] [--mode permissive|restrictive|air-gapped] [--output PATH]
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional, Tuple


# ---------------------------------------------------------------------------
# Static destination catalogue
# ---------------------------------------------------------------------------

# (component, host, purpose)
_STATIC_DESTINATIONS: List[Tuple[str, str, str]] = [
    ("auth", "api.github.com", "licence collaborator check"),
    ("bridge_poller", "api.github.com", "gist command queue poll/write"),
    ("bridge_notifier", "slack.com", "Slack chat.postMessage API"),
    ("bridge_slack_bot", "slack.com", "Slack Socket Mode WebSocket"),
]

_LOCAL_DESTINATIONS: List[Tuple[str, str, str]] = [
    ("local_services", "localhost", "local mock providers / databases"),
]


def _collect_destinations(
    workspace: Path,
    mode: Optional[str] = None,
) -> List[Tuple[str, str, str]]:
    """
    Return all outbound destinations for this workspace filtered by mode.

    In air-gapped mode only local destinations are returned.
    In restrictive mode only allowlisted destinations are returned.
    In permissive mode (default) the full static catalogue is returned.
    """
    # Read workspace config to determine effective mode when not overridden
    effective_mode = mode
    ws_cfg = workspace / ".adm" / "config" / "workspace.json"
    allowlist: List[str] = []
    proxy_url: Optional[str] = None

    if ws_cfg.exists():
        try:
            ws = json.loads(ws_cfg.read_text(encoding="utf-8"))
            dr = ws.get("dataResidency", {})
            if effective_mode is None:
                effective_mode = dr.get("mode", "permissive")
            allowlist = dr.get("allowedDestinations", [])
            proxy_url = (dr.get("proxy") or {}).get("url")
        except Exception:
            pass

    if effective_mode is None:
        effective_mode = "permissive"

    if effective_mode == "air-gapped":
        return list(_LOCAL_DESTINATIONS)

    destinations = list(_STATIC_DESTINATIONS)

    # Bridge settings — detect Teams webhook if configured
    bridge_cfg = workspace / ".adm" / "config" / "bridge-settings.json"
    if bridge_cfg.exists():
        try:
            bs = json.loads(bridge_cfg.read_text(encoding="utf-8"))
            teams_webhook = (
                bs.get("bridge", {}).get("teams", {}).get("webhookUrl", "")
            )
            if teams_webhook and "teams.microsoft.com" in teams_webhook:
                destinations.append(
                    ("bridge_notifier", "teams.microsoft.com", "Teams incoming webhook")
                )
            gist_host = (
                bs.get("bridge", {}).get("queue", {}).get("apiHost", "")
            )
            if gist_host and gist_host not in ("api.github.com", ""):
                destinations.append(
                    ("bridge_poller", gist_host, "GitHub Enterprise gist queue")
                )
        except Exception:
            pass

    # MCP servers
    mcp_cfg = workspace / ".adm" / "config" / "mcp-servers.json"
    if mcp_cfg.exists():
        try:
            mcp = json.loads(mcp_cfg.read_text(encoding="utf-8"))
            for srv in mcp.get("servers", []):
                cmd = srv.get("command", "")
                name = srv.get("name", "unknown-mcp")
                if cmd in ("npx", "node"):
                    destinations.append(
                        ("mcp/" + name, "registry.npmjs.org", "npx package fetch (MCP install)")
                    )
        except Exception:
            pass

    # Workspace allowlist entries
    if ws_cfg.exists():
        try:
            ws = json.loads(ws_cfg.read_text(encoding="utf-8"))
            for pattern in ws.get("dataResidency", {}).get("allowedDestinations", []):
                already = any(d[1] == pattern for d in destinations)
                if not already:
                    destinations.append(("workspace/allowlist", pattern, "allowlisted destination"))
        except Exception:
            pass

    # In restrictive mode, filter destinations to only those matching the allowlist
    if effective_mode == "restrictive" and allowlist:
        import fnmatch
        filtered = []
        for comp, host, purpose in destinations:
            if any(fnmatch.fnmatch(host.lower(), p.lower()) for p in allowlist):
                filtered.append((comp, host, purpose))
        destinations = filtered

    # Annotate proxy if configured
    if proxy_url:
        destinations.append(("proxy_gateway", proxy_url, "corporate proxy (all egress routed here)"))

    return destinations


# ---------------------------------------------------------------------------
# Mermaid renderer
# ---------------------------------------------------------------------------

def _render_mermaid(workspace: Path, mode: Optional[str] = None) -> str:
    destinations = _collect_destinations(workspace, mode=mode)
    effective_mode = mode or "permissive"

    lines = [
        "flowchart LR",
        f'    Fleet([Fleet Command — EGRESS MODE: {effective_mode.upper()}])',
    ]

    hosts_seen = {}
    for _, host, _ in destinations:
        node_id = host.replace(".", "_").replace("-", "_").replace("*", "WILD").replace(":", "_")
        if host not in hosts_seen:
            hosts_seen[host] = node_id
            lines.append(f'    {node_id}["{host}"]')

    lines.append("")

    for component, host, purpose in destinations:
        node_id = hosts_seen[host]
        comp_safe = component.replace("/", "_").replace("-", "_")
        lines.append(f'    Fleet -- "{comp_safe}: {purpose}" --> {node_id}')

    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Graphviz renderer
# ---------------------------------------------------------------------------

def _render_graphviz(workspace: Path, mode: Optional[str] = None) -> str:
    destinations = _collect_destinations(workspace, mode=mode)
    effective_mode = mode or "permissive"

    lines = [
        'digraph admiralty_egress {',
        '    rankdir=LR;',
        '    node [shape=box];',
        f'    "Fleet Command\\n(EGRESS MODE: {effective_mode.upper()})" [shape=ellipse];',
    ]

    fleet_label = f"Fleet Command\\n(EGRESS MODE: {effective_mode.upper()})"
    for component, host, purpose in destinations:
        label = f"{component}\\n{purpose}"
        lines.append(f'    "{fleet_label}" -> "{host}" [label="{label}"];')

    lines.append("}")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def generate_diagram(
    workspace: Path,
    fmt: str = "mermaid",
    output: Optional[Path] = None,
    mode: Optional[str] = None,
) -> str:
    """
    Generate a data-flow diagram for the workspace.

    Args:
        workspace: Path to the workspace root (contains .adm/).
        fmt:       "mermaid" (default) or "graphviz".
        output:    Write to this path instead of returning.
        mode:      Override the egress mode for rendering
                   ("permissive", "restrictive", "air-gapped").
                   When None, the mode is read from workspace.json.

    Returns:
        The diagram as a string (even when output is given).
    """
    if fmt == "graphviz":
        diagram = _render_graphviz(workspace, mode=mode)
    else:
        diagram = _render_mermaid(workspace, mode=mode)

    if output:
        output.write_text(diagram, encoding="utf-8")

    return diagram
