# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Air-gap mode helpers for the Admiralty egress filter.

In air-gapped mode ALL outbound HTTP is denied except requests to
localhost / 127.0.0.1 / ::1 and Unix domain sockets (empty host).
"""

from __future__ import annotations

# Hosts that are always reachable in air-gapped mode (local services).
LOCAL_HOSTS: frozenset[str] = frozenset({
    "localhost",
    "127.0.0.1",
    "::1",
})


def is_local(host: str) -> bool:
    """
    Return True if the host refers to a local / loopback destination.

    An empty host string is treated as a Unix socket, which is also local.
    """
    if not host:
        return True  # Unix socket — no network hop
    return host.lower() in LOCAL_HOSTS
