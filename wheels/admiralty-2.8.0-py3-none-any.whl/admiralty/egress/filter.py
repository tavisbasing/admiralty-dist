# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Central egress filter — allowlist enforcement for all outbound HTTP.

Enterprise feature gated by workspace.json: enterprise: true.
In default (permissive) mode this module is a no-op.

Architecture:
- EgressFilter holds the parsed allowlist and exposes is_allowed(host).
- install_egress_filter() installs a urllib opener that pre-checks every
  request against the allowlist.  All stdlib urllib callers are covered
  automatically once installed.
- get_session() returns a requests.Session with a custom transport adapter
  that performs the same check (for any callers using requests directly).
- Both raise EgressDenied for non-allowlisted hosts.

Modes (workspace.json: dataResidency.mode):
  permissive  — default; no restrictions (non-enterprise workspaces always land here)
  restrictive — allowlist enforced via dataResidency.allowedDestinations
  air-gapped  — ALL outbound denied except localhost / 127.0.0.1 / ::1 / Unix sockets

Proxy (workspace.json: dataResidency.proxy):
  When configured, get_session() routes traffic through the proxy but the
  egress check still inspects the INTENDED destination URL, not the proxy host.
"""

from __future__ import annotations

import fnmatch
import json
import logging
import urllib.error
import urllib.request
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse

from admiralty.egress.airgap import is_local
from admiralty.egress.proxy import ProxyConfig, parse_proxy_config

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------

class EgressDenied(Exception):
    """Raised when an outbound request targets a host not in the allowlist."""

    def __init__(self, host: str, allowed: List[str], reason: str = "") -> None:
        self.host = host
        self.allowed = allowed
        hint = ", ".join(allowed) if allowed else "(none configured)"
        detail = f" ({reason})" if reason else ""
        super().__init__(
            f"Egress denied{detail}: '{host}' is not in allowedDestinations.\n"
            f"Allowed patterns: {hint}\n"
            "Add the host to workspace.json dataResidency.allowedDestinations."
        )


# ---------------------------------------------------------------------------
# Core filter
# ---------------------------------------------------------------------------

class EgressFilter:
    """Holds the egress allowlist and evaluates hosts against it."""

    VALID_MODES = ("permissive", "restrictive", "air-gapped")

    def __init__(
        self,
        patterns: List[str],
        mode: str = "permissive",
        proxy: Optional[ProxyConfig] = None,
    ) -> None:
        self.patterns = patterns
        self.mode = mode if mode in self.VALID_MODES else "permissive"
        self.proxy = proxy

    @classmethod
    def from_workspace(cls, workspace: Path) -> "EgressFilter":
        """Load filter config from workspace.json. Default: permissive."""
        ws_cfg = workspace / ".adm" / "config" / "workspace.json"
        if not ws_cfg.exists():
            return cls([], mode="permissive")

        try:
            data = json.loads(ws_cfg.read_text(encoding="utf-8"))
        except Exception:
            return cls([], mode="permissive")

        # Enterprise gate — non-enterprise workspaces are always permissive
        if not data.get("enterprise", False):
            return cls([], mode="permissive")

        dr = data.get("dataResidency", {})
        mode = dr.get("mode", "permissive")
        patterns: List[str] = dr.get("allowedDestinations", [])
        proxy = parse_proxy_config(dr)

        return cls(patterns, mode=mode, proxy=proxy)

    def is_allowed(self, host: str) -> bool:
        """Return True if the host is permitted under the current mode."""
        if self.mode == "air-gapped":
            return is_local(host)
        if self.mode != "restrictive":
            return True
        # restrictive mode
        if not self.patterns:
            return False
        host_lower = host.lower()
        return any(fnmatch.fnmatch(host_lower, p.lower()) for p in self.patterns)

    def check(self, host: str) -> None:
        """Raise EgressDenied if the host is not allowed."""
        if not self.is_allowed(host):
            reason = "air-gap mode" if self.mode == "air-gapped" else ""
            raise EgressDenied(host, self.patterns, reason=reason)


# ---------------------------------------------------------------------------
# Singleton state
# ---------------------------------------------------------------------------

_active_filter: Optional[EgressFilter] = None


def _get_active_filter() -> EgressFilter:
    global _active_filter
    if _active_filter is None:
        _active_filter = EgressFilter([], mode="permissive")
    return _active_filter


# ---------------------------------------------------------------------------
# urllib integration
# ---------------------------------------------------------------------------

class _EgressHandler(urllib.request.BaseHandler):
    """urllib handler that enforces the egress allowlist before every request."""

    handler_order = 100  # run before HTTPHandler (order 500)

    def http_open(self, req: urllib.request.Request):
        host = urlparse(req.full_url).hostname or req.host.split(":")[0]
        _get_active_filter().check(host)
        return None  # returning None passes control to the next handler

    https_open = http_open


def install_egress_filter(workspace: Path) -> EgressFilter:
    """
    Load the egress filter from workspace.json and install it globally.

    - Installs a urllib opener that pre-checks every outbound request.
    - Stores the filter for get_session() to use.
    - Returns the installed EgressFilter (permissive by default).
    - Logs a prominent startup line announcing the active mode.
    """
    global _active_filter
    ef = EgressFilter.from_workspace(workspace)
    _active_filter = ef

    mode_label = ef.mode.upper().replace("-", "_")
    logger.info("EGRESS MODE: %s", mode_label)
    print(f"[Admiralty] EGRESS MODE: {mode_label}", flush=True)

    if ef.mode in ("restrictive", "air-gapped"):
        opener = urllib.request.build_opener(_EgressHandler)
        urllib.request.install_opener(opener)

    return ef


# ---------------------------------------------------------------------------
# requests integration (optional — only if requests is installed)
# ---------------------------------------------------------------------------

def get_session():
    """
    Return a requests.Session with egress enforcement.

    - In proxy mode, routes all traffic through the configured proxy while
      still checking the INTENDED destination against the allowlist.
    - Falls back to a plain session-like object using urllib if requests is
      not installed.  Callers should use session.get() / session.post() only.
    """
    try:
        import requests
        from requests.adapters import HTTPAdapter

        active = _get_active_filter()

        class _EgressAdapter(HTTPAdapter):
            def send(self, prepared_request, **kwargs):
                host = urlparse(prepared_request.url).hostname or ""
                active.check(host)
                return super().send(prepared_request, **kwargs)

        session = requests.Session()
        adapter = _EgressAdapter()
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        if active.proxy:
            session.proxies.update(active.proxy.proxies_dict)
            if active.proxy.authentication:
                from requests.auth import HTTPProxyAuth
                auth = active.proxy.authentication
                username = auth.get("username", "")
                password = auth.get("password", "")
                if username:
                    session.auth = HTTPProxyAuth(username, password)

        return session
    except ImportError:
        return _UrllibSession()


class _UrllibSession:
    """Minimal requests-compatible session backed by urllib."""

    def get(self, url: str, headers: dict = None, timeout: int = 30, **_):
        host = urlparse(url).hostname or ""
        _get_active_filter().check(host)
        req = urllib.request.Request(url, headers=headers or {})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return _UrllibResponse(resp)

    def post(self, url: str, data=None, json_data=None, headers: dict = None,
             timeout: int = 30, **_):
        import json as _json
        host = urlparse(url).hostname or ""
        _get_active_filter().check(host)
        body = None
        h = dict(headers or {})
        if json_data is not None:
            body = _json.dumps(json_data).encode("utf-8")
            h.setdefault("Content-Type", "application/json")
        elif data is not None:
            body = data if isinstance(data, bytes) else str(data).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers=h, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return _UrllibResponse(resp)


class _UrllibResponse:
    def __init__(self, resp):
        self.status_code = resp.status
        self._body = resp.read()
        self.headers = dict(resp.headers)

    def json(self):
        import json as _json
        return _json.loads(self._body.decode("utf-8"))

    @property
    def text(self):
        return self._body.decode("utf-8", errors="replace")

    def raise_for_status(self):
        if self.status_code >= 400:
            raise urllib.error.HTTPError(
                None, self.status_code, f"HTTP {self.status_code}", {}, None
            )


# ---------------------------------------------------------------------------
# Convenience check
# ---------------------------------------------------------------------------

def is_host_allowed(host: str) -> bool:
    """Check a host against the active filter without raising."""
    return _get_active_filter().is_allowed(host)
