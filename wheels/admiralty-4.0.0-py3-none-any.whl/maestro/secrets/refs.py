"""
Secret reference resolution for the secret://<provider>/<namespace>/<key> scheme.

Usage (at the use site, never at config-load time):
    from maestro.secrets.refs import resolve_secret_refs, install_log_scrub

    config = resolve_secret_refs(raw_config, workspace=Path('.'))
    install_log_scrub()
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

_REF_PATTERN = re.compile(r"^secret://([^/]+)/([^/]+)/([^/\s]+)$")
_REF_INLINE = re.compile(r"secret://[^\s\"']+")

logger = logging.getLogger(__name__)


# =============================================================================
# REF PARSING
# =============================================================================


@dataclass(frozen=True)
class SecretRef:
    provider: str
    namespace: str
    key: str

    def __str__(self) -> str:
        return f"secret://{self.provider}/{self.namespace}/{self.key}"


def parse_ref(value: str) -> SecretRef | None:
    """Parse a secret:// reference string. Returns None if not a ref."""
    m = _REF_PATTERN.match(value.strip())
    if not m:
        return None
    return SecretRef(provider=m.group(1), namespace=m.group(2), key=m.group(3))


# =============================================================================
# RESOLUTION
# =============================================================================


def _is_enterprise(workspace: Path | None) -> bool:
    if workspace is None:
        return False
    try:
        from maestro.secrets.registry import _load_enterprise_flag
        return _load_enterprise_flag(workspace)
    except Exception:
        return False


def resolve_ref(ref: SecretRef, workspace: Path | None = None) -> str | None:
    """
    Resolve a single SecretRef to its plaintext value via the active SecretsProvider.

    The provider field is reserved for future multi-provider dispatch; currently
    the workspace's single configured provider is used regardless of provider name.
    Returns None when the key is not found.
    """
    try:
        from maestro.secrets.registry import get_provider
        provider = get_provider(workspace or Path.cwd())
        return provider.get(ref.key)
    except Exception as exc:
        logger.debug("resolve_ref error for %s: %s", ref, exc)
        return None


def resolve_secret_refs(
    config: Any,
    workspace: Path | None = None,
    *,
    _resolved_values: set[str] | None = None,
) -> Any:
    """
    Walk a config dict/list/str and resolve secret:// references lazily.

    Call at the *use site*, not at config-load time.

    Feature-gated: when enterprise is False, secret:// strings pass through
    unchanged (with a debug-level warning) so downstream tooling is not broken.
    """
    enterprise = _is_enterprise(workspace)
    bucket: set[str] = _resolved_values if _resolved_values is not None else set()
    result = _walk(config, workspace, enterprise, bucket)
    # Register any newly resolved values with the scrub filter
    if bucket:
        flt = get_scrub_filter()
        if flt is not None:
            for v in bucket:
                flt.add_resolved(v)
    return result


def _walk(obj: Any, workspace: Path | None, enterprise: bool, resolved: set[str]) -> Any:
    if isinstance(obj, str):
        ref = parse_ref(obj)
        if ref is None:
            return obj
        if not enterprise:
            logger.debug(
                "secret:// reference found but enterprise mode is disabled — "
                "passing through: %s", obj
            )
            return obj
        value = resolve_ref(ref, workspace)
        if value is None:
            logger.warning("secret:// reference could not be resolved: %s", obj)
            return obj
        resolved.add(value)
        return value
    if isinstance(obj, dict):
        return {k: _walk(v, workspace, enterprise, resolved) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_walk(v, workspace, enterprise, resolved) for v in obj]
    return obj


# =============================================================================
# LOGGING SCRUB FILTER
# =============================================================================


class SecretScrubFilter(logging.Filter):
    """
    Logging filter that redacts secret:// references and resolved secret values
    from all log records before they are written to any handler.
    """

    def __init__(self, resolved_values: set[str] | None = None) -> None:
        super().__init__()
        self._resolved: set[str] = set(resolved_values) if resolved_values else set()

    def add_resolved(self, value: str) -> None:
        """Register a plaintext value that should be redacted from logs."""
        self._resolved.add(value)

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self._scrub(str(record.msg))
        if record.args:
            record.args = self._scrub_args(record.args)
        return True

    def _scrub(self, text: str) -> str:
        def _replace_ref(m: re.Match) -> str:
            return f"[REDACTED:{m.group(0)}]"

        text = _REF_INLINE.sub(_replace_ref, text)
        for val in self._resolved:
            if val and val in text:
                text = text.replace(val, "[REDACTED:secret-value]")
        return text

    def _scrub_args(self, args: Any) -> Any:
        if isinstance(args, tuple):
            return tuple(self._scrub(str(a)) if isinstance(a, str) else a for a in args)
        if isinstance(args, dict):
            return {k: self._scrub(str(v)) if isinstance(v, str) else v for k, v in args.items()}
        return args


_SCRUB_FILTER: SecretScrubFilter | None = None


def install_log_scrub(workspace: Path | None = None) -> SecretScrubFilter:  # noqa: ARG001
    """
    Install the SecretScrubFilter on the root logger (idempotent).
    Returns the singleton filter so callers can register resolved values.
    """
    global _SCRUB_FILTER
    if _SCRUB_FILTER is None:
        _SCRUB_FILTER = SecretScrubFilter()
        logging.getLogger().addFilter(_SCRUB_FILTER)
    return _SCRUB_FILTER


def get_scrub_filter() -> SecretScrubFilter | None:
    """Return the active scrub filter, or None if not yet installed."""
    return _SCRUB_FILTER


# =============================================================================
# MIGRATION HELPER
# =============================================================================


def scan_config_for_cleartext(config_path: Path, workspace: Path | None = None) -> list[str]:
    """
    Scan a config file for likely cleartext secrets and emit a warning per finding.

    Re-uses admiralty/hooks/secret_patterns.py Scanner (VOY-0022) for pattern detection.
    Returns a list of warning strings (also logged at WARNING level).
    """
    if not config_path.exists():
        return []
    warnings: list[str] = []
    try:
        from maestro.hooks.secret_patterns import Scanner
        scanner = Scanner(workspace_root=workspace)
        text = config_path.read_text(encoding="utf-8", errors="replace")
        matches = scanner.scan(text, field_label=str(config_path), rel_path=str(config_path))
        for m in matches:
            msg = (
                f"[secrets] Possible cleartext secret in {config_path}: "
                f"pattern '{m.pattern_name}' (severity={m.severity}). "
                "Consider replacing with a secret:// reference."
            )
            warnings.append(msg)
            logger.warning(msg)
    except ImportError:
        pass
    except Exception as exc:
        logger.debug("scan_config_for_cleartext error: %s", exc)
    return warnings


def maybe_warn_cleartext(workspace: Path | None = None) -> None:
    """
    When workspace.json declares a secretsProvider, scan known config files for
    cleartext secrets and warn. Called once at startup in enterprise mode.
    """
    if workspace is None:
        return
    if not _is_enterprise(workspace):
        return

    import json as _json

    ws_cfg = workspace / ".adm" / "config" / "workspace.json"
    if not ws_cfg.exists():
        return
    try:
        data = _json.loads(ws_cfg.read_text(encoding="utf-8"))
    except Exception:
        return

    if not data.get("secretsProvider"):
        return

    config_dir = workspace / ".adm" / "config"
    if not config_dir.is_dir():
        return
    for cfg_file in config_dir.glob("*.json"):
        scan_config_for_cleartext(cfg_file, workspace)
