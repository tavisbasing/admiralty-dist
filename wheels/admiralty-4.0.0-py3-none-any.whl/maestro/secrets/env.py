from __future__ import annotations

import os

from .base import SecretsProvider

_DEFAULT_PREFIX = "MAESTRO_SECRET_"


class EnvSecretsProvider(SecretsProvider):
    """
    Reads secrets from environment variables.

    Keys are stored as env vars: <prefix><KEY> (uppercased).
    Default prefix: MAESTRO_SECRET_
    Override via config: {"prefix": "MY_PREFIX_"}
    """

    def __init__(self, config: dict | None = None) -> None:
        cfg = config or {}
        self._prefix = cfg.get("prefix", _DEFAULT_PREFIX)

    def _env_key(self, key: str) -> str:
        return self._prefix + key.upper()

    def get(self, key: str) -> str | None:
        return os.environ.get(self._env_key(key))

    def set(self, key: str, value: str) -> None:
        os.environ[self._env_key(key)] = value

    def delete(self, key: str) -> None:
        os.environ.pop(self._env_key(key), None)

    def list(self) -> list[str]:
        prefix = self._prefix
        return [
            k[len(prefix):].lower()
            for k in os.environ
            if k.startswith(prefix)
        ]
