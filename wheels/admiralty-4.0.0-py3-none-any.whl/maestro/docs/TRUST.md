# Maestro — Trust & Security

> **Scope:** How Maestro handles your code, your secrets, and your data. Written for engineers, security teams, and procurement. If something here is incomplete or not yet implemented, we say so explicitly and say when it will be.

---

## Contents

1. [Our Promise](#1-our-promise)
2. [Data Flow Guarantees](#2-data-flow-guarantees)
3. [Threat Model Summary](#3-threat-model-summary)
4. [Compliance Posture](#4-compliance-posture)
5. [Subprocessors](#5-subprocessors)
6. [Vulnerability Disclosure Policy](#6-vulnerability-disclosure-policy)
7. [Air-Gapped Operation](#7-air-gapped-operation)
8. [Open-Source Security Tooling](#8-open-source-security-tooling)

---

## 1. Our Promise

Maestro is a locally-executed orchestration layer for Claude Code crews. It runs entirely on your own machine or your own infrastructure — there are no Maestro-operated servers, no cloud control plane, and no telemetry callbacks. Your code, your prompts, your secrets, and your artefacts never leave the environment you choose to run them in. You bring your own Anthropic API key (BYOK); Maestro never holds or proxies it. The only outbound connections Maestro makes are the ones you explicitly configure: the Anthropic API for model inference, your chosen licence backend for tier validation (if applicable), and any external anchors or integrations you opt into. Every one of those destinations is enumerable, allowlistable, and — in enterprise mode — enforceable with a hard egress filter. What goes to Anthropic is limited to the prompt content each Claude Code crew generates; your source repository never transits any Maestro-operated system.

---

## 2. Data Flow Guarantees

### What leaves your environment and where it goes

| Data | Destination | Condition | Opt-out |
|------|-------------|-----------|---------|
| Prompt + context for each crew turn | Anthropic API (`api.anthropic.com`) | Always, when a crew is running | Use air-gapped mode with a local model endpoint |
| Licence key (hash only) | Licence backend (see §5) | Paid tiers only; not in trial or open-source builds | N/A for open-source |
| Audit log anchors | Customer-configured S3 / Azure Blob / filesystem | Enterprise mode, when `audit.anchorProvider` is set | Set to `filesystem` for local-only anchoring |
| Bridge messages | Customer-configured Slack workspace | Only when `mso bridge` is started | Don't start the bridge |

Nothing else leaves. Specifically:

- No file contents are sent to any Maestro-operated endpoint.
- No usage telemetry, crash reports, or analytics are collected.
- No credentials or resolved secret values are transmitted beyond the configured secrets provider.

### How you can verify

1. **Egress filter (`restrictive` mode):** set `dataResidency.mode: "restrictive"` and `allowedDestinations` to an explicit list. Maestro will raise `EgressDenied` on any connection not in the allowlist. Run `adm data-flow diagram` to see the current allowed graph.
2. **Network-layer verification:** run Maestro behind a corporate proxy or firewall and inspect traffic. Nothing surprising should appear.
3. **Source audit:** Maestro is open-source. The outbound connection points are in `maestro/core/` and `maestro/audit/anchor/`. There are no obfuscated or compiled call sites.
4. **Subprocess env scrub:** in enterprise mode, every crew process is launched via `maestro/launch/sandbox.py:spawn()`, which builds a minimal environment from scratch. Verify with `strace` / `procmon` that child processes do not inherit your shell environment.

> **Known gap:** the egress filter operates at the urllib/requests layer and does not intercept raw socket calls or subprocess network activity (open finding 4.1 from the V6 pen-test). Combine the application-layer filter with a network-layer firewall or egress proxy for complete coverage. This will be patched in the v3.0.x release.

---

## 3. Threat Model Summary

Maestro's security design was reviewed twice during the V6 enterprise hardening voyage (VOY-ADM-2026-0026):

| Phase | Report | Outcome |
|-------|--------|---------|
| Pre-implementation design review | SEC-FTR-ADM-2026-0053 | 2 CRITICAL + 3 HIGH design findings — all addressed in FTR-0067 through FTR-0071 |
| Post-implementation pen-test | SEC-FTR-ADM-2026-0064 | **2 CRITICAL + 2 HIGH + 5 MEDIUM** findings — partially open |

### Assets protected

- Source code and artefacts in `.adm/` (plans, orders, voyage records)
- Secrets referenced via the secrets provider
- Identity and ACL records in `.adm/identity/`
- The audit log

### Primary threat actors considered

- Malicious crew output attempting to exfiltrate secrets or escalate privilege via prompt injection
- Insider threat (a human operator editing identity or ACL files directly to elevate privilege)
- Compromised MCP server injecting tool calls that bypass the egress filter

### Controls in place

| Control | Mechanism |
|---------|-----------|
| Privilege escalation via direct file edit | Identity integrity guard (FTR-0067): every identity file load verifies git tracking or SHA-256 hash match; failure raises `IdentityIntegrityError` |
| Secrets exfiltration via logs | Central log filter replaces resolved secret values with `[REDACTED:secret://...]`; subprocess env is scrubbed before crew launch (FTR-0069) |
| Unbounded outbound connections | Egress filter with `restrictive` / `air-gapped` modes (FTR-0070) |
| Unattributed privileged actions | Immutable audit log with hash chain + external anchoring (FTR-0068) |
| Prompt injection via MCP server output | MCP server allowlist with risk levels (see §8) |

### Open findings that block v3.0.0 production use

| ID | Severity | Summary | Interim mitigation |
|----|----------|---------|-------------------|
| 2.2 | CRITICAL | Audit log truncation not detected by `verify_chain` | Frequent external anchoring; treat log as modification-detectable but not truncation-detectable |
| 3.1a | CRITICAL | `print()` and subprocess stdout bypass the central secrets scrub | Avoid `print()` in any code path that handles resolved secret values |
| 3.1b | HIGH | Logging exfil paths not exhaustively covered | As above |
| 4.1 | HIGH | Egress filter does not intercept raw socket / subprocess network | Combine with network-layer firewall or egress proxy |

A v3.0.x patch voyage is committed to closing these findings before any production customer deployment. Until then, **do not deploy V6 enterprise controls to production without an independent external security review** — the internal LKT pen-test was performed for design validation, not as a certification substitute.

---

## 4. Compliance Posture

**Current status (as of v2.0.0 / v3.0.0 development):**

- Maestro is **not** SOC 2 certified.
- Maestro is **not** ISO 27001 certified.
- No third-party audit has been commissioned.

**What we do ship:**

Maestro 3.0 (Enterprise tier) includes controls that *support* SOC 2 Common Criteria and ISO/IEC 27001:2022 Annex A objectives. The companion [COMPLIANCE-MAPPING.md](COMPLIANCE-MAPPING.md) maps each control to the relevant framework clause and notes where coverage is partial or carries an open finding. That document is a feature description, not an audit opinion.

**Planned:**

SOC 2 Type II attestation is targeted for the Enterprise tier following general availability and resolution of the open V6 findings. No date is committed. Customers requiring certified compliance today should engage their own assessor against the COMPLIANCE-MAPPING.md evidence set and treat V6 controls as supporting — not certifying — their own audit.

**What to tell your auditor:**

- Maestro executes locally; no data transits Maestro-operated systems.
- Anthropic is a subprocessor for model inference (see §5).
- V6 enterprise controls are designed to support SOC 2 CC6, CC7, CC8 and ISO 27001 A.8. Mapping detail is in COMPLIANCE-MAPPING.md.
- Four CRITICAL/HIGH findings are open and documented; mitigations are in place; a patch voyage is planned.

---

## 5. Subprocessors

Maestro itself operates no servers and processes no customer data. The following third parties are involved depending on your configuration:

| Subprocessor | Role | Data sent | Required? | DPA / Privacy docs |
|---|---|---|---|---|
| **Anthropic** (`api.anthropic.com`) | Model inference — processes each crew's prompt context | Prompt content for each crew turn | Yes, when running crews | [Anthropic Privacy Policy](https://www.anthropic.com/privacy); [Anthropic API Terms](https://www.anthropic.com/legal) |
| **Licence backend** (TBD) | Tier validation — confirms licence key validity | Hashed licence key; no code or artefacts | Paid tiers only (not open-source builds) | To be published when licence system ships (currently access is GitHub collaborator–based; no external licence backend is active) |

No other subprocessors exist. When you configure optional integrations (Slack bridge, audit anchors, external secrets providers), those are your own services — Maestro acts as a client to infrastructure you control.

> The licence key backend is not yet implemented. Current releases use GitHub collaborator access. This table will be updated, with a DPA link, when the licence system ships.

---

## 6. Vulnerability Disclosure Policy

We take security reports seriously and commit to responding promptly and transparently.

### How to report

**Email:** maestro@tech127.com *(placeholder — update to active address before GA)*

Please include:
- Description of the vulnerability and the conditions required to trigger it
- Steps to reproduce, with the Maestro version and OS
- Assessment of impact and exploitability
- Whether you would like public credit in the advisory

### What to expect

| Stage | Timeline |
|-------|----------|
| Initial acknowledgement | Within 2 business days |
| Triage and severity assessment | Within 5 business days |
| Status update (fix timeline or mitigation) | Within 10 business days |
| Public disclosure | Coordinated with reporter; default 90 days from acknowledgement |

We follow coordinated disclosure. We will not take legal action against researchers who report in good faith under this policy.

### Scope

In scope: the Maestro pip package (`maestro/` source), the `mso` CLI, and the `.mso/` artefact schema.

Out of scope: vulnerabilities in Anthropic's API or Claude Code itself (report those to Anthropic), vulnerabilities in third-party MCP servers you choose to install, or issues that require physical access to the operator's machine.

### Known open findings

The V6 enterprise hardening pen-test (SEC-FTR-ADM-2026-0064) identified four CRITICAL/HIGH open findings documented in §3 above. These are known, tracked, and will be patched in v3.0.x. You do not need to report them again, but if you find a novel exploitation path against them we want to know.

---

## 7. Air-Gapped Operation

Maestro supports fully air-gapped operation in Enterprise tier via `dataResidency.mode: "air-gapped"`. In this mode:

- All outbound HTTP is blocked at the application layer except `localhost`, `127.0.0.1`, `::1`, and Unix sockets.
- Startup logs `EGRESS MODE: AIR-GAPPED` prominently so operators can verify the mode is active.
- Crew inference must be served by a local model endpoint (e.g., a self-hosted Anthropic-compatible API, Ollama, or similar).
- The Slack bridge cannot be used; all crew communication is local.

Configure in `workspace.json`:

```json
{
  "enterprise": true,
  "dataResidency": {
    "mode": "air-gapped"
  }
}
```

> **Note:** ARCHITECTURE.md (planned for v3.0.0 docs) will include a full data-flow diagram for each residency mode. Until it exists, use `adm data-flow diagram --mode air-gapped` to generate the current Mermaid diagram for your deployment.

> **Known gap:** the application-layer egress filter does not intercept raw socket calls or subprocess network activity (open finding 4.1). For a genuine air-gap, back this with a network-layer firewall that blocks all outbound except your local model endpoint.

---

## 8. Open-Source Security Tooling

Maestro ships three security capabilities as part of the core package, available to all tiers:

### Secret detection (v2.3.0 — VOY-ADM-2026-0022)

A pre-tool hook scans every file the crew is about to read or write for patterns matching common secret formats (API keys, tokens, connection strings). Matches block the tool call and log a warning. The pattern library is open-source and in `maestro/hooks/pretool/`. You can extend it with custom patterns via `workspace.json: security.secretPatterns`.

The central log filter also runs continuously: any `secret://...` reference string or known resolved value that appears in a log line is replaced with `[REDACTED:secret://...]` before emission.

> **Known gap:** the log filter covers the `logging` module but not `print()` calls or subprocess stdout (open finding 3.1). Avoid `print()` in code paths that may handle resolved secret values until this is patched in v3.0.x.

Audit all detected secrets:

```bash
adm secrets scrub        # Scan config + logs for cleartext patterns
adm secrets doctor       # Verify every secret:// reference resolves
```

### OWASP / CWE scanning (v2.3.0 — VOY-ADM-2026-0024)

A post-tool hook runs static analysis on files written by crews, checking against an OWASP Top 10 and CWE Top 25 pattern set. Findings are reported as crew warnings and logged. The COX integration gate can be configured to block merge on any unresolved HIGH or CRITICAL finding.

Scan output is written to `.adm/reports/security/` for audit trail purposes.

### MCP server risk levels (v2.3.0 — VOY-ADM-2026-0023)

The MCP server registry (`workspace.json: mcp.servers`) assigns each configured server a risk tier:

| Tier | Meaning | Default crew permission |
|------|---------|------------------------|
| `low` | Read-only, sandboxed, no network | Allowed without prompt |
| `medium` | May write files or make network calls to allowlisted hosts | Allowed with audit log entry |
| `high` | Arbitrary network or system access | Requires explicit Captain approval per voyage |
| `blocked` | Prohibited by policy | Never allowed |

Risk levels are enforced at dispatch time. A crew cannot use an MCP server at a higher tier than its voyage approval specifies. This provides a documented, auditable control against prompt injection via compromised MCP servers.

---

*Questions not answered here? Email maestro@tech127.com for security matters, or see [SUPPORT.md](SUPPORT.md) for general support channels.*
