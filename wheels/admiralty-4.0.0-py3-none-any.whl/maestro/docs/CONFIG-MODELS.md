# Configuring per-role models

Maestro assigns a Claude model to each role based on what the role does:

| Role | Default model | Why |
|------|---------------|-----|
| **COX** — Coxswain | `claude-opus-4-7` | Integration review + quality gates — best judgement matters most |
| **NAV** — Navigator | `claude-sonnet-4-6` | Planning, architecture |
| **SHP** — Shipwright | `claude-sonnet-4-6` | Implementation |
| **BOS** — Bosun | `claude-sonnet-4-6` | QA, testing |
| **SCR** — Scribe | `claude-sonnet-4-6` | Documentation |
| **LKT** — Lookout | `claude-haiku-4-5-20251001` | Fast investigation, scanning |

These defaults are tuned for the typical AU/NZ price-and-quality envelope. You can override at three layers, evaluated in order from highest to lowest priority:

1. **Per-order** — order JSON `model` field (one-off, for a hard order)
2. **Workspace config** — `.adm/config/role-models.json` (per-project, persistent)
3. **Env var** — `MAESTRO_MODEL_<ROLE>` (per-shell, fastest to test)
4. **Built-in default** — falls back to the table above

If none of the above is set, the built-in default is used.

## Inspecting the active configuration

```bash
adm config models
```

Prints a table showing the resolved model for each role and the source that decided it. The per-order layer can't be displayed in a static table (it depends on the order being dispatched), so this command shows the next three layers.

## Layer 1 — Per-order override

Add a `model` field to an order JSON. Highest priority — beats every other layer.

```json
{
  "orderId": "FTR-PSG-2026-0042",
  "type": "FTR",
  "role": "SHP",
  "title": "Refactor the auth flow",
  "model": "claude-opus-4-7"
}
```

Use this when one specific order needs a different model — e.g. a particularly thorny SHP refactor that benefits from Opus, while the rest of the fleet stays on Sonnet for cost.

## Layer 2 — Workspace config

Create `.adm/config/role-models.json` in your workspace:

```json
{
  "models": {
    "SHP": "claude-opus-4-7",
    "BOS": "claude-opus-4-7"
  }
}
```

Only the roles you list are overridden — everything else stays on the built-in default. Survives across shells, runs, and dispatcher restarts. Per-project: each project workspace can have its own.

## Layer 3 — Env var

```powershell
# PowerShell
$env:MAESTRO_MODEL_SHP = "claude-opus-4-7"
```

```bash
# bash / WSL
export MAESTRO_MODEL_SHP=claude-opus-4-7
```

Lives only in the shell that set it — useful for one-off testing or CI where you want different routing without touching files. Linux/macOS env vars are case-sensitive (must be uppercase `MAESTRO_MODEL_SHP`); Windows is case-insensitive at the OS level.

## Supported model IDs

```
claude-opus-4-7
claude-opus-4-6
claude-sonnet-4-6
claude-haiku-4-5-20251001
```

Maestro refuses to dispatch against a model ID it can't price (no `PRICING` entry in `maestro/core/fleet_usage_tracker.py`). Adding a new model means updating both `SUPPORTED_MODELS` and `PRICING` in the framework — file an FTR if you need one Maestro doesn't have.

## Cost trade-offs

Sonnet 4.6 is roughly **5× cheaper** than Opus 4.7 on input and output. Haiku 4.5 is another order of magnitude cheaper than Sonnet. The defaults already exploit this asymmetry — only COX runs Opus by default because integration review is the role most likely to catch costly mistakes downstream. Most workspaces never need to override.

If your operators are seeing budget pressure, the cheapest first move is to drop NAV from Sonnet to Haiku for non-critical projects. Plans are short and Haiku does well at outline-and-bullet work. Run `adm usage --voyage <ID>` after a voyage to see whether the change paid off.
