# Personas — Maestro

Maestro's persona system lets you change the vocabulary, tone, and character of the AI agents running in your workspace — without changing any underlying code or workflow mechanics. A persona is a lens over the same orchestration engine.

---

## Contents

1. [What a persona is](#what-a-persona-is)
2. [Why personas exist](#why-personas-exist)
3. [Built-in personas](#built-in-personas)
   - [Nautical (default)](#nautical-default)
   - [Corporate](#corporate)
   - [Startup](#startup)
   - [Default (minimal)](#default-minimal)
4. [Picking a persona](#picking-a-persona)
5. [Customising a persona](#customising-a-persona)
6. [Persona file format](#persona-file-format)
7. [Persona injection in CLI output](#persona-injection-in-cli-output)
8. [Persona injection in role prompts](#persona-injection-in-role-prompts)
9. [Examples](#examples)
10. [FAQ](#faq)

---

## What a persona is

A persona is a YAML or JSON file that defines:

- **Vocabulary mappings** — what to call each role, work unit, and structural concept
- **Tone descriptors** — how agents should address the human operator and each other
- **Greeting / sign-off templates** — opening and closing lines in agent output
- **CLAUDE.md layer content** — the Layer 1 and Layer 2 context injected into each session

The persona does **not** change:
- The role codes (PLN, BLD, TST, DOC, SEC, REL, LEAD)
- The order / sprint JSON schema
- The dispatcher mechanics
- Any Python source file

When the dispatcher launches a squad, it renders the role prompt through the active persona. CLI output headers, status messages, and handoff documents are also rendered through the persona. The result is a workspace that feels cohesive — from the terminal output to the agent's opening lines — without a single line of engine code changing.

---

## Why personas exist

Maestro v1.x and v2.x shipped exclusively with a nautical persona (Captains, Quartermasters, Fleets, Voyages). Many early adopters loved this character. Others — particularly in enterprise and regulated environments — found nautical terminology confusing to new team members or incongruent with company culture.

The persona system resolves this without forking the codebase. You can:

- Keep the nautical persona if your team enjoys it
- Switch to a corporate persona for a neutral, professional tone
- Adopt the startup persona for a fast-moving, informal style
- Write a fully custom persona that matches your company's engineering culture

The nautical persona is still the default. It has no functional advantage over any other persona — it is simply the heritage theme.

---

## Built-in personas

### Nautical (default)

File: `maestro/personas/nautical.yaml`

The heritage persona from the Maestro v2.x era. Uses seafaring vocabulary throughout.

| Canonical concept | Nautical term |
|------------------|--------------|
| Human (operator) | Captain |
| LEAD | Quartermaster |
| Dispatcher | Fleet Admiral |
| Squad | Crew |
| Sprint | Voyage |
| Order | Order |
| PLN role | Navigator |
| BLD role | Shipwright |
| TST role | Bosun |
| DOC role | Scribe |
| SEC role | Lookout |
| REL role | Coxswain |

**Tone:** Respectful, nautical, slightly formal. Agents address the human as "Captain" and sign off with sailing metaphors.

**Best for:** Teams that enjoy a distinct character in their tools; solo operators who want a memorable experience.

### Corporate

File: `maestro/personas/corporate.yaml`

Clean, neutral, professional. Minimal metaphor.

| Canonical concept | Corporate term |
|------------------|---------------|
| Human (operator) | Lead |
| LEAD | Assistant |
| Dispatcher | Scheduler |
| Squad | Agent |
| Sprint | Sprint |
| Order | Task |
| PLN role | Planner |
| BLD role | Developer |
| TST role | QA Engineer |
| DOC role | Technical Writer |
| SEC role | Security Analyst |
| REL role | Release Engineer |

**Tone:** Concise, professional, no metaphor. Suitable for regulated environments or organisations where tool vocabulary must match HR/PM conventions.

**Best for:** Enterprise teams, regulated industries, organisations with strict terminology standards.

### Startup

File: `maestro/personas/startup.yaml`

Fast-moving, informal, outcome-focused.

| Canonical concept | Startup term |
|------------------|-------------|
| Human (operator) | Founder |
| LEAD | Co-pilot |
| Dispatcher | Launcher |
| Squad | Bot |
| Sprint | Sprint |
| Order | Ticket |
| PLN role | Architect |
| BLD role | Engineer |
| TST role | QA |
| DOC role | Writer |
| SEC role | Security |
| REL role | DevOps |

**Tone:** Casual, direct, high-energy. Minimal ceremony, fast handoffs.

**Best for:** Small teams moving fast, indie developers, hackathon-style workflows.

### Default (minimal)

File: `maestro/personas/default.yaml`

Uses the canonical Maestro role names and no extra colour. Zero metaphor, zero character. Every term is exactly what the system calls it internally.

**Best for:** Operators who want maximum clarity and no decoration; scripted/CI environments where human-readable persona output is irrelevant.

---

## Picking a persona

Set the active persona in your workspace config:

```bash
# In .adm/config/workspace.json
{
  "persona": "nautical"
}
```

Or pass it on the command line (overrides workspace config for that invocation):

```bash
mso dispatch --persona corporate
mso status --persona default
```

Or set an environment variable:

```bash
export MAESTRO_PERSONA=startup
mso dispatch
```

Priority: CLI flag > environment variable > workspace config > default (nautical).

---

## Customising a persona

Copy any built-in persona as a starting point:

```bash
cp maestro/personas/nautical.yaml .adm/config/personas/my-team.yaml
```

Edit the copy to taste. Then reference it in your workspace config:

```json
{
  "persona": ".adm/config/personas/my-team.yaml"
}
```

If the value is a relative path, it is resolved from the workspace root. If it is a bare name (e.g. `nautical`), Maestro looks for it in `maestro/personas/{name}.yaml`.

---

## Persona file format

Personas are YAML files. All fields are optional — omitted fields fall back to the `default` persona.

```yaml
# .adm/config/personas/my-team.yaml

meta:
  name: My Team
  description: Custom persona for the Acme engineering team

vocabulary:
  human: "Tech Lead"           # How the human operator is addressed
  lead: "AI Partner"           # The interactive LEAD role
  dispatcher: "Orchestrator"   # The mso dispatch process
  squad: "Worker"              # An autonomous agent
  sprint: "Sprint"             # A group of related orders
  order: "Ticket"              # A single unit of work

roles:
  PLN:
    name: "Architect"
    pronoun: "The Architect"
  BLD:
    name: "Engineer"
    pronoun: "The Engineer"
  TST:
    name: "QA"
    pronoun: "The QA"
  DOC:
    name: "Writer"
    pronoun: "The Writer"
  SEC:
    name: "Security"
    pronoun: "Security"
  REL:
    name: "DevOps"
    pronoun: "DevOps"
  LEAD:
    name: "AI Partner"
    pronoun: "Your AI Partner"

tone:
  formality: "professional"    # casual | professional | formal
  greeting: "Hello, {human}."
  signoff: "Ready when you are."

claude_md:
  # Optional: extra lines to inject into CLAUDE.md Layer 1 persona section
  # Jinja2 template; receives all vocabulary and role definitions as context
  layer1_extra: |
    Address the {{ vocabulary.human }} by name where known.
    Use plain English; avoid jargon and metaphor.
```

### Field reference

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `meta.name` | string | persona filename | Display name |
| `meta.description` | string | — | Short description |
| `vocabulary.human` | string | `"Operator"` | How to address the human |
| `vocabulary.lead` | string | `"Lead"` | Name of the interactive role |
| `vocabulary.dispatcher` | string | `"Dispatcher"` | Name of `mso dispatch` |
| `vocabulary.squad` | string | `"Squad"` | Name of an autonomous agent |
| `vocabulary.sprint` | string | `"Sprint"` | Name of a work group |
| `vocabulary.order` | string | `"Order"` | Name of a single task |
| `roles.{CODE}.name` | string | role code | Display name for that role |
| `roles.{CODE}.pronoun` | string | `"The {name}"` | How the role refers to itself |
| `tone.formality` | enum | `"professional"` | One of: `casual`, `professional`, `formal` |
| `tone.greeting` | Jinja2 string | — | Opening line template |
| `tone.signoff` | Jinja2 string | — | Closing line template |
| `claude_md.layer1_extra` | Jinja2 string | — | Extra content appended to CLAUDE.md Layer 1 persona section |

---

## Persona injection in CLI output

When `MAESTRO_PERSONA` is active, CLI status messages, dispatch logs, and handoff headers render through the persona vocabulary. Examples:

**Default (minimal):**
```
[Maestro] Dispatching 3 squads for sprint VOY-MSO-2026-0001
[Maestro] BLD — order FTR-MSO-2026-0042 — in progress
[Maestro] TST — order FTR-MSO-2026-0042 — complete
```

**Nautical persona:**
```
[Maestro] Setting sail — 3 crews assigned to voyage VOY-MSO-2026-0001
[Maestro] Shipwright — order FTR-MSO-2026-0042 — underway
[Maestro] Bosun — order FTR-MSO-2026-0042 — complete
```

**Corporate persona:**
```
[Maestro] Scheduling 3 agents for sprint VOY-MSO-2026-0001
[Maestro] Developer — task FTR-MSO-2026-0042 — in progress
[Maestro] QA Engineer — task FTR-MSO-2026-0042 — complete
```

The order/sprint IDs are not renamed — they always use the canonical `VOY-` / `FTR-` prefixes regardless of persona vocabulary. This keeps artefact references stable across persona switches.

---

## Persona injection in role prompts

Each squad receives a system prompt that begins with a persona-rendered preamble. For the nautical persona this reads:

> You are the **Shipwright** on this project — responsible for development and implementation. The Captain has assigned you an order; your work is to execute it faithfully and report back.

For the corporate persona, the same PLN squad reads:

> You are the **Developer** on this project — responsible for development and implementation. The Lead has assigned you a task; your work is to execute it faithfully and report back.

The role instructions (what files to read, what to write, quality gates) are identical. Only the framing changes.

---

## Examples

### Switch to corporate persona for a client project

```bash
# In the client project's .adm/config/workspace.json
{
  "persona": "corporate",
  "maxCrews": 3
}
```

All output in that workspace uses corporate vocabulary. Other workspaces are unaffected.

### Try a persona without changing config

```bash
mso status --persona startup
mso dispatch --persona startup --max-crews 2
```

### Create a minimal custom persona for CI

```yaml
# .adm/config/personas/ci.yaml
meta:
  name: CI
  description: Silent, machine-readable persona for CI pipelines

vocabulary:
  human: "operator"
  lead: "lead"
  squad: "agent"
  sprint: "sprint"
  order: "order"

tone:
  formality: "formal"
  greeting: ""
  signoff: ""
```

```bash
export MAESTRO_PERSONA=.adm/config/personas/ci.yaml
mso dispatch --max-crews 5
```

---

## FAQ

**Q: Does switching persona break any existing artefacts (orders, voyages, plans)?**
A: No. Artefact IDs and JSON schemas are persona-independent. Switching persona only changes how the system talks to you, not what it stores.

**Q: Can I have different personas per role?**
A: Not in the current implementation. The active persona applies to all roles. Per-role persona overrides are on the roadmap.

**Q: Does the persona affect model selection or quality gates?**
A: No. Model assignments (PLN=Sonnet 4.6, SEC=Haiku 4.5, REL=Opus 4.7) and gate logic are persona-independent.

**Q: Can I share a custom persona across projects?**
A: Yes. Put the YAML file in a shared location (e.g. `~/.maestro/personas/acme.yaml`) and reference it by absolute path in `workspace.json`.

**Q: The nautical persona says "Captain" — is this the human or an AI role?**
A: "Captain" is always the human operator. The AI interactive role is "Quartermaster" in the nautical persona. See the vocabulary table in the [Nautical](#nautical-default) section above.

**Q: I want to keep nautical terms for roles but use "Sprint" instead of "Voyage".**
A: Create a custom persona that inherits nautical role names but sets `vocabulary.sprint: "Sprint"`. See the [Persona file format](#persona-file-format) section.
