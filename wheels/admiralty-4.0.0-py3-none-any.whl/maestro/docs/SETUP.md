# Maestro — `adm setup` deeper wizard

> The heavier configurator behind `adm quickstart`. Run `adm quickstart` for the friendly first-run; run `adm setup` when you want deeper control — prerequisite validation across 6 checks, fingerprint-based project analysis, 8 built-in requirement templates, contextual next-steps cheatsheet, and a non-interactive `--check` mode for CI.

## When to use `adm quickstart` vs `adm setup`

| | `adm quickstart` | `adm setup` |
|---|---|---|
| **Audience** | First-time operator on a new machine | Anyone with an existing workspace |
| **Mode** | Demo voyage + dispatch | Audit + configure + analyse |
| **Touches** | Creates demo voyage + orders | Reads/repairs `.adm/config/workspace.json` |
| **CI-friendly** | No | Yes — `adm setup --check` exits 0/1/2/3 |

If you ran `adm quickstart` once already, run `adm setup` next.

## Five modes

| Command | Purpose |
|---------|---------|
| `adm setup` | Interactive wizard — step-through prompts; configures `.adm/config/workspace.json` |
| `adm setup --check` | Non-interactive audit — exit 0/1/2/3, no prompts |
| `adm setup --check --json` | Machine-readable JSON output for CI parsing |
| `adm setup --repair` | Auto-fix repairable conditions (workspace.json regen, git init, etc.) |
| `adm setup --show <section>` | Read-only view of one section (`prereqs`, `project`, `workspace`, `templates`) |

## 6 prerequisite validators

| # | Validator | What it checks | OK → | WARN → | FAIL → |
|---|-----------|---------------|------|--------|--------|
| 1 | `check_python_version` | `sys.version_info >= (3, 9)` | Python 3.9+ | — | < 3.9 |
| 2 | `check_claude_cli` | `claude --version` responds | found + responsive | found but slow | not found / errored |
| 3 | `check_git` | `git --version` + cwd is a repo | installed + repo | installed, no repo | not installed |
| 4 | `check_gh_cli` | `gh auth status` ok | authenticated | not authenticated | not installed |
| 5 | `check_anthropic_auth` | `ANTHROPIC_API_KEY` env OR `claude` responsive | set / subscription | placeholder-looking | neither |
| 6 | `check_workspace_scaffold` | `.adm/` + valid `workspace.json` | scaffolded + valid | exists but malformed | not scaffolded |

All validators have a 10-second timeout to avoid hanging the wizard on broken tools.

### Repairable conditions

`adm setup --repair` will automatically fix:
- `.adm/config/workspace.json` missing or invalid → regenerate from defaults
- `.adm/` directory partially scaffolded → fill in missing dirs

Non-repairable (`--repair` prints remediation only):
- Python < 3.9 — requires system intervention
- Claude Code / Git / `gh` not installed — requires installer
- `ANTHROPIC_API_KEY` env var unset — must be set in parent shell

## Project analysis matrix

`adm setup` runs `maestro/project_analysis.py:analyze()` against the current directory. **Fingerprint-only — no recursive scan** — completes in <100ms even on large repos.

| Detector | Signals |
|----------|---------|
| **Language** | `pyproject.toml`/`setup.py`/`requirements.txt` → Python; `tsconfig.json`/`package.json`+TS → TypeScript; `go.mod` → Go; `Cargo.toml` → Rust; `*.csproj`/`*.sln` → C#; `pom.xml`/`build.gradle` → Java |
| **Framework** | `next.config.*` → Next.js; `manage.py` → Django; `fastapi` in deps → FastAPI; `flask` in deps → Flask; `Microsoft.AspNetCore` in `*.csproj` → ASP.NET |
| **Source root** | `src/` > `lib/` > `app/` > `packages/` > `.` (flat) |
| **Test layout** | `tests/`, `test/`, `__tests__/`, `*.test.*`, `*_test.go`, `spec/` |
| **Docs** | `README.md`, `docs/`, `mkdocs.yml`, `docusaurus.config.js`, `_docs/` |
| **Git history** | recent commit timestamp, branch count, CI presence (`.github/workflows/`, `.gitlab-ci.yml`, `Jenkinsfile`, `.circleci/`) |

Result is a `ProjectAnalysis` dataclass with `primary_language`, `secondary_languages`, `framework`, `source_root`, `test_layouts`, `has_readme`, `has_docs_dir`, `has_ci`, `ci_systems`, `recent_activity`, `branch_model`.

## 8 built-in requirement templates

Each template is a Jinja2 markdown file at `maestro/templates/requirements/*.md.j2`. Rendered output is a starter order JSON that operators can dispatch.

| Template | Purpose | Key sections |
|----------|---------|--------------|
| `new-feature` | Propose a new feature | Goal, User story, Acceptance criteria, Out of scope |
| `project-setup` | Initial project configuration | Stack, CI target, Branching strategy, Deployment target |
| `security-review` | Security audit | Threat model, OWASP concerns, Sensitive files, Auth mechanisms |
| `test-coverage` | Test gap analysis | Current coverage, Target %, Untested paths, Test strategy |
| `doc-audit` | Documentation review | Existing docs, Gaps, Target audience, Format |
| `bug-report` | Bug reproduction + fix | Steps to reproduce, Expected vs actual, Environment, Logs |
| `performance` | Performance investigation | Observed latency, Profiling baseline, Hotspot hypothesis, Target |
| `refactor` | Refactoring scope | Current pain points, Target structure, Risk surface, Rollback plan |

Variables injected at render time: `{{ project }}`, `{{ language }}`, `{{ framework }}`, `{{ source_root }}`, `{{ date }}`.

### Custom templates

Drop `.md.j2` files in `.adm/templates/requirements/` to extend the catalogue. Custom templates override built-ins with the same filename. List all available with:

```bash
adm setup --show templates
```

## Contextual cheatsheet (`adm setup` step 5)

After analysis + workspace config, `adm setup` runs `maestro/setup_cheatsheet.py:generate_cheatsheet()` and prints contextual next-steps. Rules include:

- No test layout → suggest `test-coverage` template
- No README + no docs/ → suggest `doc-audit` template
- No CI workflow → suggest scaffolding `.github/workflows/`
- Dormant repo (>180 days quiet) → suggest `project-setup` template
- `gh` not authenticated → walk through `gh auth login`
- Missing `ANTHROPIC_API_KEY` → environment-variable instructions
- Next.js detected → suggest `performance` template if you have measured slowness
- FastAPI detected → suggest `security-review` template early
- Django detected → confirm `manage.py check` + `migrate` in CI

10+ rules total. Heuristic, not exhaustive — treat suggestions as starting points.

## `--check` mode for CI/CD

Designed to be pipeline-friendly:

```bash
adm setup --check || exit 1
```

### Exit codes

| Code | Meaning |
|------|---------|
| 0 | All prereqs OK |
| 1 | Any FAIL |
| 2 | Only WARNs |
| 3 | Internal error (reserved) |

### JSON output

```bash
adm setup --check --json
```

Returns a stable JSON schema:

```json
{
  "prereqs": [
    {"name": "python_version", "status": "OK", "message": "Python 3.11 OK", "remediation": ""},
    {"name": "gh_cli", "status": "WARN", "message": "`gh` installed but not authenticated", "remediation": "Run `gh auth login`."}
  ],
  "exit_code": 2
}
```

### Sample GitHub Actions step

```yaml
- name: Validate Maestro setup
  run: |
    pip install maestro --extra-index-url https://maestrodevs.github.io/simple/
    adm setup --check
```

## Operator workflow — typical day

```bash
# Day-1 onboarding to an existing repo
cd <repo>
adm setup                            # interactive wizard runs through all 5 steps

# After config drifts (e.g. workspace.json hand-edited)
adm setup --check                    # quick audit
adm setup --repair                   # auto-fix anything fixable

# Generating starter orders from templates
adm setup                            # prompts you through template selection in step 4

# CI integration
adm setup --check --json | jq .      # parse status programmatically
```

## Migration note — FTR-ADM-2026-0009

The original `FTR-ADM-2026-0009` roadmap order (Apr 2026) called for both `adm quickstart` AND `adm setup`. **`adm quickstart` shipped in VOY-ADM-2026-0028** (delivered the friendly first-run slice). **VOY-ADM-2026-0035 (this voyage) delivers the deeper `adm setup` wizard** — the remaining scope of FTR-0009. Treat VOY-0035 as the authoritative delivery of FTR-0009.
