"""Centralised role-model and squad-name constants for the Maestro engine.

Replaces the triplicated CREW_NAMES / ROLE_MODELS dicts that previously lived
in admiralty/core/{fleet_monitor,crew,fleet_runner}.py (FTR-MSO-2026-0168).
"""

from __future__ import annotations

from typing import Optional

# Canonical role → short model label used in dashboards and lifecycle logs.
# Legacy role codes (NAV/SHP/BOS/SCR/LKT/COX/QM) resolve via
# admiralty.core.fleet_runner.resolve_role_code before lookup here.
DEFAULT_ROLE_MODELS: dict[str, str] = {
    "PLN":  "Sonnet",   # was NAV
    "BLD":  "Sonnet",   # was SHP
    "TST":  "Sonnet",   # was BOS
    "DOC":  "Sonnet",   # was SCR
    "SEC":  "Haiku",    # was LKT
    "REL":  "Opus",     # was COX
    "LEAD": "Opus",
}

# Canonical role → full Claude model ID used when dispatching crews.
# Mirrors DEFAULT_ROLE_MODELS but contains the actual API model strings.
DEFAULT_ROLE_MODEL_IDS: dict[str, str] = {
    "PLN":  "claude-sonnet-4-6",
    "BLD":  "claude-sonnet-4-6",
    "TST":  "claude-sonnet-4-6",
    "DOC":  "claude-sonnet-4-6",
    "SEC":  "claude-haiku-4-5-20251001",
    "REL":  "claude-opus-4-7",
    "LEAD": "claude-opus-4-7",
}

_DEFAULT_MODEL_LABEL = "Sonnet"
_DEFAULT_MODEL_ID = "claude-sonnet-4-6"


def _resolve(role: str) -> str:
    """Resolve legacy nautical role code to canonical without importing fleet_runner at module level."""
    try:
        from maestro.core.fleet_runner import resolve_role_code  # noqa: PLC0415
        return resolve_role_code(role)
    except Exception:
        return role


def get_role_model(role: str) -> str:
    """Return the short model label (Opus/Sonnet/Haiku) for a role code.

    Accepts both canonical (PLN/BLD/…) and legacy (NAV/SHP/…) codes.
    """
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_MODELS.get(canonical, _DEFAULT_MODEL_LABEL)


def get_role_model_id(role: str) -> str:
    """Return the full Claude model ID for a role code (used when dispatching crews)."""
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_MODEL_IDS.get(canonical, _DEFAULT_MODEL_ID)


def get_squad_name(slot: int) -> str:
    """Return the persona-specific display name for crew slot *slot* (1-indexed).

    Falls back to 'Squad <slot>' if the slot is out of range or persona unavailable.
    """
    try:
        from maestro.personas import current_persona  # noqa: PLC0415
        names = current_persona().squad_names()
        if 1 <= slot <= len(names):
            return names[slot - 1]
    except Exception:
        pass
    return f"Squad {slot}"
