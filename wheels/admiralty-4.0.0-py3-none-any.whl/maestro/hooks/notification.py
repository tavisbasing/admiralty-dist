#!/usr/bin/env python3
"""
Fleet Notification Hook v8.1 — Error and Warning Capture.

Logs Claude's internal notifications (API errors, permission prompts, etc.)
to a per-crew notifications.log file for debugging and audit.

IMPORTANT: This hook ONLY activates for crew sessions (MAESTRO_CREW env set).
The Captain's interactive sessions are NEVER affected.

Input:  JSON on stdin (from Claude Code hook system)
Output: Exit 0 always (observation-only, never blocks)
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path


def main():
    try:
        raw_input = sys.stdin.read()
        hook_input = json.loads(raw_input) if raw_input.strip() else {}
    except Exception:
        sys.exit(0)

    # Only for crew sessions
    crew_str = os.environ.get("MAESTRO_CREW")
    if not crew_str:
        sys.exit(0)

    try:
        crew_number = int(crew_str)
    except ValueError:
        sys.exit(0)

    # Extract notification details
    message = hook_input.get("message", "")
    title = hook_input.get("title", "")
    notification_type = hook_input.get("notification_type", "info")

    if not message and not title:
        sys.exit(0)  # Nothing to log

    # Write to crew notifications log
    cwd = hook_input.get("cwd", os.getcwd())
    from maestro.hooks import find_admiralty_root
    workspace = find_admiralty_root(cwd)
    if workspace is None:
        sys.exit(0)  # Not an Admiralty workspace — no-op
    adm_root = workspace / ".adm" if (workspace / ".adm").is_dir() else workspace / ".admiralty"
    crew_dir = adm_root / "crews" / f"crew{crew_number}"
    crew_dir.mkdir(parents=True, exist_ok=True)

    log_file = crew_dir / "notifications.log"
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    title_part = f" {title}:" if title else ""
    entry = f"[{timestamp}] [{notification_type.upper()}]{title_part} {message}\n"

    try:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(entry)
    except Exception:
        pass

    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        sys.exit(0)
