"""
Admiralty backup & restore — project state archiving.

Provides backup(), restore(), and list_backups() for creating and extracting
versioned ZIP archives of .admiralty project state.
"""

from __future__ import annotations

import json
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional


BACKUP_INCLUDES = [
    "orders/active",
    "orders/complete",
    "orders/failed",
    "voyages/active",
    "voyages/complete",
    "prompts/active",
    "plans",
    "handoffs",
    "requirements",
    "reports",
    "usage/orders",
    "config",
]

BACKUP_EXCLUDES = {
    "core", "hooks", "crews", "logs", "temp", "queues",
}

_ROOT_FILES = [
    "CLAUDE.md",
    ".adm/BACKLOG.md",
    ".adm/VOYAGE-STATUS.md",
    ".adm/config/workspace.json",
    ".adm/config/projects.json",
]


def _matches_project(filename: str, project: str) -> bool:
    """Return True if filename belongs to the given project."""
    tag = project.upper()
    return f"-{tag}-" in filename or filename.startswith(f"{tag}.")


def backup(
    workspace: Path,
    project: Optional[str] = None,
    output_dir: Optional[Path] = None,
) -> Path:
    """
    Create a versioned ZIP archive of project state files.

    Args:
        workspace:  Workspace root (directory containing .adm/).
        project:    If set, only include files for this project acronym.
        output_dir: Directory to write the ZIP to (default: workspace/admiralty-backups/).

    Returns:
        Path to the created ZIP archive.
    """
    from maestro import __version__ as admiralty_version

    if output_dir is None:
        output_dir = workspace / "admiralty-backups"
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
    tag = project.upper() if project else "all"
    zip_name = f"admiralty-backup-{tag}-{timestamp}.zip"
    zip_path = output_dir / zip_name

    collected: list[tuple[Path, str]] = []  # (absolute_path, archive_name)

    admiralty_dir = workspace / ".adm" if (workspace / ".adm").is_dir() else workspace / ".admiralty"
    for rel in BACKUP_INCLUDES:
        target_dir = admiralty_dir / rel
        if not target_dir.exists():
            continue
        for file_path in sorted(target_dir.rglob("*")):
            if not file_path.is_file():
                continue
            if project and not _matches_project(file_path.name, project):
                continue
            archive_name = str(file_path.relative_to(workspace)).replace("\\", "/")
            collected.append((file_path, archive_name))

    # Also glob per-project config files
    projects_config_dir = admiralty_dir / "config" / "projects"
    if projects_config_dir.exists():
        for file_path in sorted(projects_config_dir.glob("*.json")):
            if not file_path.is_file():
                continue
            archive_name = str(file_path.relative_to(workspace)).replace("\\", "/")
            # Avoid duplicates (config/ is already in BACKUP_INCLUDES)
            if not any(arc == archive_name for _, arc in collected):
                if not project or _matches_project(file_path.name, project):
                    collected.append((file_path, archive_name))

    # Root files — always included regardless of project filter
    for rel_str in _ROOT_FILES:
        file_path = workspace / rel_str
        if file_path.exists() and file_path.is_file():
            archive_name = rel_str.replace("\\", "/")
            if not any(arc == archive_name for _, arc in collected):
                collected.append((file_path, archive_name))

    manifest = {
        "version": 1,
        "created_at": datetime.now().isoformat(),
        "workspace": str(workspace),
        "projects_included": [project.upper()] if project else ["ALL"],
        "admiralty_version": admiralty_version,
        "file_count": len(collected),
    }

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))
        for abs_path, arc_name in collected:
            zf.write(abs_path, arc_name)

    return zip_path


def restore(
    backup_file: Path,
    workspace: Path,
    project: Optional[str] = None,
    force: bool = False,
    merge: bool = False,
    dry_run: bool = False,
) -> None:
    """
    Extract files from a backup ZIP with conflict resolution.

    Conflict resolution (default = skip existing):
        --force  Overwrite all existing files.
        --merge  Keep whichever file is newer by mtime.
        --dry-run  Print actions without writing anything.

    Args:
        backup_file: Path to the ZIP archive.
        workspace:   Workspace root to restore into.
        project:     If set, only restore files for this project acronym.
        force:       Overwrite existing files.
        merge:       Keep newer file by mtime.
        dry_run:     Print actions only; no writes.
    """
    if not backup_file.exists():
        raise SystemExit(f"[Admiralty] Backup file not found: {backup_file}")

    with zipfile.ZipFile(backup_file, "r") as zf:
        names = zf.namelist()
        if "manifest.json" not in names:
            raise SystemExit(
                f"[Admiralty] Invalid backup — manifest.json missing in {backup_file}"
            )

        extracted = skipped = overwritten = 0

        for zi in zf.infolist():
            if zi.filename == "manifest.json":
                continue
            if project and not _matches_project(Path(zi.filename).name, project):
                continue

            dest = workspace / zi.filename
            if dest.exists():
                if force:
                    action = "OVERWRITE"
                elif merge:
                    # Compare mtimes
                    arc_mtime = datetime(*zi.date_time).timestamp()
                    dest_mtime = dest.stat().st_mtime
                    if dest_mtime >= arc_mtime:
                        action = "KEEP-EXISTING"
                    else:
                        action = "EXTRACT"
                else:
                    action = "SKIP"
            else:
                action = "EXTRACT"

            print(f"  [{action}] {zi.filename}")

            if dry_run:
                if action in ("EXTRACT", "OVERWRITE"):
                    extracted += 1
                elif action == "KEEP-EXISTING":
                    skipped += 1
                else:
                    skipped += 1
                continue

            if action in ("EXTRACT", "OVERWRITE"):
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(zi.filename))
                if action == "OVERWRITE":
                    overwritten += 1
                else:
                    extracted += 1
            else:
                skipped += 1

    prefix = "[DRY RUN] " if dry_run else ""
    print(
        f"\n{prefix}[Admiralty] Restore complete — "
        f"extracted: {extracted}, overwritten: {overwritten}, skipped: {skipped}"
    )


def list_backups(backup_dir: Path) -> list[dict]:
    """
    Return metadata for all backup ZIPs in backup_dir.

    Each dict contains manifest fields plus a 'file' key (Path).
    Sorted by created_at descending. ZIPs without a valid manifest
    are returned with just {'file': ..., 'error': '...'}.
    """
    if not backup_dir.exists():
        return []

    results: list[dict] = []
    for zip_path in sorted(backup_dir.glob("*.zip")):
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                if "manifest.json" not in zf.namelist():
                    raise ValueError("no manifest.json")
                manifest = json.loads(zf.read("manifest.json"))
            manifest["file"] = zip_path
            results.append(manifest)
        except Exception as exc:
            results.append({"file": zip_path, "error": str(exc)})

    results.sort(
        key=lambda d: d.get("created_at", ""),
        reverse=True,
    )
    return results
