"""Polar.sh API client for licence-key validation.

Single integration point — the CLI talks to api.polar.sh directly, no
Admiralty-operated webhook service in between. Polar handles
subscription billing, key issuance, and key state (granted / revoked /
expired); we read state via these endpoints and never push it.

Uses urllib (stdlib only — no httpx dependency on the CLI hot path).

Polar's licence-key validate endpoint:
    POST {base}/customers/{customer_id}/license-keys/{key}/validate

We don't know `customer_id` at activate-time (the user only types the
key), so the first call hits the lookup endpoint:
    GET  {base}/license-keys/lookup?key={key}
which returns the customer_id and a per-customer signing secret. From
then on we have the customer_id stored locally.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Optional

from maestro.licence.config import (
    POLAR_API_BASE,
    product_id_to_tier,
)


DEFAULT_API_BASE = POLAR_API_BASE


class PolarError(Exception):
    """Polar API failure.

    Attributes:
        status: HTTP status code (or 0 for network errors).
        reason: human-readable reason from Polar's error body, if any.
        polar_status: Polar's domain status value when available — e.g.
            "granted", "revoked", "expired", "subscription_canceled". The
            licence layer maps this to specific exceptions deterministically
            (LicenceRevoked vs LicenceExpired) without string-matching reason.
    """

    # Polar's status values that indicate the customer's subscription was
    # ended/refunded. We map these to LicenceRevoked. Everything else
    # non-granted maps to LicenceExpired.
    REVOKED_STATUSES = frozenset({
        "revoked", "subscription_canceled", "subscription_cancelled",
        "payment_refunded", "subscription_refunded",
    })

    def __init__(self, status: int, reason: str = "", polar_status: str = "") -> None:
        self.status = status
        self.reason = reason
        self.polar_status = polar_status
        super().__init__(f"Polar error {status}: {reason}" if reason else f"Polar error {status}")

    def is_revoked(self) -> bool:
        """True if Polar's domain status indicates revocation (vs expiry)."""
        return self.polar_status in self.REVOKED_STATUSES


class PolarClient:
    """Sync Polar API client. Re-instantiate per call; not pooled."""

    def __init__(self, api_base: Optional[str] = None) -> None:
        self.api_base = (api_base or os.environ.get("MAESTRO_LICENCE_API_BASE") or DEFAULT_API_BASE).rstrip("/")

    def validate(self, licence_key: str) -> dict:
        """Validate `licence_key` against Polar.

        On first activation we don't yet know customer_id, so we call
        the lookup endpoint to discover it; subsequent calls go straight
        to the per-customer validate endpoint.

        Returns a dict with: tier, product_id, customer_id, issued_at,
        expires_at, signing_secret. Raises PolarError on any non-2xx.
        """
        info = self._lookup(licence_key)
        return self._validate_for_customer(info["customer_id"], licence_key, info)

    # ------------------------------------------------------------------
    # Internal HTTP
    # ------------------------------------------------------------------

    def _lookup(self, licence_key: str) -> dict:
        url = f"{self.api_base}/license-keys/lookup?key={licence_key}"
        return self._get(url)

    def _validate_for_customer(self, customer_id: str, licence_key: str, info: dict) -> dict:
        url = f"{self.api_base}/customers/{customer_id}/license-keys/{licence_key}/validate"
        result = self._post(url, body={})
        # Map Polar's response shape onto our internal contract.
        status = result.get("status", "")
        if status != "granted":
            reason = result.get("reason", status or "unknown")
            raise PolarError(403, reason, polar_status=status)
        # Resolve tier from the product_id when Polar doesn't include it
        # in the response. Falls back to "pro" for unknown product IDs
        # (rather than the empty string, so cmd_licence's status print
        # always has a tier to show).
        # Use `or` chains rather than dict.get's default — Polar can
        # legitimately return `null` for product_id, and the default
        # only kicks in when the key is absent, not when the value
        # is None. Force-coerce to str so downstream consumers (signing
        # payload, dataclass field) get a guaranteed string.
        product_id = (result.get("product_id") or info.get("product_id") or "")
        tier = (
            info.get("tier")
            or result.get("tier")
            or product_id_to_tier(product_id)
            or "pro"
        )
        return {
            "customer_id": customer_id,
            "tier": tier,
            "product_id": product_id,
            "issued_at": info.get("issued_at") or result.get("issued_at", ""),
            "expires_at": result.get("expires_at", info.get("expires_at", "")),
            "signing_secret": info.get("signing_secret") or result.get("signing_secret", ""),
        }

    def _get(self, url: str) -> dict:
        req = urllib.request.Request(url, method="GET", headers={"Accept": "application/json"})
        return self._send(req)

    def _post(self, url: str, body: dict) -> dict:
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            method="POST",
            headers={"Accept": "application/json", "Content-Type": "application/json"},
        )
        return self._send(req)

    def _send(self, req: urllib.request.Request) -> dict:
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            polar_status = ""
            try:
                payload = json.loads(exc.read().decode("utf-8"))
                reason = payload.get("error") or payload.get("detail") or payload.get("message") or ""
                polar_status = payload.get("status", "") or payload.get("license_status", "")
            except Exception:
                reason = exc.reason or ""
            raise PolarError(exc.code, str(reason), polar_status=str(polar_status)) from exc
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            raise PolarError(0, str(exc)) from exc
