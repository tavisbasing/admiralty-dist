# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Admiralty Bridge — Mobile Command Bridge module.

Provides CLI-facing functions for managing the bridge components:
- Poller daemon (inbound commands from GitHub Gist)
- Slack bot (interactive commands from Slack)
- Notifier (outbound notifications to Slack)
- Bridge status and test utilities
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from maestro.launch.sandbox import spawn as _spawn
import sys
from pathlib import Path
from typing import Dict, Optional


def _resolve_bridge_script(workspace: Path, script: str) -> Path:
    """Resolve a bridge core script path (pip package or workspace-local)."""
    # 1. Workspace-local (dev/submodule)
    local = workspace / "admiralty" / "core" / script
    if local.exists():
        return local
    # 2. Pip-installed package
    try:
        import importlib.resources as pkg_resources
        import contextlib
        ref = pkg_resources.files("admiralty") / "core" / script
        with contextlib.suppress(Exception):
            p = Path(str(ref))
            if p.exists():
                return p
    except Exception:
        pass
    raise SystemExit(f"[Bridge] Script not found: {script}. Ensure admiralty pip package is installed.")


def _get_workspace_subdir(workspace: Path) -> Path:
    adm = workspace / ".adm"
    if adm.exists():
        return adm
    legacy = workspace / ".admiralty"
    if legacy.exists():
        import sys as _sys
        print(
            "[Admiralty] WARNING: Found legacy .admiralty/ directory. "
            "Migrate with: adm init --project <PRJ>",
            file=_sys.stderr,
        )
        return legacy
    return adm


def _is_process_alive(pid: int) -> bool:
    """Check if a process is running (Windows ctypes compatible)."""
    if not pid or pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def _read_pid(pid_file: Path) -> Optional[int]:
    """Read a PID from a file, return None if invalid."""
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return None


# ---------------------------------------------------------------------------
# Poller management
# ---------------------------------------------------------------------------

def start_poller(workspace: Path) -> None:
    """Start the bridge poller daemon in the background."""
    admiralty_dir = _get_workspace_subdir(workspace)
    pid_file = admiralty_dir / "bridge" / "poller.pid"

    # Check if already running
    existing_pid = _read_pid(pid_file)
    if existing_pid and _is_process_alive(existing_pid):
        print(f"[Bridge] Poller already running (PID: {existing_pid})")
        return

    script = _resolve_bridge_script(workspace, "bridge_poller.py")
    cmd = [sys.executable, str(script), "--admiralty-dir", str(admiralty_dir)]

    # Launch as detached background process
    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        proc = _spawn(
            cmd,
            identity="bridge_poller",
            workspace=workspace,
            cwd=workspace,
            creationflags=flags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        proc = _spawn(
            cmd,
            identity="bridge_poller",
            workspace=workspace,
            cwd=workspace,
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    print(f"[Bridge] Poller started (PID: {proc.pid})")


def stop_poller(workspace: Path) -> None:
    """Stop the bridge poller daemon by removing its PID file.

    The poller checks for PID file existence each cycle and exits cleanly
    when it's removed — no force-kill needed.
    """
    pid_file = _get_workspace_subdir(workspace) / "bridge" / "poller.pid"
    pid = _read_pid(pid_file)

    if not pid or not _is_process_alive(pid):
        print("[Bridge] Poller is not running")
        if pid_file.exists():
            pid_file.unlink()
        return

    # Remove PID file — poller detects this and exits cleanly after current cycle
    pid_file.unlink()
    print(f"[Bridge] Stop signal sent to poller (PID: {pid}). Will exit after current poll cycle.")


# ---------------------------------------------------------------------------
# Slack bot management
# ---------------------------------------------------------------------------

def start_bot(workspace: Path) -> None:
    """Start the Slack bridge bot in the background."""
    admiralty_dir = _get_workspace_subdir(workspace)
    pid_file = admiralty_dir / "bridge" / "slack-bot.pid"

    existing_pid = _read_pid(pid_file)
    if existing_pid and _is_process_alive(existing_pid):
        print(f"[Bridge] Slack bot already running (PID: {existing_pid})")
        return

    script = _resolve_bridge_script(workspace, "bridge_slack_bot.py")
    cmd = [sys.executable, str(script), "--admiralty-dir", str(admiralty_dir)]

    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        proc = _spawn(
            cmd,
            identity="bridge_slack_bot",
            workspace=workspace,
            cwd=workspace,
            creationflags=flags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        proc = _spawn(
            cmd,
            identity="bridge_slack_bot",
            workspace=workspace,
            cwd=workspace,
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    print(f"[Bridge] Slack bot started (PID: {proc.pid})")


def stop_bot(workspace: Path) -> None:
    """Stop the Slack bridge bot gracefully.

    Sends SIGTERM (or taskkill without /F on Windows) to allow the bot
    to close its WebSocket connection and clean up.
    """
    pid_file = _get_workspace_subdir(workspace) / "bridge" / "slack-bot.pid"
    pid = _read_pid(pid_file)

    if not pid or not _is_process_alive(pid):
        print("[Bridge] Slack bot is not running")
        if pid_file.exists():
            pid_file.unlink()
        return

    try:
        if os.name == "nt":
            # Use GenerateConsoleCtrlEvent or taskkill (without /F for graceful)
            subprocess.run(["taskkill", "/PID", str(pid)],
                           capture_output=True, timeout=10)
        else:
            os.kill(pid, 15)  # SIGTERM
        print(f"[Bridge] Stop signal sent to Slack bot (PID: {pid})")
    except Exception as e:
        print(f"[Bridge] Failed to stop Slack bot: {e}")

    # Give it a moment to clean up, then remove stale PID if still present
    import time
    time.sleep(2)
    if pid_file.exists() and not _is_process_alive(pid):
        pid_file.unlink()


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------

def bridge_status(workspace: Path) -> Dict:
    """Get the status of all bridge components."""
    admiralty_dir = _get_workspace_subdir(workspace)
    bridge_dir = admiralty_dir / "bridge"

    # Poller status
    poller_pid_file = bridge_dir / "poller.pid"
    poller_pid = _read_pid(poller_pid_file)
    poller_alive = bool(poller_pid and _is_process_alive(poller_pid))

    # Bot status
    bot_pid_file = bridge_dir / "slack-bot.pid"
    bot_pid = _read_pid(bot_pid_file)
    bot_alive = bool(bot_pid and _is_process_alive(bot_pid))

    # Notifier status
    notifier_status = {"enabled": False, "connected": False}
    try:
        from maestro.core.bridge_notifier import BridgeNotifier
        notifier = BridgeNotifier(admiralty_dir)
        notifier_status = notifier.get_status()
    except Exception:
        pass

    # Config status
    config_path = admiralty_dir / "config" / "bridge-settings.json"
    config_exists = config_path.exists()

    return {
        "config_exists": config_exists,
        "notifier": notifier_status,
        "poller": {"running": poller_alive, "pid": poller_pid if poller_alive else None},
        "slack_bot": {"running": bot_alive, "pid": bot_pid if bot_alive else None},
    }


def print_status(workspace: Path) -> None:
    """Print a formatted bridge status report."""
    status = bridge_status(workspace)

    print("\n  FLEET COMMAND BRIDGE — STATUS")
    print("  " + "-" * 50)

    # Config
    if status["config_exists"]:
        print("  Config:     bridge-settings.json found")
    else:
        print("  Config:     MISSING — create .adm/config/bridge-settings.json (see: adm docs bridge-setup)")

    # Notifier
    ns = status["notifier"]
    if ns["enabled"]:
        if ns["connected"]:
            pending = ns.get("pending_notifications", 0)
            print(f"  Notifier:   ACTIVE (token configured, {pending} pending)")
        else:
            print("  Notifier:   ENABLED but NO TOKEN — set MAESTRO_SLACK_BOT_TOKEN")
    else:
        print("  Notifier:   DISABLED")

    # Poller
    ps = status["poller"]
    if ps["running"]:
        print(f"  Poller:     RUNNING (PID: {ps['pid']})")
    else:
        print("  Poller:     STOPPED")

    # Bot
    bs = status["slack_bot"]
    if bs["running"]:
        print(f"  Slack Bot:  RUNNING (PID: {bs['pid']})")
    else:
        print("  Slack Bot:  STOPPED")

    print("  " + "-" * 50)
    print()


# ---------------------------------------------------------------------------
# Test notification
# ---------------------------------------------------------------------------

def restart(workspace: Path) -> None:
    """Restart both bridge components (stop then start)."""
    stop_poller(workspace)
    stop_bot(workspace)
    start_poller(workspace)
    start_bot(workspace)


def setup_wizard(workspace: Path) -> None:
    """Interactive setup wizard for bridge-settings.json."""
    admiralty_dir = _get_workspace_subdir(workspace)
    config_path = admiralty_dir / "config" / "bridge-settings.json"

    print("\n  FLEET COMMAND BRIDGE — SETUP WIZARD")
    print("  " + "=" * 50)

    if config_path.exists():
        print(f"\n  Existing config found: {config_path}")
        answer = input("  Reconfigure? [y/N]: ").strip().lower()
        if answer != "y":
            print("  Setup cancelled.")
            return

    print(f"""
  This wizard will create {config_path}.

  Tokens are stored as environment variable references (e.g. ${{MY_VAR}}).
  You will set the actual values in your shell environment — never in the
  config file itself.
""")

    _env_var_re = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')

    def prompt(label: str, default: str = "", required: bool = True) -> str:
        hint = f" [{default}]" if default else ""
        while True:
            val = input(f"  {label}{hint}: ").strip()
            if not val and default:
                return default
            if val or not required:
                return val
            print("  (required — please enter a value)")

    def prompt_env_var(label: str, default: str) -> str:
        while True:
            val = prompt(label, default=default)
            if _env_var_re.match(val):
                return val
            print(f"  Invalid env var name '{val}' — use only letters, digits, and underscores (must not start with a digit).")

    def prompt_channel(label: str, default: str) -> str:
        val = prompt(label, default=default)
        return val if val.startswith("#") else f"#{val}"

    def prompt_bool(label: str, default: bool = True) -> bool:
        hint = "Y/n" if default else "y/N"
        val = input(f"  {label} [{hint}]: ").strip().lower()
        if not val:
            return default
        return val in ("y", "yes")

    # --- Bridge enabled ---
    enabled = prompt_bool("Enable bridge?", default=True)

    # --- Slack ---
    print("\n  -- Slack --")
    bot_token_var = prompt_env_var(
        "Env var name for Slack Bot Token",
        default="MAESTRO_SLACK_BOT_TOKEN"
    )
    app_token_var = prompt_env_var(
        "Env var name for Slack App Token  (Socket Mode)",
        default="MAESTRO_SLACK_APP_TOKEN"
    )
    default_channel = prompt_channel("Default Slack channel", default="#fleet-command")

    # --- GitHub Gist queue ---
    print("\n  -- GitHub Gist Queue (command poller) --")
    gist_id_var = prompt_env_var(
        "Env var name for GitHub Gist ID",
        default="MAESTRO_BRIDGE_GIST_ID"
    )
    github_token_var = prompt_env_var(
        "Env var name for GitHub Token",
        default="MAESTRO_GITHUB_TOKEN"
    )
    poll_interval = prompt("Poll interval (seconds)", default="30")
    try:
        poll_interval = int(poll_interval)
    except ValueError:
        poll_interval = 30

    # --- Projects ---
    print("\n  -- Project Channel Mapping --")
    print("  Enter one project per line as  ACRONYM #channel")
    print("  Leave blank and press Enter when done.\n")
    projects: dict = {}
    while True:
        line = input("  Project (ACRONYM #channel): ").strip()
        if not line:
            break
        parts = line.split()
        if len(parts) < 2:
            print("  Format: ACRONYM #channel  (e.g. ADM #fleet-ADM)")
            continue
        acronym = parts[0].upper()
        channel = parts[1] if parts[1].startswith("#") else f"#{parts[1]}"
        projects[acronym] = {"enabled": True, "channel": channel}

    if not projects:
        print("  (no projects configured — you can add them manually later)")

    # --- Notifications ---
    print("\n  -- Notifications --")
    grace = prompt("Grace period before escalation (minutes)", default="5")
    try:
        grace = int(grace)
    except ValueError:
        grace = 5
    include_escalations = prompt_bool("Notify on escalations?", default=True)
    include_approvals = prompt_bool("Notify on approval requests?", default=True)
    immediate_blocked = prompt_bool("Notify immediately when a crew is blocked?", default=True)

    # --- Build config ---
    config = {
        "bridge": {
            "enabled": enabled,
            "slack": {
                "botToken": f"${{{bot_token_var}}}",
                "appToken": f"${{{app_token_var}}}",
                "defaultChannel": default_channel,
            },
            "projects": projects,
            "queue": {
                "provider": "github-gist",
                "gistId": f"${{{gist_id_var}}}",
                "githubToken": f"${{{github_token_var}}}",
                "pollIntervalSeconds": poll_interval,
            },
            "notifications": {
                "gracePeriodMinutes": grace,
                "includeEscalations": include_escalations,
                "includeApprovals": include_approvals,
                "immediateOnBlocked": immediate_blocked,
            },
        }
    }

    # --- Write ---
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")

    print(f"\n  Config written: {config_path}")
    print("""
  Next steps — set these environment variables in your shell:
""")
    print(f"    export {bot_token_var}=xoxb-...")
    print(f"    export {app_token_var}=xapp-...")
    print(f"    export {gist_id_var}=<your-gist-id>")
    print(f"    export {github_token_var}=ghp_...")
    print("""
  Then verify with:
    adm bridge status
    adm bridge test --project <ACRONYM>
    adm bridge start
""")


def send_test(workspace: Path, project: str) -> None:
    """Send a test notification to verify Slack connectivity."""
    admiralty_dir = _get_workspace_subdir(workspace)
    try:
        from maestro.core.bridge_notifier import BridgeNotifier
        notifier = BridgeNotifier(admiralty_dir)
    except Exception as e:
        raise SystemExit(f"[Bridge] Failed to load notifier: {e}")

    if not notifier.enabled:
        raise SystemExit("[Bridge] Bridge is not enabled — set 'enabled: true' in bridge-settings.json")

    if notifier.send_test_notification(project):
        print(f"[Bridge] Test notification sent to {project} channel")
    else:
        raise SystemExit("[Bridge] Failed to send test notification — check token and channel config")
