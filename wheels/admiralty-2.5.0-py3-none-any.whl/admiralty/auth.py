# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Admiralty — GitHub collaborator licence validation.

Single public entry point: check().
Called at module startup via admiralty/__init__.py.
Bypassable via ADMIRALTY_SKIP_AUTH=1 (CI/CD) or for 'version'/'init' subcommands.
"""

import getpass
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from admiralty.egress.filter import install_egress_filter, EgressDenied

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REPO = "tavisbasing/Admiralty"
AUTH_FILE = Path.home() / ".admiralty" / "auth.json"
API_BASE = "https://api.github.com"
DEFAULT_GRACE_DAYS = 7
TIMEOUT_SECONDS = 5

_SKIP_COMMANDS = {"version", "init"}


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _load_cache() -> dict:
    """Read AUTH_FILE; return {} if missing or corrupt."""
    try:
        with AUTH_FILE.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def _save_cache(data: dict) -> None:
    """Write data to AUTH_FILE with mode 0600. Creates ~/.admiralty/ if needed."""
    try:
        dir_path = AUTH_FILE.parent
        dir_path.mkdir(mode=0o700, parents=True, exist_ok=True)
        with AUTH_FILE.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        try:
            AUTH_FILE.chmod(0o600)
        except OSError:
            pass  # Limited effect on Windows — silently continue
    except OSError as exc:
        print(f"[Admiralty] Warning: could not write auth cache ({exc})", file=sys.stderr)


# ---------------------------------------------------------------------------
# Token prompt
# ---------------------------------------------------------------------------

def _prompt_for_token() -> tuple:
    """Prompt for a GitHub PAT, resolve username via /user, return (token, username)."""
    print("[Admiralty] GitHub authorisation required.", file=sys.stderr)
    print(
        "A GitHub Personal Access Token (PAT) with 'repo' scope is needed to verify\n"
        "your licence as an authorised collaborator on tavisbasing/Admiralty.\n"
        "Create one at: https://github.com/settings/tokens",
        file=sys.stderr,
    )
    token = getpass.getpass("GitHub Personal Access Token: ")

    # Resolve username via /user endpoint
    req = urllib.request.Request(
        f"{API_BASE}/user",
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            user_data = json.loads(resp.read().decode("utf-8"))
            username = user_data.get("login", "")
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, OSError) as exc:
        print(f"[Admiralty] Failed to verify token: {exc}", file=sys.stderr)
        sys.exit(1)

    if not username:
        print("[Admiralty] Could not determine GitHub username from token.", file=sys.stderr)
        sys.exit(1)

    return token, username


# ---------------------------------------------------------------------------
# Collaborator verification
# ---------------------------------------------------------------------------

def _verify_collaborator(token: str, username: str) -> str:
    """
    Call GET /repos/{REPO}/collaborators/{username}.

    Returns one of: 'ok', 'not_collaborator', 'bad_token', 'network_error'.
    """
    url = f"{API_BASE}/repos/{REPO}/collaborators/{username}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            if resp.status == 204:
                return "ok"
            return "not_collaborator"
    except EgressDenied as exc:
        print(f"[Admiralty] {exc}", file=sys.stderr)
        return "network_error"
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return "not_collaborator"
        if exc.code in (401, 403):
            return "bad_token"
        return "network_error"
    except (urllib.error.URLError, OSError):
        return "network_error"


# ---------------------------------------------------------------------------
# Exit messages
# ---------------------------------------------------------------------------

def _exit_not_collaborator() -> None:
    print(
        "\n[Admiralty] Licence validation failed.\n"
        f"You are not listed as an authorised collaborator on {REPO}.\n\n"
        "To obtain access, contact: https://github.com/tavisbasing\n"
        f"For licensing enquiries: https://github.com/{REPO}\n",
        file=sys.stderr,
    )
    sys.exit(1)


def _exit_grace_expired(grace_days: int) -> None:
    print(
        f"\n[Admiralty] Offline grace period expired ({grace_days} days).\n"
        "Could not reach GitHub to verify your licence.\n"
        "Please connect to the internet and retry, or contact https://github.com/tavisbasing.\n",
        file=sys.stderr,
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def check() -> None:
    """
    Verify the current user is an authorised collaborator on tavisbasing/Admiralty.

    Skipped when:
    - ADMIRALTY_SKIP_AUTH=1 is set
    - sys.argv[1] is 'version' or 'init'
    """
    # Env-var bypass (CI/CD)
    if os.environ.get("ADMIRALTY_SKIP_AUTH") == "1":
        return

    # Subcommand bypass
    if len(sys.argv) > 1 and sys.argv[1] in _SKIP_COMMANDS:
        return

    # Install egress filter (no-op in permissive/non-enterprise mode)
    try:
        from pathlib import Path as _Path
        import os as _os
        _cwd = _Path.cwd()
        for _p in [_cwd, *_cwd.parents]:
            if (_p / ".adm" / "config").is_dir():
                install_egress_filter(_p)
                break
    except Exception:
        pass

    cache = _load_cache()
    token = cache.get("token", "")
    username = cache.get("username", "")

    # First run — no token cached
    if not token:
        token, username = _prompt_for_token()
        cache = {"token": token, "username": username, "last_verified": ""}
        _save_cache(cache)

    # Verify collaborator status
    result = _verify_collaborator(token, username)

    if result == "ok":
        cache["last_verified"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        cache["token"] = token
        cache["username"] = username
        _save_cache(cache)
        return

    if result == "not_collaborator":
        _exit_not_collaborator()

    if result == "bad_token":
        print("[Admiralty] Token rejected (401/403). Please re-enter your PAT.", file=sys.stderr)
        token, username = _prompt_for_token()
        retry = _verify_collaborator(token, username)
        if retry == "ok":
            cache["token"] = token
            cache["username"] = username
            cache["last_verified"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            _save_cache(cache)
            return
        if retry == "not_collaborator":
            _exit_not_collaborator()
        # bad_token again or network_error — fall through to network_error handling
        result = retry

    # network_error — check grace period
    grace_days = DEFAULT_GRACE_DAYS
    try:
        grace_days = int(os.environ.get("ADMIRALTY_OFFLINE_GRACE_DAYS", DEFAULT_GRACE_DAYS))
    except (ValueError, TypeError):
        pass

    last_verified = cache.get("last_verified", "")
    if last_verified:
        try:
            last_dt = datetime.strptime(last_verified, "%Y-%m-%dT%H:%M:%SZ").replace(
                tzinfo=timezone.utc
            )
            elapsed = (datetime.now(timezone.utc) - last_dt).days
            if elapsed <= grace_days:
                print(
                    f"[Admiralty] Warning: could not reach GitHub (offline). "
                    f"Grace period active ({elapsed}/{grace_days} days).",
                    file=sys.stderr,
                )
                return
        except ValueError:
            pass

    _exit_grace_expired(grace_days)
