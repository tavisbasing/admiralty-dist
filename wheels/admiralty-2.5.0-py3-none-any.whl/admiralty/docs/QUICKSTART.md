# Admiralty — Quick Start

> From zero to first fleet dispatch in 5 minutes.

---

## 1. Install

```bash
pip install git+https://github.com/tavisbasing/Admiralty.git@main
<<<<<<< HEAD
admiralty version
=======
adm version
>>>>>>> main
```

---

## 2. Validate prerequisites

Before you run Admiralty for the first time, verify:

- **Python 3.11+** — `python --version`
- **Claude Code** installed and on your PATH — `claude --version`
- **Anthropic API key** set — `echo $ANTHROPIC_API_KEY`
- **Git** installed — `git --version`

Fix any issues before continuing.

<<<<<<< HEAD
> **Planned:** `admiralty setup --check` will automate these checks.
=======
> **Tip:** Run `adm setup` for an interactive setup wizard that checks all prerequisites.
>>>>>>> main

---

## 3. Scaffold a workspace

```bash
<<<<<<< HEAD
admiralty init --project MYPROJ
=======
adm init --project MYPROJ
>>>>>>> main
cd my-workspace        # or wherever you ran init
```

> Tip: Replace `MYPROJ` with your project acronym (2–8 uppercase letters).

---

## 4. Create a requirement

A requirement is the front door to Admiralty — describe what needs to happen; the fleet handles the rest.

```bash
<<<<<<< HEAD
admiralty requirement create --project MYPROJ --title "Add user authentication"
```

This creates a requirement file in `.admiralty/requirements/`. The Navigator will break it into orders and a voyage plan when you dispatch.
=======
adm requirement create --project MYPROJ --title "Add user authentication"
```

This creates a requirement file in `.adm/requirements/`. The Navigator will break it into orders and a voyage plan when you dispatch.
>>>>>>> main

**Or use a template:**

```bash
<<<<<<< HEAD
admiralty requirement create --project MYPROJ --template new-feature --title "Add user authentication"
=======
adm requirement create --project MYPROJ --template new-feature --title "Add user authentication"
>>>>>>> main
```

---

## 5. Approve the requirement

```bash
<<<<<<< HEAD
admiralty approve --requirement .admiralty/requirements/REQ-MYPROJ-2026-0001.md
=======
adm approve --requirement .adm/requirements/REQ-MYPROJ-2026-0001.md
>>>>>>> main
```

---

## 6. Launch the fleet

```bash
<<<<<<< HEAD
admiralty dispatch --max-crews 3
=======
adm dispatch --max-crews 3
>>>>>>> main
```

The Fleet Admiral picks up the requirement, assigns a Navigator crew to create a plan, then dispatches work crews as orders become ready.

---

## 7. Monitor progress

```bash
<<<<<<< HEAD
admiralty status
```

Watch the live dashboard. The **APPROVALS** panel (yellow) appears when the Navigator's plan needs your sign-off — run `admiralty approve --plan <FILE>` to proceed.
=======
adm status
```

Watch the live dashboard. The **APPROVALS** panel (yellow) appears when the Navigator's plan needs your sign-off — run `adm approve --plan <FILE>` to proceed.
>>>>>>> main

---

## 8. Check results

```bash
# See completed orders
<<<<<<< HEAD
ls .admiralty/orders/complete/

# Check token usage
admiralty usage --summary
=======
ls .adm/orders/complete/

# Check token usage
adm usage --summary
>>>>>>> main
```

---

## What's next?

| Topic | Document |
|-------|---------|
| Full setup walkthrough | [docs/GETTING-STARTED.md](GETTING-STARTED.md) |
| All CLI commands | [docs/CLI-REFERENCE.md](CLI-REFERENCE.md) |
| Creating orders and voyages directly | [docs/ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) |
| Understanding crew roles | [docs/ROLES-GUIDE.md](ROLES-GUIDE.md) |

---

<<<<<<< HEAD
*Admiralty Fleet Command System v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
=======
*Admiralty Fleet Command System v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
>>>>>>> main
