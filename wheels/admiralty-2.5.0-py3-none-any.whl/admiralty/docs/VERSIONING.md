# Admiralty Versioning

Admiralty uses **MAJOR.MINOR.PATCH** semantic versioning.

## Scheme

| Increment | When to use | Example |
|-----------|-------------|---------|
| `+1.0.0` | Breaking change, framework redesign, migration required | `1.x → 2.0.0` |
| `+0.1.0` | New feature, new command, non-breaking enhancement | `2.0.0 → 2.1.0` |
| `+0.0.1` | Bug fix, typo, minor correction | `2.0.0 → 2.0.1` |

## Version History

| Version | Description |
|---------|-------------|
| **v2.5.0** | Licence backend (Polar.sh) — replaces GitHub-collaborator auth with `adm licence activate/status/deactivate/revalidate`, HMAC-signed local store, OS-keychain-backed signing secret, 14-day offline grace, Polar webhook receiver (Fly.io / Sydney), branch-discipline enforcement (BUG-0004). Closes the long-standing FTR-ADM-2026-0013 licensing-system roadmap order. See release notes below. |
| **v2.4.0** | `adm quickstart` — single-command end-to-end demo voyage that runs in under three minutes for a first-time user with Claude Code + Anthropic API key. Ships docs/QUICKSTART.md, README quickstart section, and the asciinema recording script. See release notes below. |
| **v2.3.0** | Comparator-recon follow-ups: secret detection in pretool, MCP server registry + dispatch-time enforcement, OWASP/CWE scanning + COX security gate, pytest core-dispatch suite + GitHub Actions CI. See release notes below. |
| **v2.2.0** | COX role expansion (PR creation, CI/CD monitoring, Copilot review resolution, QM notification). Default COX model bumped to Opus 4.7. |
| **v2.1.0** | Acceptance criteria schema, `adm update` command, quality gates. |
| **v2.0.0** | Breaking redesign — `.adm/` project directory + pip-only installation. `adm` and `admiralty` CLI entry points. |
| **v1.x** (formerly `9.x`) | Legacy `.admiralty/` monolith — submodule-based installation. |

---

## v2.5.0 Release Notes

**Released:** 2026-04-30

Source: VOY-ADM-2026-0031 (licence backend) + BUG-ADM-2026-0004 (branch discipline). Closes FTR-ADM-2026-0013 (licence system roadmap order).

### Licence backend (Polar.sh)

Replaces the GitHub-collaborator auth in [admiralty/auth.py](../auth.py) with a proper licence-key system backed by Polar.sh (selected over Lemon Squeezy/Paddle/Keygen-self-host on take-rate, OSS-alignment, and AU-tax MoR coverage — full comparison in [PLAN-VOY-ADM-2026-0031](../../.adm/plans/PLAN-VOY-ADM-2026-0031.md)).

New module: [admiralty/licence/](../licence/) — `__init__.py` (public API: `activate` / `validate` / `deactivate` / `status`), `client.py` (Polar API client, urllib only — no httpx dep on the CLI hot path), `storage.py` (HMAC-SHA256 signature over `~/.admiralty/licence.json` mode 0600, per-customer signing secret in OS keychain via `keyring` lib with file-mode-0600 fallback), `grace.py` (pure datetime + RFC3339-Z parser), `errors.py` (`LicenceMissing` / `LicenceInvalid` / `LicenceRevoked` / `LicenceExpired` / `LicenceTampered`), `webhooks.py` (Polar webhook receiver shipping in [infra/licence-backend/](../../infra/licence-backend/)).

New CLI: `adm licence activate <KEY> | status [--json] | deactivate | revalidate` (with `license` accepted as alias).

Behaviour:
- Cached-OK fast path within 24h of last validation; force online via `adm licence revalidate`.
- 14-day offline grace from last successful online validation; CLI shows a warning banner when grace fallback is active (`record.used_grace == True`).
- Cross-machine theft mitigation: copying `licence.json` without the keychain entry triggers `LicenceTampered`.
- Polar API errors map to specific exceptions deterministically via `polar_status` (not string-matching `reason`).

### Polar webhook backend (Fly.io)

[infra/licence-backend/](../../infra/licence-backend/) — Sydney-region Fly.io deployable. HMAC-SHA256 signature verification with 5-min replay window; 4 event handlers (`subscription.created/updated/canceled/refunded`) + `payment.refunded` alias. `flyctl secrets set POLAR_WEBHOOK_SECRET=...` rotates without redeploy.

Operator runbook: [infra/licence-backend/README.md](../../infra/licence-backend/README.md). Customer-facing docs: [docs/LICENCE.md](../../docs/LICENCE.md), [docs/AIR-GAPPED.md](../../docs/AIR-GAPPED.md).

### Branch-discipline enforcement (BUG-ADM-2026-0004)

`voyageBranch` is now **load-bearing**, not advisory. Three layers:
- Dispatcher (`fleet_runner.py:_verify_dispatcher_branch`) checks out the right branch before every crew launch.
- Pretool guard (`hooks/branch_guard.py`) denies `git`/`gh` mutations targeting a different branch (including the `gh pr create --head` flag form, both space and equals).
- Every role prompt template (NAV/SHP/BOS/SCR/LKT/COX) gets a "Branch discipline (mandatory)" section.

Operator escape: `ADMIRALTY_BRANCH_GUARD_BYPASS=1` for QM manual-recovery sessions only. See [docs/BRANCH-DISCIPLINE.md](../../docs/BRANCH-DISCIPLINE.md).

### Tests

- 95 cases across `tests/test_licence.py` (37) + `tests/test_licence_webhooks.py` (22) + `tests/test_licence_extended.py` (36 — grace soak, expiry edge cases, tamper variants, full lifecycle, concurrent saves, webhook→CLI consistency, parse_iso edge cases).
- 40 cases in `tests/test_branch_guard.py` (denial / approval / bypass / Captain-direct / dispatcher checkout-create / `gh pr create --head` flag / explicit cross-branch targets / credential redaction).

### Other

- `schemaVersion` in `workspace.json` and `workspace.json.j2` template bumped to `2.5.0`.
- LKT review: 4 LOW findings (3 fixed in PR #38, 1 deferred as cosmetic). Report at [.adm/reports/security/SEC-FTR-ADM-2026-0092.md](../../.adm/reports/security/SEC-FTR-ADM-2026-0092.md).

### Closes
- FTR-ADM-2026-0013 (licence system roadmap order — original placeholder from before VOY-0031 was scoped).

---

## v2.4.0 Release Notes

**Released:** 2026-04-28

Source: [VOY-ADM-2026-0028](../../.adm/voyages/active/VOY-ADM-2026-0028.json) — Phase 1 productisation. Closes part of the still-open FTR-ADM-2026-0009 (admiralty setup wizard) by delivering the user-facing entry point.

### `adm quickstart` Command (VOY-ADM-2026-0028)

New CLI command: `adm quickstart` — one-shot bootstrap for a brand-new operator.

- Scaffolds a throwaway demo workspace, queues a pre-canned demo voyage, and walks the user through `adm dispatch` end-to-end without manual JSON authoring
- **Three-minute SLA** — designed to complete in under 3 minutes on a fresh machine with Claude Code + an Anthropic API key already configured
- Idempotent — safe to re-run; won't clobber an existing workspace
- Demo voyage content (NAV plan → SHP `hello.py` → BOS QA) is embedded in `admiralty/quickstart.py` as `DEMO_ORDER_TEMPLATES` so it can't drift from a packaging template; voyage/order IDs use the chosen `--project` prefix and a year + sequence picked at runtime, so re-runs don't collide
- Test coverage: happy path + 5 edge cases (FTR-ADM-2026-0075), security-reviewed for secret leakage in console output (FTR-ADM-2026-0076)
- Documentation: [docs/QUICKSTART.md](QUICKSTART.md), README quickstart section, asciinema recording script for the marketing capture (FTR-ADM-2026-0077)

### Other

- `schemaVersion` in `workspace.json` and `workspace.json.j2` template bumped to `2.4.0`
- OPERATOR-GUIDE.md version-scope header and footer updated to v2.4.0

---

## v2.3.0 Release Notes

**Released:** 2026-04-27

Source: voyages VOY-ADM-2026-0022 through 0025, all derived from the comparator reconnaissance against `affaan-m/everything-claude-code` (VOY-ADM-2026-0021). Closes the security-tooling and engineering-foundations gaps surfaced by that recon.

### Secret Detection in Pretool (VOY-ADM-2026-0022)

New module: [admiralty/hooks/secret_patterns.py](../hooks/secret_patterns.py).

- Pattern library covers AWS access keys, GitHub PATs (classic + fine-grained), OpenAI / Anthropic / Slack tokens, JWTs, RSA/SSH private keys, and a high-entropy fallback gated by an entropy keyword window
- [pretool.py](../hooks/pretool.py) calls the scanner before any `Edit`/`Write`/`MultiEdit`/`NotebookEdit` and blocks the tool call (with a structured `decision: deny`) if a non-allowlisted match is found
- **Fail-closed** — scanner exceptions deny the tool call and `logger.exception()` the failure (never the matched value)
- Per-workspace allowlist at `.adm/config/secret-allowlist.json` (scaffolded by `adm init` from the bundled template); legacy `.admiralty/config/` honoured for v1.x workspaces
- Test suite: [test_secret_patterns.py](../../tests/test_secret_patterns.py), [test_pretool_secret_guard.py](../../tests/test_pretool_secret_guard.py)

### MCP Server Registry (VOY-ADM-2026-0023)

New module: [admiralty/mcp.py](../mcp.py) + JSON Schema at [admiralty/config/mcp-servers.schema.json](../config/mcp-servers.schema.json).

- Canonical MCP server registry at `.adm/config/mcp-servers.json` with per-server `risk_level`, `allowed_roles`, and `env_required`
- **Fleet Admiral enforcement** — [fleet_runner.py](../core/fleet_runner.py) refuses to launch a crew that requires an unregistered server, or whose role isn't in `allowed_roles`. Permissive fallback (with warning) when no registry is present
- New CLI: `adm mcp list|add|remove|validate|show`
- `adm update` migrates existing `.claude/settings.json mcpServers` entries into the registry (idempotent; `--dry-run` honoured; refuses to migrate entries with empty `command`)
- Server-name uniqueness enforced explicitly in `validate_registry()` (JSON Schema's `uniqueItems` only checks whole-object equality)

### OWASP/CWE Scanning + COX Security Gate (VOY-ADM-2026-0024)

New module: [admiralty/security/owasp_patterns.py](../security/owasp_patterns.py).

- Pattern library covering OWASP Top 10 + CWE: SQL injection, XSS, path traversal, hardcoded credentials, insecure deserialization, command injection, weak crypto, missing-auth decorators (Python first; JS/TS/C# marked future)
- [posttool.py](../hooks/posttool.py) invokes the scanner when `ADMIRALTY_ROLE=LKT` and merges findings into `.adm/reports/security/SEC-{ORDER-ID}.json` + `.md`
- **COX security gate** — [pr_merge.py](../core/pr_merge.py) refuses to merge if any unresolved HIGH or CRITICAL finding exists; MEDIUM requires an acknowledged waiver
- New CLI: `adm security scan [--order|--voyage|--since|--json]` for manual invocation
- **Credential snippet redaction** — findings tagged `OWASP-A07-CRED-*` write a redaction marker into the report instead of the matched line, so the SEC reports never leak the secret they detected

### Unit Test Suite + GitHub Actions CI (VOY-ADM-2026-0025)

- New `tests/` directory (55 tests) covering [fleet_runner.py](../core/fleet_runner.py), [crew.py](../core/crew.py), [fleet_monitor.py](../core/fleet_monitor.py)
- [.github/workflows/ci.yml](../../.github/workflows/ci.yml) — pytest matrix on Python 3.11 / 3.12 / 3.13 with coverage publishing
- Coverage threshold set to 70% with `continue-on-error: true` until follow-up tests raise actual coverage past the bar
- Dev install via `pip install -e .[dev]` — adds `pytest`, `pytest-cov`, `pytest-mock`
- CI sets `ADMIRALTY_SKIP_AUTH=1` so the licence prompt doesn't EOFError on non-TTY stdin

### Other

- Comparator reconnaissance report published at [docs/COMPARATOR-everything-claude-code.md](../../docs/COMPARATOR-everything-claude-code.md) — public positioning piece + 12-dimension feature matrix versus `affaan-m/everything-claude-code`
- Open bug: [BUG-ADM-2026-0002](../../.adm/queues/bugs/BUG-ADM-2026-0002.json) — Fleet Admiral re-injects already-completed orders into the queue after sweeps. Tracked for a follow-up patch.

---

## v2.2.0 Release Notes

**Released:** 2026-04-21

### Coxswain Role Expansion

COX is now the terminal role for every voyage and explicitly owns the handshake from "work complete" to "PR Captain-review-ready":

- Verifies the voyage branch has every commit pushed to origin
- Resolves the repo's default branch (`main` or `master`) via `gh api` and opens the Pull Request
- Monitors CI/CD checks via `gh pr checks --watch`; failures regress to the responsible role (SHP/BOS/LKT) rather than being fixed by COX directly
- Fetches GitHub Copilot review comments and addresses each — applying doc/config fixes itself, regressing code/test issues, or declining with rationale
- Resolves Copilot review threads via GitHub GraphQL `resolveReviewThread` mutation
- Writes the terminal `COX-to-QM.md` handoff, updates voyage JSON to `READY_FOR_REVIEW`, and notifies the Captain via the bridge
- Never merges the PR — that remains the Captain's prerogative

See [ROLES-GUIDE.md](ROLES-GUIDE.md) and the updated [coxswain.md](../roles/coxswain.md) for full responsibilities.

### Model Updates

- **Default COX model bumped to Opus 4.7** (`claude-opus-4-7`). Opus 4.6 remains in pricing tables so historical transcripts still resolve.
- Pricing table in [fleet_usage_tracker.py](../core/fleet_usage_tracker.py) and [stop.py](../hooks/stop.py) now lists Opus 4.7 alongside 4.6.

### Branching Policy

Each voyage and each bug now requires its own branch and its own PR — no bundling:

- Voyage branches: `voyage/VOY-{PRJ}-{YEAR}-{SEQ}-{short-description}`
- Bug branches: `bug/BUG-{PRJ}-{YEAR}-{SEQ}-{short-description}`
- Framework-only changes: `admiralty/{description}`
- Voyage branches carry both framework code AND the ADM artefacts (plans, orders, reports) produced by that voyage

See [CLAUDE.md](../../CLAUDE.md) branching policy section.

---

## v2.1.0 Release Notes

**Released:** 2026-04-17

### Acceptance Criteria Schema

Orders now support a structured `acceptanceCriteria` field — an array of objects that BOS validates and COX gates on.

- Three validation types: `manual`, `command`, `file-exists`
- Two severity levels: `blocking` (default) and `advisory`
- BOS records results in a companion `acResults` field on the order
- COX applies a hard stop if any blocking criterion fails; advisory failures log a warning but do not block
- Fully backwards-compatible — orders without `acceptanceCriteria` continue to work unchanged

See [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) for the full schema reference.

### `adm update` Command

New command to propagate schema and template changes from the installed Admiralty package into an existing `.adm/` workspace without destructive overwrites.

- Merges missing keys into JSON config files; never overwrites existing values
- Replaces the Admiralty block in `.gitignore`
- Updates generated sections in `.adm/claude.md` (between `<!-- adm:generated -->` markers)
- Bumps `schemaVersion` in `workspace.json` after a successful run
- `--dry-run` shows what would change without applying it
- `--force` replaces skipped files (e.g. fully customised prose files)

See [CLI-REFERENCE.md](CLI-REFERENCE.md) for full flag documentation.

### Quality Gate Changes

BOS role prompts now include an explicit AC validation phase. COX role prompts enforce gate logic based on `acResults` before marking orders complete.

> **Note:** The legacy `9.x` series used an internal numbering convention unrelated to semver. v2.0.0 marks the first public semver release.

## Release Tags

Tags on the public repo follow the `v{MAJOR}.{MINOR}.{PATCH}` format:

```bash
git tag v2.0.0 -m "Admiralty Fleet Command System v2.0.0"
git push origin v2.0.0
```

Examples: `v2.0.0`, `v2.1.0`, `v2.0.1`

## Installation by Tag

```bash
pip install git+https://github.com/tavisbasing/Admiralty.git@v2.0.0
```
