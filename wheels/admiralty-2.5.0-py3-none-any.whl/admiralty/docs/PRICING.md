# Admiralty — Pricing

> **Note:** The licence-key system described below is planned for a future release. Current releases use GitHub collaborator-based access control. This document describes the commercial packaging target.

Admiralty Fleet Command System v2.0.0 is available in four tiers: Trial, Solo, Team, and Enterprise.

---

## Contents

1. [Tier Comparison](#tier-comparison)
2. [What Each Tier Includes](#what-each-tier-includes)
3. [ROI Example](#roi-example)
4. [Try It Free](#try-it-free)
5. [Upgrading](#upgrading)
6. [Frequently Asked Questions](#frequently-asked-questions)

---

## Tier Comparison

| Feature | Trial | Solo | Team | Enterprise |
|---------|-------|------|------|-----------|
| **Price** | Free (14 days) | Contact us | Contact us | Contact us |
| **Max concurrent crews** | 3 | 3 | 5 | 5 |
| **Max projects** | 1 | 3 | Unlimited | Unlimited |
| **Token usage tracking** | ✓ | ✓ | ✓ | ✓ |
| **Fleet monitor dashboard** | ✓ | ✓ | ✓ | ✓ |
| **Backup / restore** | ✓ | ✓ | ✓ | ✓ |
| **Voyage management** | ✓ | ✓ | ✓ | ✓ |
| **Priority-queue dispatch** | ✓ | ✓ | ✓ | ✓ |
| **Captain approval workflow** | ✓ | ✓ | ✓ | ✓ |
| **ROI reporting** | — | — | ✓ | ✓ |
| **Priority support** | — | — | ✓ | ✓ |
| **Audit export** | — | — | — | ✓ |
| **Custom SLA** | — | — | — | ✓ |
| **SSO (Enterprise IdP)** | — | — | — | Contact sales |
| **Offline grace period** | — | 30 days | 30 days | 30 days |

---

## What Each Tier Includes

### Trial

A full-featured 14-day trial with no credit card required.

- Up to 3 concurrent crews
- 1 project
- All core commands: `dispatch`, `status`, `usage`, `backup`, `verify`
- After 14 days, only `admiralty version` and `admiralty licence` remain available until a licence key is activated

**Trial limits are enforced at dispatch time.** The trial banner is shown in `admiralty status` while active.

---

### Solo

For individual developers running Admiralty on a single machine.

- Up to 3 concurrent crews
- Up to 3 projects
- All core commands
- 30-day offline grace period (licence validated locally, network check skipped when offline)
- 1 registered seat (no seat management)

---

### Team

For multi-engineer teams sharing a workspace or project set.

- Up to 5 concurrent crews
- Unlimited projects
- All core commands plus ROI reporting and priority support
- 30-day offline grace period
- Seat registration on activation — machine ID recorded locally

---

### Enterprise

For large organisations with compliance and identity requirements.

- Up to 5 concurrent crews
- Unlimited projects
- All Team features plus:
  - Audit export
  - Custom SLA
  - SSO placeholder (contact sales to configure your IdP)
- 30-day offline grace period
- Dedicated support channel

> **SSO note:** Enterprise SSO integration is currently in rollout. To configure your organisation's identity provider, contact [admiralty@tech127.com](mailto:admiralty@tech127.com).

---

## ROI Example

**Scenario:** A four-engineer team shipping a mid-size feature — 12 orders covering planning, implementation, QA, and documentation.

| Activity | Without Admiralty | With Admiralty (Team tier) |
|----------|------------------|---------------------------|
| Planning and order breakdown | 1 day (senior eng) | ~15 min (NAV crew, automated) |
| Implementation (12 tasks) | 4–5 days (2 engineers) | ~6–8 hours (3–5 SHP crews parallel) |
| QA and defect triage | 2 days (QA engineer) | ~2–3 hours (BOS crew, automated) |
| Documentation | 1 day (technical writer) | ~1–2 hours (SCR crew, automated) |
| **Total calendar time** | **8–9 days** | **~1–2 days** |
| **Engineering cost** | Full 4-person sprint | API costs + ~2 hours review |

**Typical API cost for 12 orders (Sonnet 4.6):** $8–$25 depending on order complexity, model mix, and caching.

ROI reporting (`admiralty usage --report`) generates a full breakdown of token consumption and estimated cost per voyage, so you can track expenditure against value delivered.

---

## Try It Free

Admiralty starts in trial mode automatically. No key, no credit card, no configuration needed.

**Step 1 — Install:**

```bash
pip install git+https://github.com/tavisbasing/Admiralty.git@main
```

**Step 2 — Scaffold a workspace:**

```bash
admiralty init --project MYPROJ
```

**Step 3 — Dispatch your first crew:**

```bash
admiralty dispatch --max-crews 3
```

**Check your trial status at any time:**

```bash
admiralty licence status
```

Output:

```
[Admiralty Trial]
  Days remaining: 11/14
  Max crews:      3
  Max projects:   1
  To upgrade:     https://admiraltyai.com/pricing
```

The trial runs for 14 days from first use. All core features are available within trial limits. When the trial expires, activate a licence key to continue:

```bash
admiralty licence activate ADM-SOLO-00000000-20270401-xxxxxx
```

---

## Upgrading

To activate a licence key once you have one:

```bash
admiralty licence activate <YOUR-KEY>
```

To check licence status:

```bash
admiralty licence status
```

To deactivate (free the seat on this machine):

```bash
admiralty licence deactivate
```

For Team and Enterprise keys, activation records this machine as a registered seat in `~/.admiralty/licence.json`.

---

## Frequently Asked Questions

**Q: What happens when my trial expires?**

`admiralty version` and `admiralty licence` continue to work. All other commands require an active licence key or GitHub collaborator access. Activate a key to resume.

**Q: Does licence validation require internet access?**

On first activation and periodically during use, the licence is validated locally using an embedded HMAC checksum — no server call is required for day-to-day use. The 30-day offline grace period means the licence remains active even when your machine is offline or air-gapped.

**Q: Can I use the same licence key on multiple machines?**

Solo licences are single-seat (one machine). Team and Enterprise licences support multiple seats — each machine activation registers a seat locally. Contact [admiralty@tech127.com](mailto:admiralty@tech127.com) for seat counts and multi-machine policies.

**Q: Is Anthropic API cost included?**

No. Admiralty is the orchestration framework. You supply your own Anthropic API key, and API costs are billed directly to your Anthropic account. Use `admiralty usage --summary` to monitor expenditure.

**Q: What is the key format?**

Licence keys follow the format `ADM-{TIER}-{ORG_HASH}-{EXPIRY}-{CHECKSUM}`, for example `ADM-TEAM-a1b2c3d4-20270331-x9y8z7`. Validation is local and offline-safe.

**Q: Where is the licence stored?**

At `~/.admiralty/licence.json`. The file stores your key, tier, expiry, last-validation timestamp, and machine ID. It does not contain secrets.

---

*Admiralty Fleet Command System v2.0.0 — For pricing enquiries, contact [tavisbasing](https://github.com/tavisbasing) or email [admiralty@tech127.com](mailto:admiralty@tech127.com).*
