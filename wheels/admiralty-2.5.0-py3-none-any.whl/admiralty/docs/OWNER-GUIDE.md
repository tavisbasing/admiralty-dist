# Admiralty — Owner & Developer Guide

> For framework owners and maintainers. If you're a commercial user looking to get started, see [GETTING-STARTED.md](GETTING-STARTED.md).

---

## Contents

1. [Repository Overview](#1-repository-overview)
2. [Branch Strategy](#2-branch-strategy)
3. [Development Workflow](#3-development-workflow)
4. [Versioning](#4-versioning)
5. [Cutting a Release](#5-cutting-a-release)
6. [Adding a New Project](#6-adding-a-new-project)
7. [Managing Project State](#7-managing-project-state)
   - [7.5 Captain Review Workflow (AWAITING_APPROVAL)](#75-captain-review-workflow-awaiting_approval)
   - [7.6 Budget Enforcement and Billing Mode](#76-budget-enforcement-and-billing-mode)
8. [Commercial Licensing Strategy](#8-commercial-licensing-strategy)
9. [Maintenance Workflows](#9-maintenance-workflows)
10. [Workspace Backup Strategy](#10-workspace-backup-strategy)
11. [CLI Reference](#11-cli-reference)
12. [Collaborator Access Management](#12-collaborator-access-management)

---

## 1. Repository Overview

```
tavisbasing/Admiralty/
├── .admiralty/                  # Fleet Command System (runtime + config)
│   ├── core/                    # fleet-runner.py, crew.py, fleet_monitor.py, etc.
│   ├── config/                  # workspace.json, projects.json, role-paths.json
│   │   └── projects/            # Per-project config files ({ACRONYM}.json)
│   ├── hooks/                   # Claude Code hooks (stop, pretool, posttool, notification)
│   ├── orders/                  # ADM order tracking (active, complete, failed)
│   ├── voyages/                 # ADM voyage tracking
│   ├── queues/                  # Dispatch queues (orders, bugs, security, etc.)
│   ├── plans/                   # Navigator planning documents
│   ├── crews/                   # Per-crew runtime state
│   └── CHAIN-OF-COMMAND.md      # Technical specification
├── admiralty/                   # Python package (pip-installable CLI)
│   ├── __init__.py              # Version + title
│   ├── cli.py                   # Entry points for all admiralty commands
│   └── init.py                  # `admiralty init` scaffold logic
├── docs/                        # End-user and owner documentation
├── pyproject.toml               # pip package definition
├── README.md                    # GitHub-facing project overview
└── CLAUDE.md                    # Quartermaster instructions (this workspace)
```

**Key principle:** The Admiralty repo is both the framework source and the pip package. The `admiralty/` Python package delegates all CLI commands to the scripts in `.admiralty/core/`. No duplication of logic.

---

## 2. Branch Strategy

### Branch Types

| Branch Pattern | Purpose | Who Uses It |
|----------------|---------|-------------|
| `main` | Clean framework. No project state. The installable package. | Everyone |
| `admiralty/{description}` | Framework changes: core scripts, CLI, hooks, config | Owner/QM |
| `project/{ACRONYM}` | Project-specific state: orders, voyages, prompts, plans | Per-project |

### Rules

- **`main` is always clean.** No project state (`orders/`, `voyages/`, `prompts/`, crew runtime files) on `main`.
- **Framework changes** (`.admiralty/core/`, `admiralty/`, `pyproject.toml`, `docs/`) go on `admiralty/` branches, then PR to `main`.
- **Project state** for a given project lives on `project/{ACRONYM}` branches. These branches layer project state on top of `main`.
- **Never** bundle framework changes with project state in the same branch or PR.

### Example Flows

**Developing a framework feature:**
```bash
git checkout main
git pull
git checkout -b admiralty/v2.0-new-feature
# ... make changes ...
git push -u origin admiralty/v2.0-new-feature
# Open PR → main
```

**Managing ADM (Admiralty self-development) project state:**
```bash
# The Admiralty repo uses main branch for its own ADM project state
# since this workspace IS the framework repo
git checkout main
# Orders, voyages, etc. are committed directly to main for ADM work
```

---

## 3. Development Workflow

### Prerequisites

- Python 3.9+
- [Claude Code](https://claude.ai/code) CLI installed and authenticated
- Anthropic API key with access to Sonnet 4.6, Haiku 4.5, and Opus 4.7
- `pip install -e .` from the Admiralty repo root

### Local Development Setup

```bash
# Clone the repo
git clone https://github.com/tavisbasing/Admiralty
cd Admiralty

# Install in editable mode (development)
pip install -e .

# Verify
admiralty version
```

With editable install, changes to `admiralty/` take effect immediately without reinstalling. Changes to `.admiralty/core/*.py` scripts also take effect immediately since the CLI delegates via subprocess.

### Making Framework Changes

1. **Create a branch:** `git checkout -b admiralty/{description}`
2. **Make changes** to core scripts, CLI, hooks, or docs
3. **Test locally** — run against a real workspace with crews
4. **Update version** if warranted (see [Versioning](#4-versioning))
5. **Update documentation** — CHAIN-OF-COMMAND.md, .admiralty/CLAUDE.md, root CLAUDE.md
6. **Open PR** to `main`

### Testing Changes

There is currently no automated test suite. Validation is manual:

```bash
# Test pip CLI
admiralty version
admiralty init --project TEST --directory /tmp/test-workspace

# Test dispatch (from a workspace with queued orders)
admiralty dispatch --max-crews 2

# Test monitor
admiralty status --once

# Test cleanup
admiralty cleanup
```

For major changes to the hook system or dispatcher, validate token tracking is preserved:
```bash
# After a crew completes, check usage file exists
ls .admiralty/usage/orders/
admiralty usage --summary
```

---

## 4. Versioning

### Version Number Format

`{major}.{minor}.{patch}` — currently `2.0.0`.

See [VERSIONING.md](VERSIONING.md) for the full versioning scheme and history.

### Files to Update on Version Bump

When bumping the Fleet Command System version, update **all** of these:

| File | What to Change |
|------|---------------|
| `pyproject.toml` | `version = "X.Y.Z"` |
| `admiralty/__init__.py` | `__version__ = "X.Y.Z"` |
| `.admiralty/CHAIN-OF-COMMAND.md` | Header line and capability timeline entry |
| `.admiralty/CLAUDE.md` | Header and component version table |
| `CLAUDE.md` (root) | "Fleet Command System vX.Y" reference |
| `.admiralty/config/workspace.json` | `notes` field |
| Core script headers | `crew.py`, `fleet-runner.py`, `fleet-stop-hook.py` inline comments |

### Version Bump Checklist

```
- [ ] pyproject.toml version field
- [ ] admiralty/__init__.py __version__
- [ ] CHAIN-OF-COMMAND.md header + timeline
- [ ] .admiralty/CLAUDE.md header + component table
- [ ] Root CLAUDE.md version reference
- [ ] .admiralty/config/workspace.json notes
- [ ] Core script headers (crew.py, fleet-runner.py, fleet-stop-hook.py)
```

---

## 5. Cutting a Release

### Step-by-Step Release Process

#### 1. Prepare the release branch

```bash
git checkout main
git pull
git checkout -b admiralty/vX.Y.Z-release
```

#### 2. Update version numbers

Update all files listed in the [Version Bump Checklist](#version-bump-checklist) above.

#### 3. Update documentation

- Review and update `docs/` for any new features or changed behaviour
- Update `README.md` if the feature set or installation instructions changed
- Update `CHAIN-OF-COMMAND.md` with the version capability entry

#### 4. Commit and PR

```bash
git add pyproject.toml admiralty/__init__.py .admiralty/CHAIN-OF-COMMAND.md ...
git commit -m "chore: bump version to vX.Y.Z"
git push -u origin admiralty/vX.Y.Z-release
# Open PR → main, get approval
```

#### 5. Merge to main

```bash
# After PR approval
gh pr merge --squash
```

#### 5b. (Optional) Verify obfuscated build locally

Before tagging, confirm the obfuscated package builds cleanly:

```bash
pip install pyarmor==8.* build
python .admiralty/build/build-dist.py --output-dir dist/
# Inspect dist/ for *.whl and *.tar.gz
```

See [Section 5.1 — Obfuscated Build](#51-obfuscated-build) for details.

#### 6. Tag the release

```bash
git checkout main
git pull
git tag vX.Y.Z -m "Fleet Command System vX.Y.Z"
git push origin vX.Y.Z
```

#### 7. Create GitHub Release

```bash
gh release create vX.Y.Z \
  --title "Admiralty vX.Y.Z — Fleet Command System" \
  --notes "$(cat <<'EOF'
## What's New
- Feature 1
- Feature 2

## Breaking Changes
- None

## Installation
\`\`\`bash
pip install git+https://github.com/tavisbasing/Admiralty.git@vX.Y.Z
\`\`\`
EOF
)"
```

#### 8. Publish to package registry

Publishing is automated via GitHub Actions when you push a `v*` tag (step 6 above). The workflow at `.github/workflows/publish.yml` will:

1. Build the obfuscated package using `.admiralty/build/build-dist.py`
2. Publish the resulting `.whl` and `.tar.gz` to the GitHub Package Registry

**Monitor the publish run:**
```bash
gh run list --workflow publish.yml
gh run view <run-id>
```

**Manual publish (if needed):**
```bash
pip install pyarmor==8.* build twine
python .admiralty/build/build-dist.py --output-dir dist/
twine upload --repository github dist/*
```

**Private PyPI:**
```bash
python .admiralty/build/build-dist.py --output-dir dist/
twine upload --repository-url https://your-registry/ dist/*
```

See [Section 5.1 — Obfuscated Build](#51-obfuscated-build) and [Commercial Licensing Strategy](#8-commercial-licensing-strategy) for details.

---

## 5.1 Obfuscated Build

The distributed pip package is obfuscated using [PyArmor](https://pyarmor.readthedocs.io/) to protect IP in the CLI layer.

### What is obfuscated

| File | Obfuscated | Reason |
|------|-----------|--------|
| `admiralty/__init__.py` | Yes | Version + startup code |
| `admiralty/cli.py` | Yes | CLI entry points |
| `admiralty/init.py` | Yes | Workspace scaffold logic |

### What is NOT obfuscated

| Path | Reason |
|------|--------|
| `.admiralty/core/*.py` | Crews read and execute these at runtime — must remain plain Python |
| `.admiralty/hooks/*.py` | Same — hooks are injected into live Claude Code sessions |
| Everything else in `.admiralty/` | Config, orders, voyages — not packaged |

### Running the build locally

```bash
# Install prerequisites (once)
pip install pyarmor==8.* build

# Run the build script from the repo root
python .admiralty/build/build-dist.py

# Artifacts appear in dist/
ls dist/
# admiralty-2.0.0-py3-none-any.whl
# admiralty-2.0.0.tar.gz
```

Override the output directory:
```bash
python .admiralty/build/build-dist.py --output-dir /tmp/admiralty-test/
```

### GitHub Actions auto-publish

Pushing a `v*` tag triggers `.github/workflows/publish.yml` which:
1. Installs `pyarmor==8.*`, `build`, and `twine`
2. Runs `build-dist.py` to produce the obfuscated package
3. Publishes to the GitHub Package Registry using `GITHUB_TOKEN`

No secrets need to be configured — the workflow uses the Actions-provided `GITHUB_TOKEN` with `packages: write` permission.

### PyArmor licensing

PyArmor Community Edition supports up to 1000 files per run. The Admiralty CLI package has 3 files — no commercial PyArmor license is required for the current codebase.

---

## 6. Adding a New Project

### Overview

A "project" in Admiralty is a codebase that crews work on. The framework itself (`ADM`) is registered as a project. Additional projects (e.g. `OTM`, `PSG`) are registered in the same workspace.

### Step 1 — Register in projects.json

Edit `.admiralty/config/projects.json`:

```json
{
  "projects": {
    "MYPROJ": {
      "name": "My Project",
      "acronym": "MYPROJ",
      "directory": "my-project",
      "repo": "your-org/my-project",
      "org": "your-org",
      "defaultBranch": "main",
      "voyageBranchPattern": "voyage/{VOYAGE-ID}",
      "cloneProtocol": "https",
      "configFile": "config/projects/MYPROJ.json"
    }
  }
}
```

`directory` is the local path relative to the workspace root where the project repo lives (or will be cloned).

### Step 2 — Create per-project config

Create `.admiralty/config/projects/MYPROJ.json`:

```json
{
  "$schema": "Fleet Command — Project Configuration",
  "lastUpdated": "YYYY-MM-DD",

  "common": {
    "projectRoot": "my-project",
    "admiraltyRoot": ".admiralty",
    "sourceRoot": "my-project/src",
    "documentationRoot": "my-project/docs"
  },

  "roles": {
    "NAV": {
      "inputs": {
        "fullCodebase": "my-project/**/*",
        "requirements": ".admiralty/requirements/",
        "activeOrders": ".admiralty/orders/active/"
      },
      "outputs": {
        "plans": ".admiralty/plans/",
        "handoffs": ".admiralty/handoffs/{ORDER-ID}/",
        "progress": ".admiralty/crews/crew{N}/progress.md"
      }
    },
    "SHP": {
      "inputs": { "sourceCode": "my-project/src/**" },
      "outputs": { "sourceCode": "my-project/src/" }
    }
  }
}
```

Adjust `inputs` and `outputs` for each role to match your project's directory structure.

### Step 3 — Clone the project repo

```bash
git clone https://github.com/your-org/my-project my-project
```

Or let the Fleet Admiral manage clones automatically (v2.0.0+ managed repo lifecycle). The dispatcher clones into `.admiralty/crews/crewN/repo/` when dispatching orders.

### Step 4 — Update CLAUDE.md

Add a row to the Active Projects table in the root `CLAUDE.md`:

```markdown
| **MYPROJ** | My Project | `my-project/` | `your-org/my-project` |
```

### Step 5 — Create a project branch (optional)

For projects where you want to track state separately from `main`:

```bash
git checkout -b project/MYPROJ
# Commit project-specific orders, voyages, prompts
```

### Step 6 — Add to .gitignore (if local clone)

If the project repo is a separate git repository cloned into the workspace, add it to `.gitignore`:

```
my-project/
```

### Order Naming Convention

Orders for the new project follow the pattern `{TYPE}-{ACRONYM}-{YEAR}-{SEQ}`:

```
FTR-MYPROJ-2026-0001   # Feature order
BUG-MYPROJ-2026-0001   # Bug order
DOC-MYPROJ-2026-0001   # Documentation order
INT-MYPROJ-2026-0001   # Integration/deployment order
```

---

## 7. Managing Project State

### Order Lifecycle

Orders move through three directories:

```
.admiralty/queues/orders/    # Awaiting dispatch (queued)
.admiralty/orders/active/    # Currently being worked (in-flight)
.admiralty/orders/complete/  # Done
.admiralty/orders/failed/    # Failed
```

**Creating an order:** Drop a JSON file in `.admiralty/queues/orders/`. The dispatcher picks it up and moves it to `orders/active/` when a crew starts working on it.

**Order JSON format:**
```json
{
  "orderId": "FTR-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "type": "FTR",
  "role": "SHP",
  "title": "Add login feature",
  "description": "Implement user authentication...",
  "acceptanceCriteria": ["...", "..."],
  "dependsOn": [],
  "voyageId": "VOY-MYPROJ-2026-0001",
  "targetFiles": ["src/Auth/LoginController.cs"],
  "status": "QUEUED"
}
```

### Voyage Lifecycle

Voyages group related orders. Voyage state files live in:

```
.admiralty/voyages/active/     # Voyage in progress
.admiralty/voyages/complete/   # Voyage complete
```

### Queue Tiers

Orders can be placed in different queue tiers for priority control:

| Queue Directory | Priority | Use For |
|-----------------|----------|---------|
| `queues/explicit/` | Highest | Urgent/manual dispatch |
| `queues/security/` | High | Security fixes |
| `queues/bugs/` | High | Bug fixes |
| `queues/requests/` | Medium-High | Crew-generated requests |
| `queues/orders/` | Medium | Normal feature work |
| `queues/defects/` | Medium-Low | Defects from QA |
| `queues/breakdown/` | Low | Breakdown sub-tasks |
| `queues/high-level/` | Lowest | Planning/NAV tasks |
| `queues/escalations/` | Not dispatched | Requires Captain/QM review |

### Dependency Management

The `dependsOn` field in an order JSON accepts an array of order IDs that must be complete before this order dispatches:

```json
{
  "dependsOn": ["FTR-MYPROJ-2026-0001", "FTR-MYPROJ-2026-0002"]
}
```

The dispatcher checks all queues and holds orders with unsatisfied dependencies regardless of queue tier.

---

## 7.5 Captain Review Workflow (AWAITING_APPROVAL)

The Fleet Command Monitor v4.0 includes an **APPROVALS** panel that surfaces voyages, plans, and requirements that require Captain sign-off before work proceeds. This gives you a single place to see everything awaiting your decision, visible at the top of the dashboard.

### Overview

Any of the following artifact types can be placed in a "waiting for Captain" state:

| Artifact | Location | How status is set |
|----------|----------|-------------------|
| Voyage | `.admiralty/voyages/active/*.json` | Set `"status": "AWAITING_APPROVAL"` in the JSON |
| Plan | `.admiralty/plans/*.md` | Add YAML frontmatter with `status: awaiting-approval` |
| Requirement | `.admiralty/requirements/*.md` | Add YAML frontmatter with `status: awaiting-approval` |

When any of these are in `AWAITING_APPROVAL` state, the dashboard shows a yellow **APPROVALS — AWAITING CAPTAIN REVIEW** section immediately after the dispatcher block.

### Marking a Voyage for Review

Edit the voyage JSON in `.admiralty/voyages/active/`:

```json
{
  "id": "VOY-OTM-2026-0005",
  "project": "OTM",
  "title": "Operation Horizon",
  "status": "AWAITING_APPROVAL",
  "approvalNote": "Scope includes external API integration — approve before dispatch"
}
```

The `approvalNote` field is optional but recommended. It appears in the dashboard below the voyage ID so you know what decision is needed.

### Marking a Plan or Requirement for Review

Plans (`.admiralty/plans/*.md`) and requirements (`.admiralty/requirements/*.md`) use YAML-style frontmatter at the top of the file:

```markdown
---
status: awaiting-approval
approvalNote: "Architecture decision required: see Section 3"
project: OTM
title: "Navigation Module Redesign"
---

# PLAN-FTR-OTM-2026-0005 — Navigation Module Redesign

...rest of plan...
```

**Required frontmatter fields:**

| Field | Required | Description |
|-------|----------|-------------|
| `status` | Yes | Set to `awaiting-approval` (case-insensitive) to appear in APPROVALS panel |
| `project` | Yes | Project acronym (e.g. `OTM`, `ADM`). Used for grouping in the dashboard. |
| `title` | No | Short description shown in the dashboard alongside the filename. |
| `approvalNote` | No | Brief note on what decision or action is needed from the Captain. |

The frontmatter block must be the **first content in the file**, enclosed by `---` markers. The monitor reads the first 15 lines only, so keep the frontmatter compact.

### Approving an Item

Approval is a manual step — edit the file to change its status:

**Voyage:** Change `"status": "AWAITING_APPROVAL"` back to `"ACTIVE"` (or `"PENDING"` if not yet dispatched) and remove or update `approvalNote`.

**Plan or Requirement:** Change `status: awaiting-approval` to `status: active` in the frontmatter, or remove the frontmatter block entirely.

Once the status is no longer `awaiting-approval` / `AWAITING_APPROVAL`, the item disappears from the APPROVALS panel on the next dashboard refresh (every 5 seconds).

### Rejecting or Blocking

If you decide not to approve, you have several options depending on severity:

- **Minor revision needed:** Update the `approvalNote` to describe what changes are required, leave status as `AWAITING_APPROVAL`.
- **Blocking:** Move the voyage JSON to a different state (e.g. set `"status": "BLOCKED"`) and raise an escalation in `.admiralty/queues/escalations/` so the dispatcher holds all orders for that voyage.
- **Cancel:** Move the order or voyage to `.admiralty/orders/failed/` or `.admiralty/voyages/complete/` with an appropriate status.

### Dashboard Display

The APPROVALS section is shown in **yellow** to distinguish it from the red ESCALATIONS section. It appears only when there are pending items — if no voyages, plans, or requirements are in `AWAITING_APPROVAL` state, the section is hidden entirely.

Items are grouped by project acronym. Each item shows:
- Type (`[VOYAGE]`, `[PLAN]`, or `[REQ]`)
- Item ID or filename
- Project acronym
- Title (if set)
- Approval note (if set)
- Workspace-relative file path (clickable in VS Code terminal)

---

## 7.6 Budget Enforcement and Billing Mode

> **Planned** — Billing modes and budget enforcement are not yet implemented. The configuration schema below is the target design; the runtime does not currently consume these fields.

Admiralty v2.0.0 adds configurable billing modes and budget enforcement. These settings are stored in `.admiralty/config/workspace.json` and apply across all projects in the workspace.

### Billing configuration

Add a `billing` block to `workspace.json`:

```json
{
  "billing": {
    "mode": "track",
    "currency": "USD",
    "budgetPerVoyage": null,
    "budgetTotal": null,
    "alertThreshold": 0.8
  }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `mode` | string | Billing enforcement mode — see table below. |
| `currency` | string | Display currency for cost estimates (`USD`, `GBP`, `EUR`). Pricing is always in USD internally; display conversion is informational. |
| `budgetPerVoyage` | number or null | Maximum spend per voyage. `null` means no limit. |
| `budgetTotal` | number or null | Maximum cumulative spend across all voyages in the workspace. `null` means no limit. |
| `alertThreshold` | float (0–1) | Fraction of budget at which a dashboard warning is shown. Default: `0.8`. |

### Billing modes

| Mode | Behaviour |
|------|-----------|
| `track` *(default)* | Token usage is recorded and reported. No enforcement or dispatch blocking. |
| `enforce` | Dispatch is halted when `budgetPerVoyage` or `budgetTotal` is exceeded. Crews already running are not interrupted. |
| `estimate-first` | `admiralty dispatch` presents a pre-dispatch cost estimate and requires Captain confirmation before launching crews. |

### Approval workflow integration

The `admiralty approve` and `admiralty reject` commands provide CLI-level control over items in the APPROVALS panel, replacing the manual file-edit workflow documented in [7.5](#75-captain-review-workflow-awaiting_approval):

```bash
# Approve a voyage
admiralty approve --voyage VOY-MYPROJ-2026-0001 --note "Confirmed with stakeholders"

# Reject a voyage (moves to BLOCKED, creates escalation)
admiralty reject --voyage VOY-MYPROJ-2026-0001 --reason "Scope too broad — split required"

# Approve a plan
admiralty approve --plan .admiralty/plans/NAV-FTR-MYPROJ-2026-0001.md
```

Both commands update the artifact file in-place and refresh the dashboard state without requiring a dispatcher restart.

### Fleet pause and resume

Use `admiralty pause` and `admiralty resume` to temporarily hold fleet activity — for example, while reviewing an approval or investigating unexpected cost growth:

```bash
# Pause all running crews
admiralty pause --all

# Review usage mid-voyage
admiralty usage --voyage VOY-MYPROJ-2026-0001

# Resume when ready
admiralty resume --all
```

Paused crews retain their state and continue from where they left off after `resume`.

### Budget enforcement workflow

Typical enforce-mode workflow:

1. Set `mode: "enforce"` and `budgetPerVoyage: 5.00` in `workspace.json`.
2. Before dispatching, estimate cost: `admiralty estimate --voyage VOY-MYPROJ-2026-0001`.
3. If the estimate exceeds the budget, reduce scope or adjust `budgetPerVoyage` before proceeding.
4. Dispatch: `admiralty dispatch --max-crews 3`.
5. If a voyage breaches the budget mid-run, the dispatcher halts new crew assignments. Active crews complete their current iteration.
6. Review usage: `admiralty usage --voyage VOY-MYPROJ-2026-0001`.
7. Adjust budget or voyage scope, then resume: `admiralty resume --all`.

---

## 8. Commercial Licensing Strategy

### Current State

Admiralty is distributed as:

1. **Git submodule** — `git submodule add https://github.com/tavisbasing/Admiralty .admiralty`
2. **pip from GitHub** — `pip install git+https://github.com/tavisbasing/Admiralty.git@main`

Both are free to use for any purpose within the terms of the GitHub repo visibility.

### Distribution Options

#### Option A — Public GitHub (current)

- Anyone with internet access can `pip install` or add as a submodule
- Gate: GitHub repo must be public (or user must have read access)
- No license enforcement beyond repo access control

**Suitable for:** Open source, personal use, trusted commercial customers

#### Option B — GitHub Package Registry

```bash
# Install from private GitHub Packages
pip install admiralty --index-url https://pip.pkg.github.com/tavisbasing/
```

- Gate: GitHub personal access token required
- Token can be revoked per user/customer
- Still no in-software license validation

**Suitable for:** Semi-commercial with controlled distribution

#### Option C — Private PyPI Registry

```bash
# Customer configures their pip to point at your registry
pip install admiralty --index-url https://your-registry.example.com/simple/
```

Options: self-hosted (devpi, Artifactory), hosted (Gemfury, Cloudsmith)

**Suitable for:** Commercial SaaS product with customer accounts

#### Option D — License Key Validation (future)

The `admiralty/__init__.py` includes an extension point for startup license validation. Implementation would:

1. Read a license key from env var (`ADMIRALTY_LICENSE_KEY`) or config file
2. Validate against a central server or local cryptographic check
3. Raise `SystemExit` with clear message if invalid

```python
# admiralty/__init__.py — future extension point
def _validate_license():
    key = os.environ.get("ADMIRALTY_LICENSE_KEY")
    if key is None:
        raise SystemExit("[Admiralty] License key required. Set ADMIRALTY_LICENSE_KEY.")
    # validate key...
```

**Suitable for:** Full commercial product with per-seat/per-org licensing

### Submodule vs pip: Trade-offs

| Factor | Submodule | pip |
|--------|-----------|-----|
| Version pinning | Exact commit hash | Tag or `@main` |
| Update mechanism | `git submodule update --remote` | `pip install --upgrade` |
| Source access | Full (crew scripts visible) | Full (scripts in `.admiralty/core/`) |
| Offline use | Yes (after initial clone) | Yes (after initial install) |
| Multi-project workspace | Works directly | Works via CLI delegation |
| License gating | GitHub repo access | Package registry access + optional key |
| Customer experience | Developer-friendly | Simpler install story |

**Recommendation for commercial customers:** Offer pip as the primary install method (simpler, controlled via registry). Offer submodule as an advanced option for customers who want version pinning or air-gapped environments.

### Versioning for Commercial Deployment

Tag every release:

```bash
git tag v2.0.0 -m "Fleet Command System v2.0.0"
git push origin v2.0.0
```

Customers can pin to a specific version:

```bash
# Submodule — pin to tag
git submodule add https://github.com/tavisbasing/Admiralty.git@v2.0.0 .admiralty

# pip — pin to tag
pip install git+https://github.com/tavisbasing/Admiralty.git@v2.0.0
```

### Roadmap to Full Commercial Product

| Phase | What | How |
|-------|------|-----|
| **Now** | pip install from GitHub | `pip install git+https://...` |
| **Near-term** | GitHub Package Registry | Token-gated pip index |
| **Near-term** | Proper pip release | PyPI or private registry |
| **Future** | License key validation | `ADMIRALTY_LICENSE_KEY` env var |
| **Future** | Hosted SaaS | Crews run in cloud, web UI |

---

## 9. Maintenance Workflows

### Updating Core Scripts

Core scripts live in `.admiralty/core/`. They are part of both the pip package (via submodule in user workspaces) and the framework repo.

```bash
git checkout -b admiralty/fix-{description}
# Edit .admiralty/core/fleet-runner.py or crew.py etc.
# Test manually
git commit -m "fix: ..."
git push -u origin admiralty/fix-{description}
# PR → main
```

When updating core scripts, preserve these invariants:
- Token tracking pipeline must not break (stop hook → usage JSON → crew.py → aggregation)
- All hooks must remain fail-open (wrapped in `try/except`, `exit(0)` on error)
- Captain session safety: all hooks check `ADMIRALTY_CREW` env var before acting
- `ADMIRALTY_CREW` env var remains the single gate for hook activation

### Updating Hooks

Hooks live in `.admiralty/hooks/`. They are injected into Claude Code sessions via `.claude/settings.json` in the user's workspace.

Hook files:
- `fleet-stop-hook.py` — multi-pass iterations (Ralph Wiggum) + token usage capture
- `fleet-pretool-hook.py` — role permission enforcement at write/edit time
- `fleet-posttool-hook.py` — activity tracking, heartbeat, file counter
- `fleet-notification-hook.py` — error/warning capture

When updating hooks:
1. Test with a live crew session to confirm hooks fire and fail gracefully
2. Verify `ADMIRALTY_CREW` check is present and correct
3. Verify fail-open: introduce a deliberate error and confirm crew continues

### Adding a New Role

1. Add role definition to `.admiralty/config/role-paths.json` with `prohibited` and `outputs`
2. Add role entry to `CHAIN-OF-COMMAND.md` Role-Based Model Selection table
3. Add to `.admiralty/CLAUDE.md` component table
4. Add per-project override in `config/projects/{ACRONYM}.json` if needed
5. Update `crew.py` role-to-model mapping if the new role uses a non-default model

### Monitoring Fleet Health

```bash
# Live dashboard
admiralty status

# One-shot status
admiralty status --once

# Compact view (one line per crew)
admiralty status --once --compact

# Token usage summary
admiralty usage --summary

# Usage for a specific voyage
admiralty usage --voyage VOY-ADM-2026-0001

# Full usage report
admiralty usage --report --output .admiralty/reports/usage-report.md
```

### Cleanup After a Voyage

```bash
# Stop rogue processes and reset stale crew state
admiralty cleanup

# Or with dispatch (cleanup then launch)
admiralty dispatch --cleanup --max-crews 5
```

Cleanup removes:
- Stale `crew.lock` files
- Orphaned crew processes (by PID)
- Resets `state.json` for idle crews

### Handling Blocked Orders

When an order is stuck or a crew is blocked:

1. Check the escalation queue: `.admiralty/queues/escalations/`
2. Review the crew's progress: `.admiralty/crews/crewN/progress.md`
3. Review the crew's activity: `.admiralty/crews/crewN/activity.txt`
4. Resolve the escalation JSON (set `status: "RESOLVED"`, add `resolution`)
5. The dispatcher automatically unblocks when the escalation is resolved

For blocking escalations (those with `"blocking": true`), all orders for the same voyage are halted until the Captain/QM resolves the escalation.

### Managing Crew Iterations

Each crew runs up to `ADMIRALTY_MAX_ITERATIONS` iterations (default: 25) via the Ralph Wiggum stop hook pattern. The hook reads the crew's `ralph-state.md` to determine whether to re-invoke Claude or declare completion.

To adjust the limit per-order, set `maxIterations` in the order JSON:
```json
{
  "maxIterations": 10
}
```

### Post-Voyage Verification

After a voyage completes, run verification to confirm builds and tests pass:

```bash
admiralty verify --voyage VOY-ADM-2026-0001
```

To skip re-running tests and reuse existing results:
```bash
admiralty verify --voyage VOY-ADM-2026-0001 --skip-tests
```

---

## 10. Workspace Backup Strategy

`admiralty backup` and `admiralty restore` let you snapshot and recover all project state (orders, voyages, plans, usage records, config) from a single ZIP archive. As a framework owner managing ADM self-development work, use backups at the natural checkpoints described below.

### Before every cleanup

`admiralty cleanup` automatically creates a full backup before it runs — no manual step required. The backup path is printed to stdout:

```
[Admiralty] Auto-backup created: /workspace/admiralty-backups/admiralty-backup-all-2026-03-30-143000.zip
```

Backups accumulate in `./admiralty-backups/`. Prune old archives periodically if disk space is a concern:

```bash
# List to inspect before deleting
admiralty backup --list

# Remove backups older than 30 days (example — adjust to taste)
find ./admiralty-backups/ -name "*.zip" -mtime +30 -delete
```

### Before cutting a release

Take a snapshot of project state before any release-prep steps that might touch orders or voyages:

```bash
admiralty backup
```

This gives you a recovery point if you need to roll back the workspace to its pre-release state.

### Before a migration or machine transfer

To transfer project state to a new machine or workspace:

1. On the source machine:
   ```bash
   admiralty backup --output /tmp/transfer/
   ```
2. Copy the ZIP to the target machine.
3. On the target machine, after running `admiralty init`:
   ```bash
   admiralty restore /tmp/transfer/admiralty-backup-all-2026-03-30-143000.zip
   ```

### Per-project backups in a multi-project workspace

When you want to share a project's state with a collaborator without exposing other projects:

```bash
admiralty backup --project OTM --output /tmp/otm-handoff/
```

Only files associated with `OTM` are included. The collaborator restores with:

```bash
admiralty restore /tmp/otm-handoff/admiralty-backup-OTM-2026-03-30-143000.zip --project OTM
```

### Disaster recovery

If workspace state is accidentally deleted or corrupted:

```bash
# Preview first
admiralty restore admiralty-backup-all-2026-03-30-143000.zip --dry-run

# Restore, skipping any files already in place
admiralty restore admiralty-backup-all-2026-03-30-143000.zip

# Or overwrite everything from the snapshot
admiralty restore admiralty-backup-all-2026-03-30-143000.zip --force
```

The `--merge` flag is useful when recovering partial damage — it keeps whichever copy of each file is newer, so undamaged files are not overwritten:

```bash
admiralty restore admiralty-backup-all-2026-03-30-143000.zip --merge
```

### What is and is not in a backup

**Included** (project state — changes with usage):
- All orders (`active/`, `complete/`, `failed/`)
- All voyages (`active/`, `complete/`)
- Active prompts, plans, handoffs, requirements, reports
- Token usage records (`usage/orders/`)
- All config files (`config/workspace.json`, `config/projects.json`, `config/projects/*.json`)
- `CLAUDE.md`, `BACKLOG.md`, `VOYAGE-STATUS.md`

**Excluded** (runtime / framework — not project state):
- `.admiralty/core/` — framework scripts (provided by pip or submodule)
- `.admiralty/hooks/` — framework hooks
- `.admiralty/crews/` — ephemeral crew runtime state
- `.admiralty/logs/`, `.admiralty/temp/` — ephemeral artifacts
- `.admiralty/queues/` — regenerated by the dispatcher at runtime

See [CLI-REFERENCE.md — admiralty backup](CLI-REFERENCE.md#admiralty-backup) for the complete flag reference.

---

## 11. CLI Reference

### `admiralty dispatch`

Launch fleet crews from the dispatch queue.

```
admiralty dispatch [--max-crews N] [--cleanup] [--stagger-delay S] [--timeout M]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--max-crews N` | 5 | Maximum concurrent crews |
| `--cleanup` | false | Run cleanup before dispatching |
| `--stagger-delay S` | 30 | Seconds between crew launches |
| `--timeout M` | 90 | Per-crew timeout in minutes |

### `admiralty cleanup`

Stop rogue processes and reset stale crew state.

```
admiralty cleanup
```

### `admiralty status`

Display fleet status dashboard.

```
admiralty status [--once] [--compact]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--once` | false | One-shot display (no loop); when omitted, the dashboard loops |
| `--compact` | false | One-line summary per crew |

### `admiralty usage`

Report token usage and estimated cost.

```
admiralty usage [--voyage VOY-ID | --order ORDER-ID | --report [--output PATH]]
```

| Flag | Description |
|------|-------------|
| *(none)* | Print overall summary |
| `--voyage VOY-ID` | Per-voyage token breakdown |
| `--order ORDER-ID` | Per-order token breakdown |
| `--report` | Generate full markdown report |
| `--output PATH` | Output path for `--report` |

### `admiralty crew`

Operate an individual crew instance.

```
admiralty crew --crew {1-5} [--status | --watch | --cleanup]
```

| Flag | Description |
|------|-------------|
| `--crew N` | Crew number (1–5, required) |
| `--status` | Show crew status |
| `--watch` | Watch crew progress live |
| `--cleanup` | Stop this crew's process |

### `admiralty verify`

Run post-voyage build and test verification.

```
admiralty verify [--voyage VOY-ID] [--skip-tests]
```

| Flag | Description |
|------|-------------|
| `--voyage VOY-ID` | Voyage ID to verify |
| `--skip-tests` | Reuse existing test results |

### `admiralty backup`

Create or list project state backups.

```
admiralty backup [--project ACRONYM] [--output PATH] [--list]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--project ACRONYM` | all | Only include files for this project acronym |
| `--output PATH` | `./admiralty-backups/` | Output directory |
| `--list` | false | List available backups instead of creating one |

### `admiralty restore`

Restore project state from a backup archive.

```
admiralty restore BACKUP_FILE [--project ACRONYM] [--force] [--merge] [--dry-run]
```

| Flag | Default | Description |
|------|---------|-------------|
| `BACKUP_FILE` | *(required)* | Path to the backup ZIP |
| `--project ACRONYM` | all | Only restore files for this project acronym |
| `--force` | false | Overwrite existing files |
| `--merge` | false | Keep the newer file by mtime |
| `--dry-run` | false | Preview without writing |

### `admiralty init`

Scaffold a new Admiralty workspace.

```
admiralty init --project ACRONYM [--directory PATH] [--force]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--project ACRONYM` | *(required)* | Project acronym (e.g. `OTM`, `PSG`) |
| `--directory PATH` | current dir | Workspace directory |
| `--force` | false | Overwrite existing `.admiralty/` |

Creates:
- Full `.admiralty/` directory structure with all queue/order/voyage directories
- `config/workspace.json`, `config/projects.json`, `config/projects/{ACRONYM}.json`
- `CLAUDE.md` with Quartermaster persona
- `.gitignore` with standard exclusions

### `admiralty version`

Print the installed Admiralty version.

```
admiralty version
```

---

## Environment Variables (Crew Sessions)

These are injected by the Fleet Admiral into crew subprocesses. Documented here for completeness when debugging or extending the system.

| Variable | Purpose |
|----------|---------|
| `ADMIRALTY_CREW` | Crew number (1–5). Activates hooks. Must not be set in Captain sessions. |
| `ADMIRALTY_ORDER` | Current order ID |
| `ADMIRALTY_PROJECT` | Project acronym (e.g. `ADM`, `OTM`) |
| `ADMIRALTY_REPO_PATH` | Managed repo clone path — crew's working directory |
| `ADMIRALTY_TEMP` | Centralized temp directory |
| `ADMIRALTY_VOYAGE_BRANCH` | Voyage branch name |
| `ADMIRALTY_MAX_ITERATIONS` | Max stop-hook iterations (default: 25) |
| `ADMIRALTY_COMPLETION_PROMISE` | Promise tag crews use to signal task completion |

---

## 12. Collaborator Access Management

Admiralty v2.0.0 enforces collaborator-based licence validation on CLI startup. Users must be listed as GitHub collaborators on `tavisbasing/Admiralty` to run any CLI command (except `admiralty version` and `admiralty init`).

### How It Works

1. On first run, the user is prompted for a GitHub Personal Access Token (PAT) with `repo` scope.
2. The token and username are cached in `~/.admiralty/auth.json` (mode 0600).
3. On every subsequent CLI invocation, the GitHub API is called to confirm collaborator status.
4. If validation fails, the CLI exits with a licensing message.
5. If the network is unavailable, a grace period of 7 days (configurable) is applied.

### Adding a Collaborator (Granting Access)

```bash
# Via GitHub web UI
# Settings → Collaborators → Add people → enter GitHub username

# Via GitHub CLI
gh api repos/tavisbasing/Admiralty/collaborators/{username} -X PUT -f permission=pull
```

The user will be emailed an invitation. They must accept it before the collaborator check passes.

### Removing a Collaborator (Revoking Access)

```bash
# Via GitHub web UI
# Settings → Collaborators → remove user

# Via GitHub CLI
gh api repos/tavisbasing/Admiralty/collaborators/{username} -X DELETE
```

Revocation takes effect on the user's next CLI invocation (after their cached grace period expires, if network is unavailable).

### Environment Variables

| Variable | Purpose |
|----------|---------|
| `ADMIRALTY_SKIP_AUTH=1` | Bypass auth check entirely (for CI/CD pipelines) |
| `ADMIRALTY_OFFLINE_GRACE_DAYS=N` | Days offline before grace period expires (default: 7) |

### Cache File

The auth cache is stored at `~/.admiralty/auth.json`:

```json
{
  "token": "ghp_...",
  "username": "octocat",
  "last_verified": "2026-03-30T12:00:00Z"
}
```

The file is created with mode `0600` (owner read/write only). To reset auth (e.g. after changing PAT), delete this file:

```bash
rm ~/.admiralty/auth.json
```

> **Note (Windows):** Python's `os.chmod` has limited effect on Windows. Ensure the `~/.admiralty/` directory is appropriately restricted via NTFS permissions or keep the machine user-isolated.

> **CI/CD:** Always set `ADMIRALTY_SKIP_AUTH=1` in automated pipelines. Without it, the CLI will hang waiting for PAT input.

---

*Admiralty Fleet Command System — v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
