# Admiralty — Troubleshooting

Common errors and how to resolve them.

---

## Contents

- [Installation and PATH issues](#installation-and-path-issues)
  - [E01 — `admiralty: command not found`](#e01--admiralty-command-not-found)
  - [E02 — `claude: command not found`](#e02--claude-command-not-found)
  - [E03 — Wrong Python version](#e03--wrong-python-version)
- [Authentication and Licence](#authentication-and-licence)
  - [E04 — Licence key activation failed](#e04--licence-key-activation-failed)
  - [E05 — `ANTHROPIC_API_KEY` missing or invalid](#e05--anthropic_api_key-missing-or-invalid)
  - [E06 — Trial expired — access blocked](#e06--trial-expired--access-blocked)
  - [E07 — Licence expired or grace period exceeded](#e07--licence-expired-or-grace-period-exceeded)
- [Dispatch and Order Problems](#dispatch-and-order-problems)
  - [E08 — No orders found — dispatch exits immediately](#e08--no-orders-found--dispatch-exits-immediately)
  - [E09 — Orders held: unsatisfied dependencies](#e09--orders-held-unsatisfied-dependencies)
  - [E10 — Crew launches but immediately stops](#e10--crew-launches-but-immediately-stops)
  - [E11 — Crew stuck: no progress for a long time](#e11--crew-stuck-no-progress-for-a-long-time)
  - [E12 — Crew crashes: CRASHED or FAILED status](#e12--crew-crashes-crashed-or-failed-status)
  - [E13 — Trial: `--max-crews` capped unexpectedly](#e13--trial---max-crews-capped-unexpectedly)
  - [E14 — Trial: single-project cap exceeded](#e14--trial-single-project-cap-exceeded)
- [State and Stale Locks](#state-and-stale-locks)
  - [E15 — Stale lock files from a previous run](#e15--stale-lock-files-from-a-previous-run)
  - [E16 — Dispatcher shows STOPPED but process is running](#e16--dispatcher-shows-stopped-but-process-is-running)
- [Git and Repo Problems](#git-and-repo-problems)
  - [E17 — Crew fails: cannot push branch](#e17--crew-fails-cannot-push-branch)
  - [E18 — `admiralty init` fails: `.admiralty/` already exists](#e18--admiralty-init-fails-admiralty-already-exists)
- [Monitoring and Usage](#monitoring-and-usage)
  - [E19 — `admiralty usage` shows no data](#e19--admiralty-usage-shows-no-data)
  - [E20 — `admiralty status` shows no crews or blank dashboard](#e20--admiralty-status-shows-no-crews-or-blank-dashboard)

---

## Installation and PATH issues

### E01 — `admiralty: command not found`

**Cause:** pip installed the `admiralty` entry point into a `bin` or `Scripts` directory that is not on your `PATH`.

**Fix:**

*Linux / macOS:*
```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

*Windows (PowerShell):*

Add `%APPDATA%\Python\PythonXX\Scripts` to your user `PATH` via System > Advanced system settings > Environment Variables. Replace `XX` with your Python version (e.g. `311` for Python 3.11).

*Virtual environment:*

If you installed into a virtual environment, activate it first:
```bash
source .venv/bin/activate   # Linux/macOS
.venv\Scripts\activate      # Windows
admiralty version
```

**Verify the fix:**
```bash
which admiralty       # Linux/macOS
where admiralty       # Windows
admiralty version
```

---

### E02 — `claude: command not found`

**Cause:** Claude Code is not installed or not on your `PATH`.

**Fix:**

Install Claude Code from [claude.ai/code](https://claude.ai/code) and follow the installation guide for your platform. After installation, verify:

```bash
claude --version
```

If `claude` still is not found, check the Claude Code documentation for PATH setup on your platform. Common locations:
- macOS: `~/.claude/bin/` or a path added during install
- Windows: check the installer output for the installation path

Admiralty crew sessions invoke `claude` as a subprocess — if `claude` is not on PATH, all crew dispatch will fail.

---

### E03 — Wrong Python version

**Cause:** Admiralty requires Python 3.9 or later. Some systems have Python 2 as the default `python` command.

**Fix:**

Check your version:
```bash
python --version
python3 --version
```

If your system uses `python3`, install Admiralty with:
```bash
python3 -m pip install git+https://github.com/tavisbasing/Admiralty.git@main
```

Or create a virtual environment with the correct Python:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install git+https://github.com/tavisbasing/Admiralty.git@main
```

---

## Authentication and Licence

> **Note:** Current releases (v2.0.0) use GitHub collaborator/PAT-based authentication. The licence-key system described in E04 is planned for a future release. If you encounter access errors on v2.0.0, verify your GitHub PAT is valid and stored at `~/.admiralty/auth.json`.

### E04 — Licence key activation failed (v2.0.0+)

**Symptom:**
```
[Admiralty] Licence activation failed: invalid key format
```
or
```
[Admiralty] Licence activation failed: checksum mismatch
```

**Cause:** The key string was entered incorrectly, contains extra spaces, or has been corrupted.

**Fix:**

1. Copy the key exactly as provided — it is case-sensitive
2. Ensure there are no leading or trailing spaces
3. The key format is `ADM-{TIER}-{ORG_HASH}-{EXPIRY}-{CHECKSUM}`, for example:
   ```
   ADM-TEAM-a1b2c3d4-20270331-x9y8z7
   ```
4. Try passing the key explicitly in quotes:
   ```bash
   admiralty licence activate "ADM-TEAM-a1b2c3d4-20270331-x9y8z7"
   ```

If the key was recently issued and activation still fails, contact [admiralty@tech127.com](mailto:admiralty@tech127.com) with the exact error message.

---

### E05 — `ANTHROPIC_API_KEY` missing or invalid

**Symptom:** Crews start but immediately fail, or the dispatcher exits with an API authentication error.

**Cause:** The `ANTHROPIC_API_KEY` environment variable is not set, is set to a placeholder value, or the key does not have access to the required Claude models (Sonnet 4.6, Haiku 4.5, Opus 4.7).

**Fix:**

1. Verify the variable is set:
   ```bash
   echo $ANTHROPIC_API_KEY   # Linux/macOS
   echo %ANTHROPIC_API_KEY%  # Windows cmd
   ```
2. If blank, set it:
   ```bash
   export ANTHROPIC_API_KEY=sk-ant-api03-...
   ```
3. Add to your shell profile to persist across sessions:
   ```bash
   echo 'export ANTHROPIC_API_KEY=sk-ant-api03-...' >> ~/.bashrc
   source ~/.bashrc
   ```
4. Verify the key has model access in your [Anthropic Console](https://console.anthropic.com).

---

### E06 — Trial expired — access blocked

**Symptom:**
```
[Admiralty Trial] Your 14-day trial has expired.
Only 'admiralty version' and 'admiralty licence' are available.
To continue: https://admiraltyai.com/pricing
```

**Cause:** The 14-day trial period has elapsed.

**Fix:**

Activate a licence key to resume all commands:
```bash
admiralty licence activate <YOUR-KEY>
```

If you do not have a key yet, see [PRICING.md](PRICING.md) for options. The `admiralty licence` and `admiralty version` commands remain available without a key.

---

### E07 — Licence expired or grace period exceeded

**Symptom:**
```
[Admiralty] Licence expired: ADM-TEAM-... expired on 2026-12-31.
Renew at: https://admiraltyai.com/pricing
```

**Cause:** The licence key's expiry date has passed and the 30-day offline grace period has also elapsed.

**Fix:**

1. Obtain a renewed licence key from your account or contact [admiralty@tech127.com](mailto:admiralty@tech127.com)
2. Activate the new key:
   ```bash
   admiralty licence deactivate
   admiralty licence activate <NEW-KEY>
   ```

If you are within the 30-day grace period (last network validation was within 30 days), commands continue to work. The `admiralty licence status` output shows the days remaining in the grace period.

---

## Dispatch and Order Problems

### E08 — No orders found — dispatch exits immediately

**Symptom:** `admiralty dispatch` starts and immediately exits with:
```
[Admiralty] No dispatchable orders found. Exiting.
```

**Cause:** One or more of the following:
- Queue directories are empty
- All queued orders have unsatisfied `dependsOn` dependencies
- Order files are not valid JSON or are in the wrong directory

**Fix:**

1. Verify the order file is in the correct queue directory:
   ```bash
   ls .admiralty/queues/orders/
   ```
   Order files must be directly in the queue directory — not in a subdirectory.

2. Validate the order JSON:
   ```bash
   python -c "import json; json.load(open('.admiralty/queues/orders/YOUR-ORDER-ID.json'))"
   ```

3. Check `dependsOn` — if an order lists an incomplete order as a dependency, it will not dispatch:
   ```bash
   cat .admiralty/queues/orders/YOUR-ORDER-ID.json | python -c "import json,sys; print(json.load(sys.stdin).get('dependsOn'))"
   ```
   Check whether the listed dependency is in `.admiralty/orders/complete/`.

4. Check all queue tiers, not just `queues/orders/`:
   ```bash
   ls .admiralty/queues/bugs/
   ls .admiralty/queues/requests/
   ```

---

### E09 — Orders held: unsatisfied dependencies

**Symptom:** The `QUEUES` panel in `admiralty status` shows orders pending, but dispatch does not pick them up. The lifecycle log may show `HELD: dependency not met`.

**Cause:** The order's `dependsOn` array references one or more orders that are not yet in `orders/complete/`.

**Fix:**

1. Identify which dependency is missing:
   ```bash
   cat .admiralty/queues/orders/YOUR-ORDER-ID.json
   ```
   Check the `dependsOn` list.

2. Verify the dependency status:
   ```bash
   ls .admiralty/orders/complete/   # should contain the dependency
   ls .admiralty/orders/active/     # still in progress
   ls .admiralty/orders/failed/     # failed — need to retry or remove dependency
   ```

3. If the dependency is in `failed/`, either fix and re-queue it or remove the dependency from the dependent order and re-queue.

---

### E10 — Crew launches but immediately stops

**Symptom:** A crew appears briefly in `admiralty status` then transitions to IDLE or FAILED within seconds.

**Cause:** Most commonly:
- `ANTHROPIC_API_KEY` not set (see [E05](#e05--anthropic_api_key-missing-or-invalid))
- `claude` not on PATH (see [E02](#e02--claude-command-not-found))
- Invalid or malformed order prompt
- Permission denied writing to crew directory

**Fix:**

1. Check the crew's state file:
   ```bash
   cat .admiralty/crews/crew1/state.json
   ```
2. Check the crew's activity log:
   ```bash
   cat .admiralty/crews/crew1/activity.txt
   ```
3. Check for errors in the crew's progress file:
   ```bash
   cat .admiralty/crews/crew1/progress.md
   ```
4. Verify API key and Claude Code install as described in E05 and E02.

---

### E11 — Crew stuck: no progress for a long time

**Symptom:** A crew shows RUNNING status but the activity timestamp has not updated for 30+ minutes.

**Cause:** The crew may be:
- Waiting for a long API response
- In a loop retrying a failing action
- Blocked on a decision and unable to escalate

**Fix:**

1. Check recent activity:
   ```bash
   cat .admiralty/crews/crew1/activity.txt
   ```
2. Check for escalations raised by the crew:
   ```bash
   ls .admiralty/queues/escalations/
   ```
   If there is a blocking escalation, review and resolve it (see [OWNER-GUIDE.md](OWNER-GUIDE.md#75-captain-review-workflow-awaiting_approval)).
3. If the crew has genuinely stalled, stop and re-dispatch:
   ```bash
   admiralty crew --crew 1 --cleanup
   admiralty dispatch --max-crews 1
   ```

---

### E12 — Crew crashes: CRASHED or FAILED status

**Symptom:** `admiralty status` shows a crew in CRASHED or FAILED state.

**Cause:** The crew exceeded the maximum iteration count, hit an unrecoverable error, or the `claude` process exited unexpectedly.

**Fix:**

1. Check the ralph-state file for the final iteration count:
   ```bash
   cat .admiralty/crews/crew1/ralph-state.md
   ```
2. Check the order's completion metadata:
   ```bash
   cat .admiralty/orders/failed/YOUR-ORDER-ID.json
   ```
3. Review the progress file for the last known action:
   ```bash
   cat .admiralty/crews/crew1/progress.md
   ```
4. Clean up and retry:
   ```bash
   admiralty cleanup
   # Move the order back to the queue if needed
   mv .admiralty/orders/failed/YOUR-ORDER-ID.json .admiralty/queues/orders/
   admiralty dispatch --max-crews 3
   ```

---

### E13 — Trial: `--max-crews` capped unexpectedly

**Symptom:**
```
[Admiralty] Trial mode allows 3 max crews. Capping --max-crews from 5 to 3.
```

**Cause:** You are in trial mode and requested more crews than the trial limit (3).

**Fix:**

This is expected behaviour — not an error. Trial mode limits dispatch to 3 concurrent crews.

To remove this limit, activate a Team or Enterprise licence:
```bash
admiralty licence activate <YOUR-KEY>
```

Then re-dispatch with the desired crew count:
```bash
admiralty dispatch --max-crews 5
```

---

### E14 — Trial: single-project cap exceeded

**Symptom:**
```
[Admiralty Trial] Single-project limit exceeded.
  Your workspace has 3 projects configured.
  Trial mode supports 1 project only.

  To unlock unlimited projects: https://admiraltyai.com/pricing
```

**Cause:** Your workspace `projects.json` contains more than 1 project and you are in trial mode.

**Fix:**

Either remove the extra projects from `projects.json` to stay within trial limits, or activate a paid licence key:
```bash
admiralty licence activate <YOUR-KEY>
```

Solo tier allows up to 3 projects; Team and Enterprise allow unlimited.

---

## State and Stale Locks

### E15 — Stale lock files from a previous run

**Symptom:** `admiralty status` shows crews as RUNNING but no actual crew processes are active, or `admiralty dispatch` skips slots that appear occupied.

**Cause:** A previous dispatcher run terminated without cleaning up `crew.lock` and `pid.txt` files.

**Fix:**

```bash
admiralty cleanup
```

This stops any orphaned processes and resets stale lock and state files. Safe to run at any time — does not affect orders that are genuinely in progress.

After cleanup:
```bash
admiralty dispatch --max-crews 5
```

---

### E16 — Dispatcher shows STOPPED but process is running

**Symptom:** `admiralty status` shows `DISPATCHER: STOPPED` but you know dispatch is running.

**Cause:** The dispatcher PID file is missing, stale, or the fleet monitor cannot read the dispatcher state file.

**Fix:**

1. Check whether the dispatcher process is actually running:
   ```bash
   ps aux | grep fleet-runner   # Linux/macOS
   tasklist | findstr fleet-runner   # Windows
   ```
2. If the process is running but the dashboard shows STOPPED, there may be a PID file issue. Run cleanup and re-dispatch:
   ```bash
   admiralty cleanup
   admiralty dispatch --max-crews 5
   ```

---

## Git and Repo Problems

### E17 — Crew fails: cannot push branch

**Symptom:** A crew's final step fails with a Git push error, or the order completes but no branch appears in the remote.

**Cause:** One or more of the following:
- The Admiralty host does not have push permissions for the target repository
- SSH key or HTTPS credentials not configured
- The voyage branch already exists with conflicting history

**Fix:**

1. Verify push access from the Admiralty host:
   ```bash
   git push origin HEAD --dry-run
   ```
2. For HTTPS remotes, ensure a credential helper is configured:
   ```bash
   git config --global credential.helper store
   ```
3. For SSH remotes, verify the SSH key is added to your Git host and the key is loaded:
   ```bash
   ssh -T git@github.com
   ```
4. If the voyage branch has a conflict, delete it from the remote and re-dispatch:
   ```bash
   git push origin --delete voyage/YOUR-VOYAGE-BRANCH
   ```

---

### E18 — `admiralty init` fails: `.admiralty/` already exists

**Symptom:**
```
[Admiralty] .admiralty/ already exists. Use --force to overwrite.
```

**Cause:** The workspace was already initialised.

**Fix:**

If you want to re-scaffold the workspace (this will overwrite existing config):
```bash
admiralty init --project MYPROJ --force
```

If you just need to add a new project to an existing workspace, edit `.admiralty/config/projects.json` and `.admiralty/config/projects/NEWPROJ.json` directly rather than re-running init.

---

## Monitoring and Usage

### E19 — `admiralty usage` shows no data

**Symptom:** `admiralty usage --summary` returns `No usage data found` or shows zero tokens and zero cost.

**Cause:** Usage data is captured by the stop hook at the end of each crew session. If the hook did not run (e.g. the crew was interrupted, or the hook script is missing), usage files will not exist.

**Fix:**

1. Check whether usage files were created for completed orders:
   ```bash
   ls .admiralty/usage/orders/
   ```
2. Verify the stop hook is present and executable:
   ```bash
   ls .admiralty/hooks/fleet-stop-hook.py
   ```
3. Ensure `ADMIRALTY_CREW` is set when dispatching — the stop hook only captures usage when this variable is set. This is injected automatically by the dispatcher.
4. If usage files are absent for a completed order, the session may have been terminated before the hook fired. No usage data is available for those orders — this is expected for interrupted sessions.

---

### E20 — `admiralty status` shows no crews or blank dashboard

**Symptom:** `admiralty status --once` shows an empty dashboard with no crew slots, or exits immediately.

**Cause:** One or more of the following:
- The crew directories do not exist (workspace not initialised)
- `admiralty status` is being run from the wrong directory
- The fleet monitor script is missing

**Fix:**

1. Ensure you are in the workspace root (where `.admiralty/` is a direct subdirectory):
   ```bash
   ls .admiralty/
   ```
2. Verify crew directories exist:
   ```bash
   ls .admiralty/crews/
   ```
   If not present, re-run `admiralty init --project <ACRONYM>`.
3. Verify the fleet monitor is present:
   ```bash
   ls .admiralty/core/fleet_monitor.py
   ```
   If missing, re-install or update Admiralty:
   ```bash
   pip install --upgrade git+https://github.com/tavisbasing/Admiralty.git@main
   ```

---

*Admiralty Fleet Command System v2.0.0 — If your issue is not listed here, see [SUPPORT.md](SUPPORT.md) for how to get help.*
