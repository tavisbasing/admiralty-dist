# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. See LICENSE for full terms.

"""
admiralty.licence — licence-key activation / validation / storage.

Public API:
    activate(key) -> LicenceRecord     # online verify + persist
    validate(strict=False) -> LicenceRecord
                                       # fast path: cached-OK if recent;
                                       # online re-validate beyond 24h;
                                       # raises LicenceError on hard fail.
                                       # When grace fallback is used,
                                       # record.used_grace == True so the
                                       # CLI can render a warning banner.
    deactivate() -> None               # local-side deactivation
    status() -> LicenceRecord | None   # read-only inspection

Backend: Polar.sh (selected in PLAN-VOY-ADM-2026-0031.md). All Polar
calls go through admiralty.licence.client; storage is at
~/.admiralty/licence.json (mode 0600) signed with a per-customer
keychain secret. Offline grace: 14 days from last successful online
validation.

Config (env vars):
    ADMIRALTY_LICENCE_API_BASE   default https://api.polar.sh/v1
    ADMIRALTY_LICENCE_KEY        non-interactive activation (CI/CD)
    ADMIRALTY_LICENCE_GRACE_DAYS default 14 (test override only)
"""

from __future__ import annotations

from datetime import datetime, timezone

from admiralty.licence.client import PolarClient, PolarError
from admiralty.licence.errors import (
    LicenceError,
    LicenceExpired,
    LicenceInvalid,
    LicenceRevoked,
    LicenceTampered,
    LicenceMissing,
)
from admiralty.licence.grace import (
    GRACE_DEFAULT_DAYS,
    grace_remaining_days,
    in_grace_window,
    next_grace_until,
    parse_iso,
)
from admiralty.licence.storage import (
    LicenceRecord,
    delete_record,
    load_record,
    save_record,
)


__all__ = [
    "activate",
    "validate",
    "deactivate",
    "status",
    "LicenceRecord",
    "LicenceError",
    "LicenceExpired",
    "LicenceInvalid",
    "LicenceRevoked",
    "LicenceTampered",
    "LicenceMissing",
]


def activate(key: str) -> LicenceRecord:
    """Activate `key` via Polar's online validation and persist the result.

    Raises LicenceInvalid if Polar rejects the key (4xx).
    Raises PolarError on network/5xx — does NOT cache anything; activation
    requires a successful online round-trip.
    """
    if not key or not key.strip():
        raise LicenceInvalid("Licence key is empty.")

    client = PolarClient()
    payload = client.validate(key.strip())  # raises on 4xx/5xx/network

    now = datetime.now(timezone.utc)
    record = LicenceRecord(
        licence_key=key.strip(),
        tier=payload["tier"],
        product_id=payload["product_id"],
        customer_id=payload["customer_id"],
        issued_at=payload["issued_at"],
        expires_at=payload["expires_at"],
        last_validated_at=now.isoformat(),
        offline_grace_until=next_grace_until(now).isoformat(),
        signing_secret=payload["signing_secret"],  # consumed once → keychain
    )
    save_record(record)
    return record


def validate(strict: bool = False) -> LicenceRecord:
    """Read the stored record, refresh online if stale, return a valid record.

    Behaviour:
      - record missing → LicenceMissing
      - signature tampered → LicenceTampered
      - last_validated_at < 24h ago AND not strict → fast path, no HTTP
      - else → call Polar; on 200 refresh timestamps, on revoked/expired
        raise the corresponding error, on network failure honour the
        14-day grace window then raise LicenceExpired beyond it
      - strict=True forces an online check regardless of cache age
      - When grace fallback is used, the returned record has
        `used_grace=True` and `grace_remaining_days` populated, so the
        CLI can render a warning banner without changing public types.
    """
    record = load_record()  # raises LicenceMissing/LicenceTampered

    now = datetime.now(timezone.utc)
    last = parse_iso(record.last_validated_at)
    cached_ok = (now - last).total_seconds() < 24 * 3600

    if cached_ok and not strict:
        if parse_iso(record.expires_at) <= now:
            raise LicenceExpired(record.expires_at)
        record.used_grace = False
        return record

    try:
        payload = PolarClient().validate(record.licence_key)
        record.last_validated_at = now.isoformat()
        record.offline_grace_until = next_grace_until(now).isoformat()
        record.expires_at = payload.get("expires_at", record.expires_at)
        save_record(record)
        record.used_grace = False
        return record
    except PolarError as exc:
        if exc.status in (401, 403):
            if exc.is_revoked():
                raise LicenceRevoked(exc.reason or exc.polar_status) from exc
            raise LicenceExpired(exc.reason or "Polar marked the key as not granted") from exc
        if in_grace_window(now, record.offline_grace_until):
            record.used_grace = True
            record.grace_remaining_days = grace_remaining_days(now, record.offline_grace_until)
            return record
        raise LicenceExpired(
            f"Offline grace expired ({grace_remaining_days(now, record.offline_grace_until)} days remaining). "
            "Connect to the internet to revalidate."
        ) from exc


def deactivate() -> None:
    """Drop the local licence record (file + keychain entry).

    Note: this does NOT cancel the Polar subscription — that's the
    customer's billing portal action.
    """
    delete_record()


def status() -> "LicenceRecord | None":
    """Return the current record, or None if no licence is activated.
    Never raises — callers ask "do we have a licence at all?".
    """
    try:
        return load_record()
    except LicenceMissing:
        return None
    except LicenceTampered:
        return None
