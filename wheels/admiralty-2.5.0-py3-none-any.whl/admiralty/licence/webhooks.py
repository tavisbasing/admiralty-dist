"""Polar webhook handlers — runs as a FastAPI service at licence.admiraltyai.com.

Ships in this repo for review + version control + tests, but the
deployable artefact lives under `infra/licence-backend/`. The CLI hot
path never imports this module.

Polar event flow:
    subscription.created   → issue licence key + email customer
    subscription.updated   → extend expires_at on the key
    subscription.canceled  → mark key for revocation at end-of-paid-period
    subscription.refunded  → revoke key immediately

HMAC verification: Polar signs every webhook with HMAC-SHA256 using the
secret stored in env var POLAR_WEBHOOK_SECRET. Replay-window: 5 min
(webhook timestamp must be within the window to be honoured).
"""

from __future__ import annotations

import hashlib
import hmac
import json as _json
import os
import time
from typing import Any, Dict

# FastAPI is an optional dependency — only needed by the deployed service,
# never on the CLI hot path.
try:
    from fastapi import FastAPI, HTTPException, Request
except ImportError:  # pragma: no cover — production deploy installs FastAPI
    FastAPI = None  # type: ignore[assignment]
    HTTPException = None  # type: ignore[assignment]
    Request = None  # type: ignore[assignment]


# Replay window: reject events whose timestamp is older than this.
WEBHOOK_REPLAY_WINDOW_SECONDS = 5 * 60


# ---------------------------------------------------------------------------
# Pure helpers (deps-free; tested without FastAPI)
# ---------------------------------------------------------------------------

def verify_signature(secret: str, body: bytes, header_signature: str) -> bool:
    """HMAC-SHA256 compare against `polar-signature` header.

    Polar's signature header has shape `t=<unix>,v1=<hex>`. The signed
    payload is `t.<body>` (timestamp + dot + raw body bytes).
    """
    if not header_signature or not secret:
        return False
    parts = dict(p.split("=", 1) for p in header_signature.split(",") if "=" in p)
    timestamp = parts.get("t", "")
    sig = parts.get("v1", "")
    if not timestamp or not sig:
        return False

    try:
        ts_int = int(timestamp)
    except ValueError:
        return False
    if abs(time.time() - ts_int) > WEBHOOK_REPLAY_WINDOW_SECONDS:
        return False

    expected = hmac.new(
        secret.encode("utf-8"),
        f"{timestamp}.".encode("utf-8") + body,
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, sig)


def dispatch_event(event_type: str, data: Dict[str, Any]) -> Dict[str, Any]:
    """Route a verified Polar event to the right handler.

    Returns the response body the webhook endpoint should send back to
    Polar. Always 2xx-shaped — Polar retries on 4xx/5xx, so we want
    soft-failure behaviour (logged, not retried) for events we don't
    recognise.
    """
    handler = {
        "subscription.created": handle_purchase,
        "subscription.updated": handle_renewal,
        "subscription.canceled": handle_cancellation,
        "subscription.refunded": handle_refund,
        # Polar emits payment.refunded for one-off purchases as well.
        "payment.refunded": handle_refund,
    }.get(event_type)

    if handler is None:
        return {"ok": True, "handled": "ignored", "event_type": event_type}

    licence_key_id = handler(data)
    return {
        "ok": True,
        "handled": event_type,
        "licence_key_id": licence_key_id,
    }


# ---------------------------------------------------------------------------
# Event handlers (each returns the licence-key id it acted on)
# ---------------------------------------------------------------------------
# In production these would call back to Polar's licence-keys API to
# create/update keys + dispatch transactional emails via Resend or
# Postmark. Kept as thin coordinators here so the dispatching logic is
# fully testable without external services.

def handle_purchase(data: Dict[str, Any]) -> str:
    """subscription.created — issue a new licence key + send activation email."""
    customer_id = data.get("customer", {}).get("id", "")
    product_id = data.get("product_id") or data.get("product", {}).get("id", "")
    return _issue_licence_key(customer_id, product_id, send_email=True)


def handle_renewal(data: Dict[str, Any]) -> str:
    """subscription.updated — extend expires_at on the existing key."""
    key_id = data.get("license_key_id") or data.get("license_key", {}).get("id", "")
    new_expires = data.get("current_period_end") or data.get("expires_at", "")
    if not key_id:
        return ""
    _extend_licence_key(key_id, new_expires)
    return key_id


def handle_cancellation(data: Dict[str, Any]) -> str:
    """subscription.canceled — mark the key for revocation at end-of-paid-period.

    Don't revoke immediately — fairness. The customer paid for this period.
    """
    key_id = data.get("license_key_id") or data.get("license_key", {}).get("id", "")
    period_end = data.get("current_period_end", "")
    if not key_id:
        return ""
    _schedule_revocation(key_id, period_end)
    return key_id


def handle_refund(data: Dict[str, Any]) -> str:
    """subscription.refunded / payment.refunded — revoke the key immediately."""
    key_id = data.get("license_key_id") or data.get("license_key", {}).get("id", "")
    if not key_id:
        return ""
    _revoke_licence_key(key_id, reason="payment_refunded")
    return key_id


# ---------------------------------------------------------------------------
# Polar API delegates (stubs in this module — wired up in deployment)
# ---------------------------------------------------------------------------
# These are kept tiny and side-effect-only so the test suite can replace
# them with mocks. The deployed service injects the real Polar client.

def _issue_licence_key(customer_id: str, product_id: str, send_email: bool = True) -> str:
    """Hook: call Polar's licence-keys API to mint a new key + email customer."""
    # Real implementation lives in the deployed FastAPI service; this stub
    # returns a deterministic placeholder so tests stay deterministic.
    return f"lkey_for_{customer_id}_{product_id}"


def _extend_licence_key(key_id: str, new_expires: str) -> None:
    """Hook: PATCH the licence key's expires_at on Polar."""
    return None


def _schedule_revocation(key_id: str, period_end: str) -> None:
    """Hook: schedule a Polar revoke at period_end (Polar handles this natively
    via the cancel-at-period-end flag)."""
    return None


def _revoke_licence_key(key_id: str, reason: str) -> None:
    """Hook: POST to Polar to revoke the licence key immediately."""
    return None


# ---------------------------------------------------------------------------
# FastAPI app — only constructed when FastAPI is available
# ---------------------------------------------------------------------------

def create_app(secret: str = "") -> "FastAPI":
    """Construct the FastAPI app. Pass `secret` for tests; production reads
    POLAR_WEBHOOK_SECRET from env at request-time so secret rotation is
    possible without redeploy.
    """
    if FastAPI is None:
        raise RuntimeError(
            "FastAPI is not installed in this environment — install "
            "`pip install fastapi uvicorn` (only needed for the deployed "
            "licence-backend service, not the CLI)."
        )
    app = FastAPI(title="Admiralty Licence Backend", version="1.0.0")

    @app.post("/v1/webhooks/polar")
    async def polar_webhook(request: Request):  # pragma: no cover — exercised via TestClient
        secret_at_runtime = secret or os.environ.get("POLAR_WEBHOOK_SECRET", "")
        body = await request.body()
        sig = request.headers.get("polar-signature", "")
        if not verify_signature(secret_at_runtime, body, sig):
            raise HTTPException(status_code=401, detail="invalid signature")

        try:
            payload = _json.loads(body.decode("utf-8"))
        except _json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="malformed json")

        event_type = payload.get("type", "")
        data = payload.get("data", {}) or payload
        return dispatch_event(event_type, data)

    @app.get("/healthz")
    async def healthz():  # pragma: no cover
        return {"ok": True}

    return app
